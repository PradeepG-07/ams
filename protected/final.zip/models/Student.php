<?php
 
class Student extends EMongoDocument
{
    public $first_name;
    public $last_name;
    public $email;
    public $password;
    public $roll_no;
    public $classes = [];
    public $attendance = [];
    public $percentage;
    public $address;
    public $profile_picture; // Add profile picture field

 
    public function getCollectionName()
    {
        return 'students'; 
    }

    public function rules()
    {
        return array(
            array('email, password', 'required'),
            array('email', 'email'),
            array('first_name, last_name, email, password', 'length', 'max' => 255),
            array('roll_no', 'length', 'max' => 10),
            array('percentage', 'numerical'),
            array('classes', 'safe'),
            array('today_attendance', 'safe'),
            array('address', 'safe'),
            array('profile_picture', 'safe'), // Add profile_picture to safe attributes
            array('email', 'safe', 'on' => 'search'),
        );
    }
 
    public function attributeLabels()
    {
        return array(
            'first_name' => 'First Name',
            'last_name' => 'Last Name',
            'email' => 'Email',
            'password' => 'Password',
            'roll_no' => 'Roll No',
            'classes' => 'Classes',
            'percentage' => 'Percentage',
            'address' => 'Address',
            'profile_picture' => 'Profile Picture', // Add label for profile picture
        );
    }
    public function hashPassword($password)
    {
        return password_hash($password, PASSWORD_BCRYPT);
    }

    public function behaviors()
    {
        return array(
            'EMongoDocumentBehavior' => array(
                'class' => 'ext.YiiMongoDbSuite.behaviors.EMongoDocumentBehavior'
            ),
        );
    }

    /**
     * Initialize embedded documents
     * This ensures embedded documents are never null when the ORM operates on them
     */
    public function initEmbeddedDocuments()
    {
        parent::initEmbeddedDocuments();
        
        // Initialize address if it's null
        if ($this->address === null) {
            $this->address = new Address();
        }
    }

    public function embeddedDocuments()
    {
        return array(
            'address' => 'Address',
        );
    }
    
    public static function model($className=__CLASS__)
    {
        return parent::model($className);
    }
}