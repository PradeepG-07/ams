<?php
class Qualification extends EMongoEmbeddedDocument {

    public $degree;
    public $field;
    public $institute;
    public $year;
    public $grade;



    public function getCollectionName() {
        return 'qualifications';
    }
    public function rules() {
        return array(
            array('_id degree, field, institute, year, grade', 'required'),
            array('degree, field, institute', 'length', 'max' => 255),
            array('year', 'numerical', 'integerOnly' => true),
            array('grade', 'numerical'),
        );
    }
}
