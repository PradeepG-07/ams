<?php
 
class ClassRoom extends EMongoDocument
{
    public $class_name;
    public $class_teacher_id;
    public $students = [];
    public $subject;
    public $academic_year;

    public $attendance = [];


    public function getCollectionName()
    {
        return 'classrooms'; 
    }

    public function rules()
    {
        return array(
            array('class_name, class_teacher_id, subject, academic_year', 'required'),
            array('class_name', 'length', 'max' => 255),
            array('students,attendance', 'safe'),
            array('subject', 'length', 'max' => 100),
            array('academic_year', 'length', 'max' => 20),
        );
    }
 
    public function attributeLabels()
    {
        return array(
            'class_name' => 'Class Name',
            'class_teacher_id' => 'Class Teacher ID',
            'students' => 'Students',
            'subject' => 'Subject',
            'academic_year' => 'Academic Year',
        );
    }
 
    public static function model($className=__CLASS__)
    {
        return parent::model($className);
    }
}