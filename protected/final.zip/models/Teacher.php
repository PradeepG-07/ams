<?php
 
class Teacher extends EMongoDocument
{
    public $first_name;
    public $last_name;
    public $email;
    public $password;
    public $EmployeeID;
    public $classes = []; // Array of classroom ObjectIds
    public $address; // Changed from $Address to $address to match embeddedDocuments() definition
    public $Qualifications = []; // Embedded array
 
    public function getCollectionName()
    {
        return 'teachers';
    }
 
    public function rules()
    {
        return array(
            array('email, password', 'required'),
            array('email', 'email'),
            array('first_name, last_name, email, password', 'length', 'max' => 255),
            array('EmployeeID', 'length', 'max' => 10),
            array('address', 'safe'),
            array('email', 'safe', 'on' => 'search'),
        );
    }
 
    public function attributeLabels()
    {
        return array(
            'first_name' => 'First Name',
            'last_name' => 'Last Name',
            'email' => 'Email',
            'password' => 'Password',
            'EmployeeID' => 'Employee ID',
            'Qualifications' => 'Qualifications',
            'classes' => 'Classes',
            'address' => 'Address',
        );
    }
    
    // Fix the behavior configuration to match what EMongoDocumentBehavior supports
    public function behaviors()
    {
        return array(
            'embeddedArrays' => array(
                'class' => 'ext.YiiMongoDbSuite.extra.EEmbeddedArraysBehavior',
                'arrayPropertyName' => 'Qualifications',
                'arrayDocClassName' => 'Qualification'
            ),
        );
    }

    /**
     * Initialize embedded documents
     */
    public function initEmbeddedDocuments()
    {
        parent::initEmbeddedDocuments();
         
        // Initialize address if it's null
        if ($this->address === null) {
            $this->address = new Address();
        }
        
        // Initialize Qualifications array if it's null
        if ($this->Qualifications === null) {
            $this->Qualifications = array();
        }
        
        // Initialize classes array if it's null
        if ($this->classes === null) {
            $this->classes = array();
        }
    }
 
    public function embeddedDocuments()
    {
        return array(
            'address' => 'Address',
        );
    }
    public function hashPassword($password)
    {
        return password_hash($password, PASSWORD_BCRYPT);
    }
 
    public static function model($className=__CLASS__)
    {
        return parent::model($className);
    }
}
