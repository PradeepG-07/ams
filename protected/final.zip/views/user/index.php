<?php
/* @var $this UserController */
/* @var $dataProvider CActiveDataProvider */

$this->breadcrumbs=array(
	'Users',
);

$this->menu=array(
	array('label'=>'Register User', 'url'=>array('register')),
	array('label'=>'Login User', 'url'=>array('login')),

	//array('label'=>'Manage User', 'url'=>array('admin')),
);
?>

