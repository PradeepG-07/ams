<?php

/**
 * @runTestsInSeparateProcesses
 * @preserveGlobalState disabled
 */
use Mockery\Adapter\Phpunit\MockeryTestCase;
use Mockery as m;

class LoggingHelperTest extends MockeryTestCase
{
    private $yiiMock;

    protected function setUp(): void
    {
        parent::setUp();
        $this->yiiMock = new YiiAppMock();
        $this->yiiMock->mockApp();
        
        // Mock Yii::log static method
        m::mock('alias:Yii');
    }

    protected function tearDown(): void
    {
        $this->yiiMock->close();
        parent::tearDown();
    }

    public function testLogAuthEventWithAllParameters()
    {
        $event = 'User login successful';
        $userId = '123';
        $userType = 'teacher';
        $context = ['ip' => '192.168.1.1', 'browser' => 'Chrome'];

        // Mock Yii::log
        $yiiMock = m::mock('alias:Yii');
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/\[.{8}\] User login successful \| User: 123 \| Type: teacher \| Context: .*ip.*browser/'), 
                       LoggingHelper::LEVEL_INFO, 
                       LoggingHelper::CATEGORY_AUTH);

        LoggingHelper::logAuthEvent($event, $userId, $userType, LoggingHelper::LEVEL_INFO, $context);
    }

    public function testLogAuthEventMinimalParameters()
    {
        $event = 'Password reset requested';

        $yiiMock = m::mock('alias:Yii');
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/\[.{8}\] Password reset requested/'), 
                       LoggingHelper::LEVEL_INFO, 
                       LoggingHelper::CATEGORY_AUTH);

        LoggingHelper::logAuthEvent($event);
    }

    public function testLogAttendanceEventWithAllParameters()
    {
        $operation = 'Attendance marked';
        $classId = 'class_123';
        $date = '2024-01-15';
        $studentCount = 25;
        $context = ['method' => 'bulk_upload'];

        $yiiMock = m::mock('alias:Yii');
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/\[.{8}\] Attendance marked \| Class: class_123 \| Date: 2024-01-15 \| Students: 25 \| Context: .*method.*bulk_upload/'), 
                       LoggingHelper::LEVEL_INFO, 
                       LoggingHelper::CATEGORY_ATTENDANCE);

        LoggingHelper::logAttendanceEvent($operation, $classId, $date, $studentCount, LoggingHelper::LEVEL_INFO, $context);
    }

    public function testLogAttendanceEventMinimalParameters()
    {
        $operation = 'Attendance report generated';

        $yiiMock = m::mock('alias:Yii');
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/\[.{8}\] Attendance report generated/'), 
                       LoggingHelper::LEVEL_INFO, 
                       LoggingHelper::CATEGORY_ATTENDANCE);

        LoggingHelper::logAttendanceEvent($operation);
    }

    public function testLogClassroomEventWithAllParameters()
    {
        $operation = 'Classroom created';
        $classroomId = 'room_456';
        $teacherId = 'teacher_789';
        $context = ['capacity' => 30];

        $yiiMock = m::mock('alias:Yii');
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/\[.{8}\] Classroom created \| Classroom: room_456 \| Teacher: teacher_789 \| Context: .*capacity.*30/'), 
                       LoggingHelper::LEVEL_INFO, 
                       LoggingHelper::CATEGORY_CLASSROOM);

        LoggingHelper::logClassroomEvent($operation, $classroomId, $teacherId, LoggingHelper::LEVEL_INFO, $context);
    }

    public function testLogValidationEventSuccess()
    {
        $operation = 'Student data validation';
        $success = true;
        $errors = [];
        $context = ['field_count' => 8];

        $yiiMock = m::mock('alias:Yii');
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/\[.{8}\] Student data validation \| SUCCESS \| Context: .*field_count.*8/'), 
                       LoggingHelper::LEVEL_INFO, 
                       LoggingHelper::CATEGORY_VALIDATION);

        LoggingHelper::logValidationEvent($operation, $success, $errors, LoggingHelper::LEVEL_INFO, $context);
    }

    public function testLogValidationEventFailure()
    {
        $operation = 'Form validation';
        $success = false;
        $errors = ['Name is required', 'Invalid email format'];
        $context = ['form' => 'student_registration'];

        $yiiMock = m::mock('alias:Yii');
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/\[.{8}\] Form validation \| FAILED \| Errors: Name is required, Invalid email format \| Context: .*form.*student_registration/'), 
                       LoggingHelper::LEVEL_INFO, 
                       LoggingHelper::CATEGORY_VALIDATION);

        LoggingHelper::logValidationEvent($operation, $success, $errors, LoggingHelper::LEVEL_INFO, $context);
    }

    public function testLogSecurityEventLowSeverity()
    {
        $event = 'Multiple failed login attempts';
        $severity = 'low';
        $userId = 'user_123';
        $context = ['attempts' => 3, 'ip' => '192.168.1.100'];

        $yiiMock = m::mock('alias:Yii');
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/\[.{8}\] SECURITY \[low\] \| Multiple failed login attempts \| User: user_123 \| Context: .*attempts.*3.*ip/'), 
                       LoggingHelper::LEVEL_INFO, 
                       LoggingHelper::CATEGORY_SECURITY);

        LoggingHelper::logSecurityEvent($event, $severity, $userId, $context);
    }

    public function testLogSecurityEventHighSeverity()
    {
        $event = 'SQL injection attempt detected';
        $severity = 'high';
        $userId = null;
        $context = ['query' => 'malicious_query'];

        $yiiMock = m::mock('alias:Yii');
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/\[.{8}\] SECURITY \[high\] \| SQL injection attempt detected \| Context: .*query.*malicious_query/'), 
                       LoggingHelper::LEVEL_ERROR, 
                       LoggingHelper::CATEGORY_SECURITY);

        LoggingHelper::logSecurityEvent($event, $severity, $userId, $context);
    }

    public function testLogSecurityEventCriticalSeverity()
    {
        $event = 'System compromise detected';
        $severity = 'critical';

        $yiiMock = m::mock('alias:Yii');
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/\[.{8}\] SECURITY \[critical\] \| System compromise detected/'), 
                       LoggingHelper::LEVEL_ERROR, 
                       LoggingHelper::CATEGORY_SECURITY);

        LoggingHelper::logSecurityEvent($event, $severity);
    }

    public function testLogSecurityEventMediumSeverity()
    {
        $event = 'Unauthorized access attempt';
        $severity = 'medium';

        $yiiMock = m::mock('alias:Yii');
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/\[.{8}\] SECURITY \[medium\] \| Unauthorized access attempt/'), 
                       LoggingHelper::LEVEL_WARNING, 
                       LoggingHelper::CATEGORY_SECURITY);

        LoggingHelper::logSecurityEvent($event, $severity);
    }

    public function testLogPerformanceWithMemoryUsage()
    {
        $operation = 'Database query execution';
        $executionTime = 2.5;
        $memoryUsage = 1048576; // 1MB
        $context = ['query_type' => 'SELECT', 'table' => 'students'];

        $yiiMock = m::mock('alias:Yii');
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/\[.{8}\] PERFORMANCE \| Database query execution \| Time: 2.5s \| Memory: 1 MB \| Context: .*query_type.*SELECT/'), 
                       LoggingHelper::LEVEL_PROFILE, 
                       LoggingHelper::CATEGORY_PERFORMANCE);

        LoggingHelper::logPerformance($operation, $executionTime, $memoryUsage, $context);
    }

    public function testLogPerformanceWithoutMemoryUsage()
    {
        $operation = 'File processing';
        $executionTime = 0.75;

        $yiiMock = m::mock('alias:Yii');
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/\[.{8}\] PERFORMANCE \| File processing \| Time: 0.75s/'), 
                       LoggingHelper::LEVEL_PROFILE, 
                       LoggingHelper::CATEGORY_PERFORMANCE);

        LoggingHelper::logPerformance($operation, $executionTime);
    }

    public function testLogDatabaseEventSuccess()
    {
        $operation = 'INSERT';
        $table = 'students';
        $success = true;
        $context = ['rows_affected' => 1];

        $yiiMock = m::mock('alias:Yii');
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/\[.{8}\] DB \| INSERT \| Table: students \| SUCCESS \| Context: .*rows_affected.*1/'), 
                       LoggingHelper::LEVEL_INFO, 
                       LoggingHelper::CATEGORY_DATABASE);

        LoggingHelper::logDatabaseEvent($operation, $table, $success, LoggingHelper::LEVEL_INFO, $context);
    }

    public function testLogDatabaseEventFailure()
    {
        $operation = 'UPDATE';
        $table = 'classrooms';
        $success = false;
        $context = ['error' => 'Connection timeout'];

        $yiiMock = m::mock('alias:Yii');
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/\[.{8}\] DB \| UPDATE \| Table: classrooms \| FAILED \| Context: .*error.*Connection timeout/'), 
                       LoggingHelper::LEVEL_INFO, 
                       LoggingHelper::CATEGORY_DATABASE);

        LoggingHelper::logDatabaseEvent($operation, $table, $success, LoggingHelper::LEVEL_INFO, $context);
    }

    public function testLogDatabaseEventWithoutTable()
    {
        $operation = 'BACKUP';
        $success = true;

        $yiiMock = m::mock('alias:Yii');
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/\[.{8}\] DB \| BACKUP \| SUCCESS/'), 
                       LoggingHelper::LEVEL_INFO, 
                       LoggingHelper::CATEGORY_DATABASE);

        LoggingHelper::logDatabaseEvent($operation, null, $success);
    }

    public function testLogApiEventSuccess()
    {
        $method = 'POST';
        $endpoint = '/api/students';
        $statusCode = 201;
        $responseTime = 0.25;
        $context = ['payload_size' => 512];

        $yiiMock = m::mock('alias:Yii');
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/\[.{8}\] API \| POST \/api\/students \| Status: 201 \| Time: 0.25s \| Context: .*payload_size.*512/'), 
                       LoggingHelper::LEVEL_INFO, 
                       LoggingHelper::CATEGORY_API);

        LoggingHelper::logApiEvent($method, $endpoint, $statusCode, $responseTime, $context);
    }

    public function testLogApiEventError()
    {
        $method = 'GET';
        $endpoint = '/api/students/999';
        $statusCode = 404;
        $context = ['user_id' => 'user_123'];

        $yiiMock = m::mock('alias:Yii');
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/\[.{8}\] API \| GET \/api\/students\/999 \| Status: 404 \| Context: .*user_id.*user_123/'), 
                       LoggingHelper::LEVEL_WARNING, 
                       LoggingHelper::CATEGORY_API);

        LoggingHelper::logApiEvent($method, $endpoint, $statusCode, null, $context);
    }

    public function testLogApiEventServerError()
    {
        $method = 'PUT';
        $endpoint = '/api/classrooms/123';
        $statusCode = 500;

        $yiiMock = m::mock('alias:Yii');
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/\[.{8}\] API \| PUT \/api\/classrooms\/123 \| Status: 500/'), 
                       LoggingHelper::LEVEL_WARNING, 
                       LoggingHelper::CATEGORY_API);

        LoggingHelper::logApiEvent($method, $endpoint, $statusCode);
    }

    public function testLogExceptionWithContext()
    {
        $exception = new Exception('Test exception message');
        $context = 'StudentController::create';
        $additionalData = ['user_id' => '123', 'form_data' => ['name' => 'John']];

        $yiiMock = m::mock('alias:Yii');
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/\[.{8}\] EXCEPTION \| Context: StudentController::create \| Type: Exception \| Message: Test exception message \| File: .*LoggingHelperTest.php:\d+ \| Data: .*user_id.*123/'), 
                       LoggingHelper::LEVEL_ERROR, 
                       'exception');

        LoggingHelper::logException($exception, $context, $additionalData);
    }

    public function testLogExceptionMinimal()
    {
        $exception = new RuntimeException('Runtime error');

        $yiiMock = m::mock('alias:Yii');
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/\[.{8}\] EXCEPTION \| Type: RuntimeException \| Message: Runtime error \| File: .*LoggingHelperTest.php:\d+/'), 
                       LoggingHelper::LEVEL_ERROR, 
                       'exception');

        LoggingHelper::logException($exception);
    }

    public function testLogExceptionWithDebugMode()
    {
        // Set debug mode
        if (!defined('YII_DEBUG')) {
            define('YII_DEBUG', true);
        } else {
            $originalDebug = YII_DEBUG;
            runkit_constant_redefine('YII_DEBUG', true);
        }

        $exception = new InvalidArgumentException('Invalid argument');

        $yiiMock = m::mock('alias:Yii');
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/\[.{8}\] EXCEPTION.*Trace: #0/s'), 
                       LoggingHelper::LEVEL_ERROR, 
                       'exception');

        LoggingHelper::logException($exception, 'test_context');

        // Restore debug mode if it was changed
        if (isset($originalDebug)) {
            runkit_constant_redefine('YII_DEBUG', $originalDebug);
        }
    }

    public function testFormatBytesVariousSizes()
    {
        // Test different byte sizes by calling methods that use formatBytes
        $operation = 'Memory test';
        $executionTime = 1.0;
        
        // Test bytes
        $yiiMock = m::mock('alias:Yii');
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/Memory: 512 B/'), 
                       LoggingHelper::LEVEL_PROFILE, 
                       LoggingHelper::CATEGORY_PERFORMANCE);
        LoggingHelper::logPerformance($operation, $executionTime, 512);

        // Test KB
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/Memory: 2 KB/'), 
                       LoggingHelper::LEVEL_PROFILE, 
                       LoggingHelper::CATEGORY_PERFORMANCE);
        LoggingHelper::logPerformance($operation, $executionTime, 2048);

        // Test MB with decimals
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/Memory: 1.5 MB/'), 
                       LoggingHelper::LEVEL_PROFILE, 
                       LoggingHelper::CATEGORY_PERFORMANCE);
        LoggingHelper::logPerformance($operation, $executionTime, 1572864);

        // Test GB
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/Memory: 2 GB/'), 
                       LoggingHelper::LEVEL_PROFILE, 
                       LoggingHelper::CATEGORY_PERFORMANCE);
        LoggingHelper::logPerformance($operation, $executionTime, 2147483648);

        // Test zero bytes
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/Memory: 0 B/'), 
                       LoggingHelper::LEVEL_PROFILE, 
                       LoggingHelper::CATEGORY_PERFORMANCE);
        LoggingHelper::logPerformance($operation, $executionTime, 0);
    }

    public function testLoggingWithException()
    {
        // Mock Yii::log to throw exception to test exception handling in log method
        $yiiMock = m::mock('alias:Yii');
        $yiiMock->shouldReceive('log')
                ->once()
                ->andThrow(new Exception('Logging failed'));

        // Capture error_log output
        $this->expectOutputString('');
        
        // This should not throw exception but use error_log as fallback
        LoggingHelper::logAuthEvent('Test event');
        
        // Verify that it doesn't break the application
        $this->assertTrue(true);
    }

    public function testRequestIdConsistency()
    {
        // Test that the same request ID is used across multiple log calls
        $yiiMock = m::mock('alias:Yii');
        
        // Capture the request ID from first call
        $requestId = null;
        $yiiMock->shouldReceive('log')
                ->twice()
                ->with(m::on(function($message) use (&$requestId) {
                    if (preg_match('/\[([a-f0-9]{8})\]/', $message, $matches)) {
                        if ($requestId === null) {
                            $requestId = $matches[1];
                            return true;
                        } else {
                            return $requestId === $matches[1];
                        }
                    }
                    return false;
                }), m::any(), m::any());

        LoggingHelper::logAuthEvent('First event');
        LoggingHelper::logAuthEvent('Second event');
    }

    public function testAllLogLevelConstants()
    {
        // Test all log level constants exist and have correct values
        $this->assertEquals('error', LoggingHelper::LEVEL_ERROR);
        $this->assertEquals('warning', LoggingHelper::LEVEL_WARNING);
        $this->assertEquals('info', LoggingHelper::LEVEL_INFO);
        $this->assertEquals('trace', LoggingHelper::LEVEL_TRACE);
        $this->assertEquals('profile', LoggingHelper::LEVEL_PROFILE);
    }

    public function testAllCategoryConstants()
    {
        // Test all category constants exist and have correct values
        $this->assertEquals('authentication', LoggingHelper::CATEGORY_AUTH);
        $this->assertEquals('attendance', LoggingHelper::CATEGORY_ATTENDANCE);
        $this->assertEquals('classroom', LoggingHelper::CATEGORY_CLASSROOM);
        $this->assertEquals('validation', LoggingHelper::CATEGORY_VALIDATION);
        $this->assertEquals('security', LoggingHelper::CATEGORY_SECURITY);
        $this->assertEquals('performance', LoggingHelper::CATEGORY_PERFORMANCE);
        $this->assertEquals('database', LoggingHelper::CATEGORY_DATABASE);
        $this->assertEquals('api', LoggingHelper::CATEGORY_API);
    }

    public function testEmptyContextHandling()
    {
        // Test that empty context arrays are handled properly
        $yiiMock = m::mock('alias:Yii');
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/\[.{8}\] Test event$/'), // Should not contain Context part
                       LoggingHelper::LEVEL_INFO, 
                       LoggingHelper::CATEGORY_AUTH);

        LoggingHelper::logAuthEvent('Test event', null, null, LoggingHelper::LEVEL_INFO, []);
    }

    public function testNullParameterHandling()
    {
        // Test various null parameter combinations
        $yiiMock = m::mock('alias:Yii');
        
        // Auth event with nulls
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/\[.{8}\] Login attempt$/'), 
                       LoggingHelper::LEVEL_INFO, 
                       LoggingHelper::CATEGORY_AUTH);
        LoggingHelper::logAuthEvent('Login attempt', null, null);

        // Attendance event with nulls
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/\[.{8}\] Report generated$/'), 
                       LoggingHelper::LEVEL_INFO, 
                       LoggingHelper::CATEGORY_ATTENDANCE);
        LoggingHelper::logAttendanceEvent('Report generated', null, null, null);

        // Classroom event with nulls
        $yiiMock->shouldReceive('log')
                ->once()
                ->with(m::pattern('/\[.{8}\] Room updated$/'), 
                       LoggingHelper::LEVEL_INFO, 
                       LoggingHelper::CATEGORY_CLASSROOM);            
        LoggingHelper::logClassroomEvent('Room updated', null, null);
    }
}
