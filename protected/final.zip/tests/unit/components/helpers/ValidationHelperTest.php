<?php
 
/**
* @runTestsInSeparateProcesses
* @preserveGlobalState disabled
*/
 
 
class ValidationHelperTest extends Mockery\Adapter\Phpunit\MockeryTestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        
        // Mock Yii framework components
        if (!class_exists('Yii')) {
            $yii = Mockery::mock('alias:Yii');
            $yii->shouldReceive('log')->andReturnNull();
        }
    }

    public function testValidateEmailWithValidEmail()
    {
        $result = ValidationHelper::validateEmail('test@example.com');
        
        $this->assertTrue($result['success']);
        $this->yiiAppMock = new YiiAppMock();
        $this->mongoMock = new MongoMock();
        $this->assertEquals('test@example.com', $result['data']);
        $this->assertEquals('Email validation passed', $result['message']);
    }

    public function testValidateEmailWithInvalidEmail()
    {
        $result = ValidationHelper::validateEmail('invalid-email');
        
        $this->assertFalse($result['success']);
        $this->assertEquals('Email validation failed', $result['message']);
        $this->assertEquals(400, $result['code']);
        $this->assertContains('Please provide a valid email address', $result['errors']);
    }

    public function testValidateEmailWithEmptyEmailRequired()
    {
        $result = ValidationHelper::validateEmail('', true);
        
        $this->assertFalse($result['success']);
        $this->assertEquals('Email validation failed', $result['message']);
        $this->assertContains('Email address is required', $result['errors']);
    }

    public function testValidateEmailWithEmptyEmailNotRequired()
    {
        $result = ValidationHelper::validateEmail('', false);
        
        $this->assertTrue($result['success']);
        $this->assertEquals('', $result['data']);
        $this->assertEquals('Email validation passed', $result['message']);
    }

    public function testValidateEmailWithWhitespace()
    {
        $result = ValidationHelper::validateEmail('  test@example.com  ');
        
        $this->assertTrue($result['success']);
        $this->assertEquals('test@example.com', $result['data']);
    }

    public function testValidateEmailWithException()
    {
        // Create a mock to throw exception during filter_var
        $originalEmail = 'test@example.com';
        
        // Use reflection to test exception handling
        $reflection = new ReflectionClass('ValidationHelper');
        $method = $reflection->getMethod('validateEmail');
        
        // Mock filter_var to throw exception (simulate by passing null which causes error)
        $result = ValidationHelper::validateEmail(null);
        
        // When null is passed, it should handle gracefully
        $this->assertFalse($result['success']);
        $this->assertEquals(400, $result['code']);
    }

    public function testValidatePasswordWithValidPassword()
    {
        $result = ValidationHelper::validatePassword('password123');
        
        $this->assertTrue($result['success']);
        $this->assertEquals('Password validation passed', $result['message']);
    }

    public function testValidatePasswordWithEmptyPassword()
    {
        $result = ValidationHelper::validatePassword('');
        
        $this->assertFalse($result['success']);
        $this->assertEquals('Password validation failed', $result['message']);
        $this->assertContains('Password is required', $result['errors']);
    }

    public function testValidatePasswordWithShortPassword()
    {
        $result = ValidationHelper::validatePassword('123', 6);
        
        $this->assertFalse($result['success']);
        $this->assertContains('Password must be at least 6 characters long', $result['errors']);
    }

    public function testValidatePasswordWithSpecialCharRequirements()
    {
        $result = ValidationHelper::validatePassword('simple', 6, true);
        
        $this->assertFalse($result['success']);
        $this->assertContains('Password must contain at least one uppercase letter', $result['errors']);
        $this->assertContains('Password must contain at least one number', $result['errors']);
        $this->assertContains('Password must contain at least one special character', $result['errors']);
    }

    public function testValidatePasswordWithAllRequirements()
    {
        $result = ValidationHelper::validatePassword('Password123!', 8, true);
        
        $this->assertTrue($result['success']);
        $this->assertEquals('Password validation passed', $result['message']);
    }

    public function testValidatePasswordMissingUppercase()
    {
        $result = ValidationHelper::validatePassword('password123!', 8, true);
        
        $this->assertFalse($result['success']);
        $this->assertContains('Password must contain at least one uppercase letter', $result['errors']);
    }

    public function testValidatePasswordMissingLowercase()
    {
        $result = ValidationHelper::validatePassword('PASSWORD123!', 8, true);
        
        $this->assertFalse($result['success']);
        $this->assertContains('Password must contain at least one lowercase letter', $result['errors']);
    }

    public function testValidatePasswordMissingNumbers()
    {
        $result = ValidationHelper::validatePassword('Password!', 8, true);
        
        $this->assertFalse($result['success']);
        $this->assertContains('Password must contain at least one number', $result['errors']);
    }

    public function testValidatePasswordMissingSpecialChars()
    {
        $result = ValidationHelper::validatePassword('Password123', 8, true);
        
        $this->assertFalse($result['success']);
        $this->assertContains('Password must contain at least one special character', $result['errors']);
    }

    public function testValidateNameWithValidName()
    {
        $result = ValidationHelper::validateName('John Doe');
        
        $this->assertTrue($result['success']);
        $this->assertEquals('John Doe', $result['data']);
        $this->assertEquals('Name validation passed', $result['message']);
    }

    public function testValidateNameWithEmptyRequired()
    {
        $result = ValidationHelper::validateName('', 'First Name', true);
        
        $this->assertFalse($result['success']);
        $this->assertContains('First Name is required', $result['errors']);
    }

    public function testValidateNameWithEmptyNotRequired()
    {
        $result = ValidationHelper::validateName('', 'First Name', false);
        
        $this->assertTrue($result['success']);
        $this->assertEquals('', $result['data']);
    }

    public function testValidateNameTooShort()
    {
        $result = ValidationHelper::validateName('A');
        
        $this->assertFalse($result['success']);
        $this->assertContains('Name must be at least 2 characters long', $result['errors']);
    }

    public function testValidateNameTooLong()
    {
        $longName = str_repeat('A', 51);
        $result = ValidationHelper::validateName($longName);
        
        $this->assertFalse($result['success']);
        $this->assertContains('Name must not exceed 50 characters', $result['errors']);
    }

    public function testValidateNameWithInvalidCharacters()
    {
        $result = ValidationHelper::validateName('John123');
        
        $this->assertFalse($result['success']);
        $this->assertContains('Name can only contain letters, spaces, hyphens, apostrophes, and periods', $result['errors']);
    }

    public function testValidateNameWithValidSpecialCharacters()
    {
        $result = ValidationHelper::validateName("O'Connor-Smith Jr.");
        
        $this->assertTrue($result['success']);
        $this->assertEquals("O'Connor-Smith Jr.", $result['data']);
    }

    public function testValidateNameWithWhitespace()
    {
        $result = ValidationHelper::validateName('  John Doe  ');
        
        $this->assertTrue($result['success']);
        $this->assertEquals('John Doe', $result['data']);
    }

    public function testValidateDateWithValidDate()
    {
        $result = ValidationHelper::validateDate('2025-06-13');
        
        $this->assertTrue($result['success']);
        $this->assertEquals('2025-06-13', $result['data']);
        $this->assertEquals('Date validation passed', $result['message']);
    }

    public function testValidateDateWithEmptyRequired()
    {
        $result = ValidationHelper::validateDate('', 'Y-m-d', true, true);
        
        $this->assertFalse($result['success']);
        $this->assertContains('Date is required', $result['errors']);
    }

    public function testValidateDateWithEmptyNotRequired()
    {
        $result = ValidationHelper::validateDate('', 'Y-m-d', true, false);
        
        $this->assertTrue($result['success']);
        $this->assertEquals('', $result['data']);
    }

    public function testValidateDateWithInvalidFormat()
    {
        $result = ValidationHelper::validateDate('13/06/2025', 'Y-m-d');
        
        $this->assertFalse($result['success']);
        $this->assertContains('Date must be in Y-m-d format', $result['errors']);
    }

    public function testValidateDateWithDifferentFormat()
    {
        $result = ValidationHelper::validateDate('13/06/2025', 'd/m/Y');
        
        $this->assertTrue($result['success']);
        $this->assertEquals('13/06/2025', $result['data']);
    }

    public function testValidateDateWithFutureNotAllowed()
    {
        $futureDate = date('Y-m-d', strtotime('+1 year'));
        $result = ValidationHelper::validateDate($futureDate, 'Y-m-d', false);
        
        $this->assertFalse($result['success']);
        $this->assertContains('Future dates are not allowed', $result['errors']);
    }

    public function testValidateDateWithFutureAllowed()
    {
        $futureDate = date('Y-m-d', strtotime('+1 year'));
        $result = ValidationHelper::validateDate($futureDate, 'Y-m-d', true);
        
        $this->assertTrue($result['success']);
        $this->assertEquals($futureDate, $result['data']);
    }

    public function testValidateDateWithTooOldDate()
    {
        $result = ValidationHelper::validateDate('1800-01-01');
        
        $this->assertFalse($result['success']);
        $this->assertContains('Date is outside acceptable range', $result['errors']);
    }

    public function testValidateDateWithTooFutureDate()
    {
        $result = ValidationHelper::validateDate('2050-01-01');
        
        $this->assertFalse($result['success']);
        $this->assertContains('Date is outside acceptable range', $result['errors']);
    }

    public function testValidateObjectIdWithValidId()
    {
        $result = ValidationHelper::validateObjectId('507f1f77bcf86cd799439011');
        
        $this->assertTrue($result['success']);
        $this->assertEquals('507f1f77bcf86cd799439011', $result['data']);
        $this->assertEquals('ObjectId validation passed', $result['message']);
    }

    public function testValidateObjectIdWithEmptyRequired()
    {
        $result = ValidationHelper::validateObjectId('', 'User ID', true);
        
        $this->assertFalse($result['success']);
        $this->assertContains('User ID is required', $result['errors']);
    }

    public function testValidateObjectIdWithEmptyNotRequired()
    {
        $result = ValidationHelper::validateObjectId('', 'User ID', false);
        
        $this->assertTrue($result['success']);
        $this->assertEquals('', $result['data']);
    }

    public function testValidateObjectIdWithInvalidFormat()
    {
        $result = ValidationHelper::validateObjectId('invalid-id');
        
        $this->assertFalse($result['success']);
        $this->assertContains('ID must be a valid ObjectId', $result['errors']);
    }

    public function testValidateObjectIdWithShortId()
    {
        $result = ValidationHelper::validateObjectId('507f1f77bcf86cd7');
        
        $this->assertFalse($result['success']);
        $this->assertContains('ID must be a valid ObjectId', $result['errors']);
    }

    public function testValidateObjectIdWithLongId()
    {
        $result = ValidationHelper::validateObjectId('507f1f77bcf86cd799439011extra');
        
        $this->assertFalse($result['success']);
        $this->assertContains('ID must be a valid ObjectId', $result['errors']);
    }

    public function testValidateAttendanceStatusWithValidStatus()
    {
        $result = ValidationHelper::validateAttendanceStatus('present');
        
        $this->assertTrue($result['success']);
        $this->assertEquals('present', $result['data']);
        $this->assertEquals('Attendance status validation passed', $result['message']);
    }

    public function testValidateAttendanceStatusWithAllValidStatuses()
    {
        $validStatuses = ['present', 'absent', 'late'];
        
        foreach ($validStatuses as $status) {
            $result = ValidationHelper::validateAttendanceStatus($status);
            $this->assertTrue($result['success'], "Status {$status} should be valid");
            $this->assertEquals($status, $result['data']);
        }
    }

    public function testValidateAttendanceStatusWithEmptyRequired()
    {
        $result = ValidationHelper::validateAttendanceStatus('', true);
        
        $this->assertFalse($result['success']);
        $this->assertContains('Attendance status is required', $result['errors']);
    }

    public function testValidateAttendanceStatusWithEmptyNotRequired()
    {
        $result = ValidationHelper::validateAttendanceStatus('', false);
        
        $this->assertTrue($result['success']);
        $this->assertEquals('', $result['data']);
    }

    public function testValidateAttendanceStatusWithInvalidStatus()
    {
        $result = ValidationHelper::validateAttendanceStatus('invalid');
        
        $this->assertFalse($result['success']);
        $this->assertContains('Attendance status must be one of: present, absent, late', $result['errors']);
    }

    public function testValidateUserTypeWithValidType()
    {
        $result = ValidationHelper::validateUserType('admin');
        
        $this->assertTrue($result['success']);
        $this->assertEquals('admin', $result['data']);
        $this->assertEquals('User type validation passed', $result['message']);
    }

    public function testValidateUserTypeWithAllValidTypes()
    {
        $validTypes = ['admin', 'teacher', 'student'];
        
        foreach ($validTypes as $type) {
            $result = ValidationHelper::validateUserType($type);
            $this->assertTrue($result['success'], "Type {$type} should be valid");
            $this->assertEquals($type, $result['data']);
        }
    }

    public function testValidateUserTypeWithEmptyRequired()
    {
        $result = ValidationHelper::validateUserType('', true);
        
        $this->assertFalse($result['success']);
        $this->assertContains('User type is required', $result['errors']);
    }

    public function testValidateUserTypeWithEmptyNotRequired()
    {
        $result = ValidationHelper::validateUserType('', false);
        
        $this->assertTrue($result['success']);
        $this->assertEquals('', $result['data']);
    }

    public function testValidateUserTypeWithInvalidType()
    {
        $result = ValidationHelper::validateUserType('invalid');
        
        $this->assertFalse($result['success']);
        $this->assertContains('User type must be one of: admin, teacher, student', $result['errors']);
    }

    public function testSanitizeInputWithNullInput()
    {
        $result = ValidationHelper::sanitizeInput(null);
        
        $this->assertTrue($result['success']);
        $this->assertEquals('', $result['data']);
        $this->assertEquals('Input sanitized', $result['message']);
    }

    public function testSanitizeInputWithBasicString()
    {
        $result = ValidationHelper::sanitizeInput('  Hello World  ');
        
        $this->assertTrue($result['success']);
        $this->assertEquals('Hello World', $result['data']);
    }

    public function testSanitizeInputWithHtmlNotAllowed()
    {
        $result = ValidationHelper::sanitizeInput('<p>Hello <b>World</b></p>', false);
        
        $this->assertTrue($result['success']);
        $this->assertEquals('Hello World', $result['data']);
    }

    public function testSanitizeInputWithHtmlAllowed()
    {
        $result = ValidationHelper::sanitizeInput('<p>Hello <b>World</b></p>', true);
        
        $this->assertTrue($result['success']);
        $this->assertEquals('<p>Hello <b>World</b></p>', $result['data']);
    }

    public function testSanitizeInputWithScriptTags()
    {
        $input = '<script>alert("xss")</script>Hello World';
        $result = ValidationHelper::sanitizeInput($input, false);
        
        $this->assertTrue($result['success']);
        $this->assertEquals('Hello World', $result['data']);
    }

    public function testSanitizeInputWithScriptTagsHtmlAllowed()
    {
        $input = '<p>Hello</p><script>alert("xss")</script><b>World</b>';
        $result = ValidationHelper::sanitizeInput($input, true);
        
        $this->assertTrue($result['success']);
        $this->assertEquals('<p>Hello</p><b>World</b>', $result['data']);
    }

    public function testSanitizeInputWithNullBytes()
    {
        $input = "Hello\0World";
        $result = ValidationHelper::sanitizeInput($input);
        
        $this->assertTrue($result['success']);
        $this->assertEquals('HelloWorld', $result['data']);
    }

    public function testSanitizeInputWithSpecialCharacters()
    {
        $input = '<>&"\'';
        $result = ValidationHelper::sanitizeInput($input, false);
        
        $this->assertTrue($result['success']);
        // strip_tags removes < and > characters, then htmlspecialchars encodes the remaining &"'
        $this->assertEquals('&amp;&quot;&#039;', $result['data']);
    }

    public function testValidateAttendanceDataWithValidData()
    {
        $attendanceData = [
            [
                'student_id' => '507f1f77bcf86cd799439011',
                'status' => 'present',
                'notes' => 'On time'
            ],
            [
                'student_id' => '507f1f77bcf86cd799439012',
                'status' => 'absent'
            ]
        ];

        $result = ValidationHelper::validateAttendanceData($attendanceData);
        
        $this->assertTrue($result['success']);
        $this->assertEquals($attendanceData, $result['data']);
        $this->assertEquals('Attendance data validation passed', $result['message']);
    }

    public function testValidateAttendanceDataWithNonArray()
    {
        $result = ValidationHelper::validateAttendanceData('not-an-array');
        
        $this->assertFalse($result['success']);
        $this->assertContains('Attendance data must be an array', $result['errors']);
    }

    public function testValidateAttendanceDataWithEmptyArray()
    {
        $result = ValidationHelper::validateAttendanceData([]);
        
        $this->assertFalse($result['success']);
        $this->assertContains('Attendance data cannot be empty', $result['errors']);
    }

    public function testValidateAttendanceDataWithNonArrayRecord()
    {
        $attendanceData = [
            'not-an-array'
        ];

        $result = ValidationHelper::validateAttendanceData($attendanceData);
        
        $this->assertFalse($result['success']);
        $this->assertContains('Record at index 0 must be an array', $result['errors']);
    }

    public function testValidateAttendanceDataWithMissingStudentId()
    {
        $attendanceData = [
            [
                'status' => 'present'
            ]
        ];

        $result = ValidationHelper::validateAttendanceData($attendanceData);
        
        $this->assertFalse($result['success']);
        $this->assertContains('Student ID is required for record at index 0', $result['errors']);
    }

    public function testValidateAttendanceDataWithEmptyStudentId()
    {
        $attendanceData = [
            [
                'student_id' => '',
                'status' => 'present'
            ]
        ];

        $result = ValidationHelper::validateAttendanceData($attendanceData);
        
        $this->assertFalse($result['success']);
        $this->assertContains('Student ID is required for record at index 0', $result['errors']);
    }

    public function testValidateAttendanceDataWithInvalidStudentId()
    {
        $attendanceData = [
            [
                'student_id' => 'invalid-id',
                'status' => 'present'
            ]
        ];

        $result = ValidationHelper::validateAttendanceData($attendanceData);
        
        $this->assertFalse($result['success']);
        $this->assertContains('Invalid student ID for record at index 0', $result['errors']);
    }

    public function testValidateAttendanceDataWithMissingStatus()
    {
        $attendanceData = [
            [
                'student_id' => '507f1f77bcf86cd799439011'
            ]
        ];

        $result = ValidationHelper::validateAttendanceData($attendanceData);
        
        $this->assertFalse($result['success']);
        $this->assertContains('Status is required for record at index 0', $result['errors']);
    }

    public function testValidateAttendanceDataWithEmptyStatus()
    {
        $attendanceData = [
            [
                'student_id' => '507f1f77bcf86cd799439011',
                'status' => ''
            ]
        ];

        $result = ValidationHelper::validateAttendanceData($attendanceData);
        
        $this->assertFalse($result['success']);
        $this->assertContains('Status is required for record at index 0', $result['errors']);
    }

    public function testValidateAttendanceDataWithInvalidStatus()
    {
        $attendanceData = [
            [
                'student_id' => '507f1f77bcf86cd799439011',
                'status' => 'invalid'
            ]
        ];

        $result = ValidationHelper::validateAttendanceData($attendanceData);
        
        $this->assertFalse($result['success']);
        $this->assertContains('Invalid status for record at index 0', $result['errors']);
    }

    public function testValidateAttendanceDataWithInvalidNotes()
    {
        $attendanceData = [
            [
                'student_id' => '507f1f77bcf86cd799439011',
                'status' => 'present',
                'notes' => 123
            ]
        ];

        $result = ValidationHelper::validateAttendanceData($attendanceData);
        
        $this->assertFalse($result['success']);
        $this->assertContains('Notes must be a string for record at index 0', $result['errors']);
    }

    public function testValidateAttendanceDataWithMultipleErrors()
    {
        $attendanceData = [
            [
                'student_id' => 'invalid',
                'status' => 'invalid'
            ],
            [
                'student_id' => '',
                'status' => ''
            ]
        ];

        $result = ValidationHelper::validateAttendanceData($attendanceData);
        
        $this->assertFalse($result['success']);
        $this->assertCount(4, $result['errors']);
    }

    public function testValidateModelWithValidModel()
    {
        $model = $this->createMockModel(true);
        
        $result = ValidationHelper::validateModel($model);
        
        $this->assertTrue($result['success']);
        $this->assertEquals($model, $result['data']);
        $this->assertEquals('Model validation passed', $result['message']);
    }

    public function testValidateModelWithInvalidModel()
    {
        $model = $this->createMockModel(false);
        
        $result = ValidationHelper::validateModel($model);
        
        $this->assertFalse($result['success']);
        $this->assertEquals('Model validation failed', $result['message']);
        $this->assertEquals(400, $result['code']);
        $this->assertNotEmpty($result['errors']);
    }

    public function testValidateModelWithNonActiveRecord()
    {
        $result = ValidationHelper::validateModel('not-a-model');
        
        $this->assertFalse($result['success']);
        $this->assertEquals('Invalid model provided', $result['message']);
        $this->assertEquals(400, $result['code']);
    }

    public function testCreateSuccessResponseStructure()
    {
        $result = $this->invokePrivateMethod('createSuccessResponse', ['test data', 'Test message']);
        
        $this->assertTrue($result['success']);
        $this->assertEquals('test data', $result['data']);
        $this->assertEquals('Test message', $result['message']);
        $this->assertEmpty($result['errors']);
    }

    public function testCreateErrorResponseStructure()
    {
        $errors = ['Error 1', 'Error 2'];
        $result = $this->invokePrivateMethod('createErrorResponse', ['Test error', 400, $errors]);
        
        $this->assertFalse($result['success']);
        $this->assertNull($result['data']);
        $this->assertEquals('Test error', $result['message']);
        $this->assertEquals(400, $result['code']);
        $this->assertEquals($errors, $result['errors']);
    }

    public function testExceptionHandlingInEmailValidation()
    {
        // Test with extreme edge case that might cause exception
        $result = ValidationHelper::validateEmail(str_repeat('a', 1000000) . '@test.com');
        
        // Should handle gracefully even with extreme inputs
        $this->assertArrayHasKey('success', $result);
        $this->assertArrayHasKey('code', $result);
    }

    public function testExceptionHandlingInPasswordValidation()
    {
        // Test with extreme input that might cause issues or memory problems
        $result = ValidationHelper::validatePassword(str_repeat('a', 1000000));
        
        $this->assertArrayHasKey('success', $result);
        // Since this might not actually cause an exception, check for either normal response or error response
        if (isset($result['code'])) {
            $this->assertArrayHasKey('code', $result);
        } else {
            // If no exception occurred, it should still be a valid response
            $this->assertTrue($result['success']); // Should pass validation for basic password without special requirements
        }
    }

    public function testExceptionHandlingInNameValidation()
    {
        // Test with extreme input
        $result = ValidationHelper::validateName(str_repeat('a', 1000000));
        
        $this->assertArrayHasKey('success', $result);
        $this->assertArrayHasKey('code', $result);
    }

    public function testExceptionHandlingInDateValidation()
    {
        // Test with malformed date that might cause DateTime exception
        $result = ValidationHelper::validateDate('2025-13-32'); // Invalid date
        
        $this->assertArrayHasKey('success', $result);
        $this->assertArrayHasKey('code', $result);
    }

    public function testExceptionHandlingInObjectIdValidation()
    {
        // Test with extreme input
        $result = ValidationHelper::validateObjectId(str_repeat('a', 1000000));
        
        $this->assertArrayHasKey('success', $result);
        $this->assertArrayHasKey('code', $result);
    }

    public function testExceptionHandlingInAttendanceStatusValidation()
    {
        // Test with extreme input
        $result = ValidationHelper::validateAttendanceStatus(str_repeat('a', 1000000));
        
        $this->assertArrayHasKey('success', $result);
        $this->assertArrayHasKey('code', $result);
    }

    public function testExceptionHandlingInUserTypeValidation()
    {
        // Test with extreme input
        $result = ValidationHelper::validateUserType(str_repeat('a', 1000000));
        
        $this->assertArrayHasKey('success', $result);
        $this->assertArrayHasKey('code', $result);
    }

    public function testExceptionHandlingInSanitizeInput()
    {
        // Test with extreme input that might cause regex issues
        $hugeInput = str_repeat('<script>alert("xss")</script>', 10000);
        $result = ValidationHelper::sanitizeInput($hugeInput);
        
        $this->assertArrayHasKey('success', $result);
        // The method should handle this gracefully, might not throw exception
        if (isset($result['code'])) {
            $this->assertArrayHasKey('code', $result);
        } else {
            // Should succeed in sanitizing even large inputs
            $this->assertTrue($result['success']);
        }
    }

    public function testExceptionHandlingInValidateAttendanceData()
    {
        // Test with malformed data that might cause issues
        $malformedData = [
            str_repeat('x', 100000) => 'invalid'  // Very long key
        ];

        $result = ValidationHelper::validateAttendanceData($malformedData);
        
        $this->assertArrayHasKey('success', $result);
        // This should fail validation normally, not necessarily throw exception
        $this->assertFalse($result['success']);
        if (isset($result['code'])) {
            $this->assertArrayHasKey('code', $result);
        } else {
            // Should have validation errors
            $this->assertNotEmpty($result['errors']);
        }
    }

    // Add a test to specifically test actual exception scenarios
    public function testActualExceptionInPasswordValidation()
    {
        // Create a scenario that might actually cause an exception
        // by testing with null/invalid input types that could cause PHP errors
        $result = ValidationHelper::validatePassword(null);
        
        $this->assertArrayHasKey('success', $result);
        // This should handle null gracefully
        $this->assertFalse($result['success']);
    }

    public function testActualExceptionInSanitizeInput()
    {
        // Test with input that might cause preg_replace to fail
        // Using invalid UTF-8 sequence
        $invalidUtf8 = "\xFF\xFE" . str_repeat('test', 1000);
        $result = ValidationHelper::sanitizeInput($invalidUtf8);
        
        $this->assertArrayHasKey('success', $result);
        // Should handle gracefully
        if (isset($result['code'])) {
            $this->assertEquals(500, $result['code']);
        } else {
            $this->assertTrue($result['success']);
        }
    }

    public function testActualExceptionInValidateAttendanceData()
    {
        // Test with extremely nested or recursive data that might cause stack overflow
        $recursiveData = [];
        for ($i = 0; $i < 10000; $i++) {
            $recursiveData[] = [
                'student_id' => str_repeat('a', 1000),
                'status' => str_repeat('invalid', 1000)
            ];
        }

        $result = ValidationHelper::validateAttendanceData($recursiveData);
        
        $this->assertArrayHasKey('success', $result);
        // This should fail validation or potentially cause memory issues
        if (isset($result['code'])) {
            $this->assertArrayHasKey('code', $result);
        } else {
            $this->assertFalse($result['success']);
        }
    }

    

    

    
    /**
     * Helper method to create a mock CActiveRecord model
     */
    private function createMockModel($isValid = true)
    {
        $model = Mockery::mock('CActiveRecord');
        $model->shouldReceive('validate')
            ->andReturn($isValid);

        if (!$isValid) {
            $errors = [
                'name' => ['Name is required'],
                'email' => ['Email is invalid']
            ];
            $model->shouldReceive('getErrors')
                ->andReturn($errors);
        }

        return $model;
    }

    /**
     * Helper method to invoke private methods for testing
     */
    private function invokePrivateMethod($methodName, array $params = [])
    {
        $reflection = new ReflectionClass('ValidationHelper');
        $method = $reflection->getMethod($methodName);
        $method->setAccessible(true);
        return $method->invokeArgs(null, $params);
    }
}
