<?php
 
use PHPUnit\Framework\TestCase;
use Mockery as m;
use Aws\S3\S3Client;
use Aws\Command;
use Aws\Result;
use Psr\Http\Message\RequestInterface;
use Psr\Http\Message\UriInterface;
 
/**
* @runTestsInSeparateProcesses
* @preserveGlobalState disabled
*/
class S3HelperTest extends Mockery\Adapter\Phpunit\MockeryTestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        
        // Reset the static client before each test
        $reflection = new ReflectionClass('S3Helper');
        $clientProperty = $reflection->getProperty('_client');
        $clientProperty->setAccessible(true);
        $clientProperty->setValue(null, null);
        
        // Clear environment variables
        unset($_ENV['AWS_REGION'], $_ENV['AWS_ACCESS_KEY'], $_ENV['AWS_SECRET'], $_ENV['S3_BUCKET_NAME']);
    }
 
    protected function tearDown(): void
    {
        m::close();
        parent::tearDown();
    }
 
    public function testGetClientSuccess()
    {
        // Setup environment variables - using correct variable names from S3Helper
        $_ENV['AWS_REGION'] = 'us-east-1';
        $_ENV['AWS_ACCESS_KEY'] = 'test-access-key';
        $_ENV['AWS_SECRET'] = 'test-secret-key';
 
        $client = S3Helper::getClient();
        $this->assertInstanceOf(S3Client::class, $client);
        
        // Test singleton - should return same instance
        $client2 = S3Helper::getClient();
        $this->assertSame($client, $client2);
    }
 
    public function testGeneratePUTObjectPreSignedUrlWithDefaultExpiry()
    {
        // Reset client for this test
        $reflection = new ReflectionClass('S3Helper');
        $clientProperty = $reflection->getProperty('_client');
        $clientProperty->setAccessible(true);
        
        $_ENV['AWS_REGION'] = 'us-east-1';
        $_ENV['AWS_ACCESS_KEY'] = 'test-access-key';
        $_ENV['AWS_SECRET'] = 'test-secret-key';
 
        // Mock S3Client
        $mockClient = m::mock(S3Client::class);
        $mockCommand = m::mock(Command::class);
        $mockRequest = m::mock(RequestInterface::class);
        $mockUri = m::mock(UriInterface::class);
 
        // Setup expectations
        $mockClient->shouldReceive('getCommand')
            ->once()
            ->with('PutObject', [
                'Bucket' => 'test-bucket',
                'Key' => 'test-key.txt'
            ])
            ->andReturn($mockCommand);
 
        $mockClient->shouldReceive('createPresignedRequest')
            ->once()
            ->with($mockCommand, '+1 hour')
            ->andReturn($mockRequest);
 
        $mockRequest->shouldReceive('getUri')
            ->once()
            ->andReturn($mockUri);
 
        $mockUri->shouldReceive('__toString')
            ->once()
            ->andReturn('https://test-bucket.s3.amazonaws.com/test-key.txt?presigned=true');
 
        // Set the mock client
        $clientProperty->setValue(null, $mockClient);
 
        $result = S3Helper::generatePUTObjectPreSignedUrl('test-key.txt', 'test-bucket', []);
        
        $this->assertEquals('https://test-bucket.s3.amazonaws.com/test-key.txt?presigned=true', $result);
    }
 
    public function testGeneratePUTObjectPreSignedUrlWithCustomExpiry()
    {
        // Reset client for this test
        $reflection = new ReflectionClass('S3Helper');
        $clientProperty = $reflection->getProperty('_client');
        $clientProperty->setAccessible(true);
        
        $_ENV['AWS_REGION'] = 'us-east-1';
        $_ENV['AWS_ACCESS_KEY'] = 'test-access-key';
        $_ENV['AWS_SECRET'] = 'test-secret-key';
 
        // Mock S3Client
        $mockClient = m::mock(S3Client::class);
        $mockCommand = m::mock(Command::class);
        $mockRequest = m::mock(RequestInterface::class);
        $mockUri = m::mock(UriInterface::class);
 
        // Setup expectations with custom expiry
        $mockClient->shouldReceive('getCommand')
            ->once()
            ->with('PutObject', [
                'Bucket' => 'test-bucket',
                'Key' => 'test-key.txt'
            ])
            ->andReturn($mockCommand);
 
        $mockClient->shouldReceive('createPresignedRequest')
            ->once()
            ->with($mockCommand, '+2 hours')
            ->andReturn($mockRequest);
 
        $mockRequest->shouldReceive('getUri')
            ->once()
            ->andReturn($mockUri);
 
        $mockUri->shouldReceive('__toString')
            ->once()
            ->andReturn('https://test-bucket.s3.amazonaws.com/test-key.txt?presigned=true&expires=2h');
 
        // Set the mock client
        $clientProperty->setValue(null, $mockClient);
 
        $result = S3Helper::generatePUTObjectPreSignedUrl('test-key.txt', 'test-bucket', ['expiry' => '+2 hours']);
        
        $this->assertEquals('https://test-bucket.s3.amazonaws.com/test-key.txt?presigned=true&expires=2h', $result);
    }
 
    public function testGenerateGETObjectPreSignedUrlWithDefaultExpiry()
    {
        // Reset client for this test
        $reflection = new ReflectionClass('S3Helper');
        $clientProperty = $reflection->getProperty('_client');
        $clientProperty->setAccessible(true);
        
        $_ENV['AWS_REGION'] = 'us-east-1';
        $_ENV['AWS_ACCESS_KEY'] = 'test-access-key';
        $_ENV['AWS_SECRET'] = 'test-secret-key';
 
        // Mock S3Client
        $mockClient = m::mock(S3Client::class);
        $mockCommand = m::mock(Command::class);
        $mockRequest = m::mock(RequestInterface::class);
        $mockUri = m::mock(UriInterface::class);
 
        // Setup expectations with default 24 hour expiry
        $mockClient->shouldReceive('getCommand')
            ->once()
            ->with('GetObject', [
                'Bucket' => 'test-bucket',
                'Key' => 'test-file.pdf'
            ])
            ->andReturn($mockCommand);
 
        $mockClient->shouldReceive('createPresignedRequest')
            ->once()
            ->with($mockCommand, '+24 hour')
            ->andReturn($mockRequest);
 
        $mockRequest->shouldReceive('getUri')
            ->once()
            ->andReturn($mockUri);
 
        $mockUri->shouldReceive('__toString')
            ->once()
            ->andReturn('https://test-bucket.s3.amazonaws.com/test-file.pdf?presigned=true');
 
        // Set the mock client
        $clientProperty->setValue(null, $mockClient);
 
        $result = S3Helper::generateGETObjectPreSignedUrl('test-file.pdf', 'test-bucket');
        
        $this->assertEquals('https://test-bucket.s3.amazonaws.com/test-file.pdf?presigned=true', $result);
    }
 
    public function testGenerateGETObjectPreSignedUrlWithCustomOptions()
    {
        // Reset client for this test
        $reflection = new ReflectionClass('S3Helper');
        $clientProperty = $reflection->getProperty('_client');
        $clientProperty->setAccessible(true);
        
        $_ENV['AWS_REGION'] = 'us-west-2';
        $_ENV['AWS_ACCESS_KEY'] = 'test-access-key';
        $_ENV['AWS_SECRET'] = 'test-secret-key';
 
        // Mock S3Client
        $mockClient = m::mock(S3Client::class);
        $mockCommand = m::mock(Command::class);
        $mockRequest = m::mock(RequestInterface::class);
        $mockUri = m::mock(UriInterface::class);
 
        // Setup expectations with custom expiry
        $mockClient->shouldReceive('getCommand')
            ->once()
            ->with('GetObject', [
                'Bucket' => 'my-bucket',
                'Key' => 'documents/report.pdf'
            ])
            ->andReturn($mockCommand);
 
        $mockClient->shouldReceive('createPresignedRequest')
            ->once()
            ->with($mockCommand, '+6 hours')
            ->andReturn($mockRequest);
 
        $mockRequest->shouldReceive('getUri')
            ->once()
            ->andReturn($mockUri);
 
        $mockUri->shouldReceive('__toString')
            ->once()
            ->andReturn('https://my-bucket.s3.us-west-2.amazonaws.com/documents/report.pdf?presigned=true');
 
        // Set the mock client
        $clientProperty->setValue(null, $mockClient);
 
        $result = S3Helper::generateGETObjectPreSignedUrl('documents/report.pdf', 'my-bucket', ['expiry' => '+6 hours']);
        
        $this->assertEquals('https://my-bucket.s3.us-west-2.amazonaws.com/documents/report.pdf?presigned=true', $result);
    }
 
    public function testUploadObjectSuccess()
    {
        // Reset client for this test
        $reflection = new ReflectionClass('S3Helper');
        $clientProperty = $reflection->getProperty('_client');
        $clientProperty->setAccessible(true);
        
        $_ENV['AWS_REGION'] = 'us-east-1';
        $_ENV['AWS_ACCESS_KEY'] = 'test-access-key';
        $_ENV['AWS_SECRET'] = 'test-secret-key';
 
        // Mock S3Client and Result
        $mockClient = m::mock(S3Client::class);
        $mockResult = m::mock(Result::class);
 
        $fileContent = 'This is test file content';
 
        $mockClient->shouldReceive('putObject')
            ->once()
            ->with([
                'Bucket' => 'test-bucket',
                'Key' => 'uploads/test.txt',
                'Body' => $fileContent
            ])
            ->andReturn($mockResult);
 
        // Set the mock client
        $clientProperty->setValue(null, $mockClient);
 
        $result = S3Helper::uploadObject('uploads/test.txt', $fileContent, 'test-bucket');
        
        // Updated expectation to match actual return format
        $this->assertIsArray($result);
        $this->assertTrue($result['success']);
        $this->assertSame($mockResult, $result['data']);
    }

    public function testUploadObjectFailure()
    {
        // Reset client for this test
        $reflection = new ReflectionClass('S3Helper');
        $clientProperty = $reflection->getProperty('_client');
        $clientProperty->setAccessible(true);
        
        $_ENV['AWS_REGION'] = 'us-east-1';
        $_ENV['AWS_ACCESS_KEY'] = 'test-access-key';
        $_ENV['AWS_SECRET'] = 'test-secret-key';
 
        // Mock S3Client
        $mockClient = m::mock(S3Client::class);
 
        $fileContent = 'This is test file content';
        $exceptionMessage = 'S3 upload failed';
 
        $mockClient->shouldReceive('putObject')
            ->once()
            ->with([
                'Bucket' => 'test-bucket',
                'Key' => 'uploads/test.txt',
                'Body' => $fileContent
            ])
            ->andThrow(new Exception($exceptionMessage));
 
        // Set the mock client
        $clientProperty->setValue(null, $mockClient);
 
        $result = S3Helper::uploadObject('uploads/test.txt', $fileContent, 'test-bucket');
        
        // Test failure response format
        $this->assertIsArray($result);
        $this->assertFalse($result['success']);
        $this->assertEquals($exceptionMessage, $result['message']);
    }
 
    public function testDeleteObjectSuccess()
    {
        // Reset client for this test
        $reflection = new ReflectionClass('S3Helper');
        $clientProperty = $reflection->getProperty('_client');
        $clientProperty->setAccessible(true);
        
        $_ENV['AWS_REGION'] = 'eu-west-1';
        $_ENV['AWS_ACCESS_KEY'] = 'test-access-key';
        $_ENV['AWS_SECRET'] = 'test-secret-key';
 
        // Mock S3Client and Result
        $mockClient = m::mock(S3Client::class);
        $mockResult = m::mock(Result::class);
 
        $mockClient->shouldReceive('deleteObject')
            ->once()
            ->with([
                'Bucket' => 'my-test-bucket',
                'Key' => 'files/old-document.pdf'
            ])
            ->andReturn($mockResult);
 
        // Set the mock client
        $clientProperty->setValue(null, $mockClient);
 
        $result = S3Helper::deleteObject('files/old-document.pdf', 'my-test-bucket');
        
        $this->assertSame($mockResult, $result);
    }
 
    public function testGenerateGETObjectUrl()
    {
        $_ENV['S3_BUCKET_NAME'] = 'my-production-bucket';
        $_ENV['AWS_REGION'] = 'us-west-2';
 
        $result = S3Helper::generateGETObjectUrl('images/photo.jpg');
        
        $expected = 'https://my-production-bucket.s3.us-west-2.amazonaws.com/images/photo.jpg';
        $this->assertEquals($expected, $result);
    }
 
    public function testGenerateGETObjectUrlWithSpecialCharacters()
    {
        $_ENV['S3_BUCKET_NAME'] = 'test-bucket-2024';
        $_ENV['AWS_REGION'] = 'ap-southeast-1';
 
        $result = S3Helper::generateGETObjectUrl('documents/file with spaces.pdf');
        
        $expected = 'https://test-bucket-2024.s3.ap-southeast-1.amazonaws.com/documents/file with spaces.pdf';
        $this->assertEquals($expected, $result);
    }
 
    public function testGenerateGETObjectUrlWithNestedPath()
    {
        $_ENV['S3_BUCKET_NAME'] = 'company-assets';
        $_ENV['AWS_REGION'] = 'eu-central-1';
 
        $result = S3Helper::generateGETObjectUrl('users/123/profile/avatar.png');
        
        $expected = 'https://company-assets.s3.eu-central-1.amazonaws.com/users/123/profile/avatar.png';
        $this->assertEquals($expected, $result);
    }
 
    /**
     * Integration test to verify the actual client creation without mocking
     */
    public function testGetClientIntegration()
    {
        $_ENV['AWS_REGION'] = 'us-east-1';
        $_ENV['AWS_ACCESS_KEY'] = 'test-access-key';
        $_ENV['AWS_SECRET'] = 'test-secret-key';
 
        // This will create a real client instance
        $client = S3Helper::getClient();
        $this->assertInstanceOf(S3Client::class, $client);
        
        // Verify singleton behavior
        $client2 = S3Helper::getClient();
        $this->assertSame($client, $client2);
    }
 
    /**
     * Test client configuration
     */
    public function testClientConfiguration()
    {
        $_ENV['AWS_REGION'] = 'eu-west-1';
        $_ENV['AWS_ACCESS_KEY'] = 'AKIA1234567890ABCDEF';
        $_ENV['AWS_SECRET'] = 'abcdef1234567890abcdef1234567890abcdef12';
 
        $client = S3Helper::getClient();
        
        // Test that client is properly configured by checking its region
        $this->assertEquals('eu-west-1', $client->getRegion());
        
        // Test that we can get API version
        $this->assertEquals('2006-03-01', $client->getApi()->getApiVersion());
        
        // Test that the client is working by verifying it's an S3Client instance
        $this->assertInstanceOf(S3Client::class, $client);
    }
 
    /**
     * Test error handling when environment variables are missing
     */
    public function testClientCreationWithMissingEnvironmentVariables()
    {
        // Don't set any environment variables - this should throw an exception
        // because AWS SDK requires a region
        
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Missing required client configuration options: AWS_REGION, AWS_ACCESS_KEY, AWS_SECRET');
        
        S3Helper::getClient();
    }
 
    /**
     * Test uploadObject with empty content
     */
    public function testUploadObjectWithEmptyContent()
    {
        // Reset client for this test
        $reflection = new ReflectionClass('S3Helper');
        $clientProperty = $reflection->getProperty('_client');
        $clientProperty->setAccessible(true);
        
        $_ENV['AWS_REGION'] = 'us-east-1';
        $_ENV['AWS_ACCESS_KEY'] = 'test-access-key';
        $_ENV['AWS_SECRET'] = 'test-secret-key';
 
        // Mock S3Client and Result
        $mockClient = m::mock(S3Client::class);
        $mockResult = m::mock(Result::class);
 
        $mockClient->shouldReceive('putObject')
            ->once()
            ->with([
                'Bucket' => 'test-bucket',
                'Key' => 'empty-file.txt',
                'Body' => ''
            ])
            ->andReturn($mockResult);
 
        // Set the mock client
        $clientProperty->setValue(null, $mockClient);
 
        $result = S3Helper::uploadObject('empty-file.txt', '', 'test-bucket');
        
        // Updated expectation to match actual return format
        $this->assertIsArray($result);
        $this->assertTrue($result['success']);
        $this->assertSame($mockResult, $result['data']);
    }
}