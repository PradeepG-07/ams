<?php

require_once(dirname(__FILE__) . '/../../../../components/helpers/BaseHelper.php');

/**
* @runTestsInSeparateProcesses
* @preserveGlobalState disabled
*/
 
 
use Mockery\Adapter\Phpunit\MockeryTestCase;

class BaseHelperTest extends MockeryTestCase
{
    private $yiiAppMock;

    protected function setUp(): void
    {
        parent::setUp();
        $this->yiiAppMock = new YiiAppMock();
        $this->yiiAppMock->mockApp();
    }

    protected function tearDown(): void
    {
        $this->yiiAppMock->close();
        parent::tearDown();
    }

    public function testBaseHelperClassExists()
    {
        $this->assertTrue(class_exists('BaseHelper'), 'BaseHelper class should exist');
    }

    public function testBaseHelperInheritance()
    {
        $reflection = new ReflectionClass('BaseHelper');
        
        // Check if it extends CComponent or another appropriate base class
        $this->assertTrue(
            $reflection->isSubclassOf('CComponent') || 
            $reflection->getName() === 'CComponent' ||
            $reflection->isSubclassOf('CApplicationComponent'),
            'BaseHelper should extend an appropriate Yii base class'
        );
    }

    public function testBaseHelperHasExpectedMethods()
    {
        $reflection = new ReflectionClass('BaseHelper');
        $methods = $reflection->getMethods(ReflectionMethod::IS_PUBLIC);
        
        // Verify that BaseHelper has some utility methods
        $methodNames = array_map(function($method) {
            return $method->getName();
        }, $methods);
        
        $this->assertIsArray($methodNames, 'BaseHelper should have public methods');
        
        // Test that inherited methods from CComponent are available
        if ($reflection->isSubclassOf('CComponent')) {
            $this->assertContains('__get', $methodNames, 'Should inherit __get from CComponent');
            $this->assertContains('__set', $methodNames, 'Should inherit __set from CComponent');
        }
    }

    public function testBaseHelperCanBeInstantiated()
    {
        try {
            $instance = new BaseHelper();
            $this->assertInstanceOf('BaseHelper', $instance);
            $this->assertInstanceOf('CComponent', $instance);
        } catch (Exception $e) {
            // If BaseHelper is abstract or static-only, this test should reflect that
            $this->markTestSkipped('BaseHelper cannot be instantiated: ' . $e->getMessage());
        }
    }

    public function testBaseHelperStaticUtilities()
    {
        $reflection = new ReflectionClass('BaseHelper');
        $staticMethods = $reflection->getMethods(ReflectionMethod::IS_STATIC | ReflectionMethod::IS_PUBLIC);
        
        // Filter out inherited methods that shouldn't be tested as static
        $ownStaticMethods = [];
        foreach ($staticMethods as $method) {
            if ($method->getDeclaringClass()->getName() === 'BaseHelper') {
                $ownStaticMethods[] = $method;
            }
        }
        
        foreach ($ownStaticMethods as $method) {
            // Test that static methods exist and can be called
            $this->assertTrue($method->isStatic(), "Method {$method->getName()} should be static");
            
            // Only test methods with no required parameters
            if ($method->getNumberOfRequiredParameters() === 0) {
                try {
                    $result = $method->invoke(null);
                    $this->assertTrue(true, "Static method {$method->getName()} executed successfully");
                } catch (Exception $e) {
                    // Some methods might have specific requirements
                    $this->assertTrue(true, "Static method {$method->getName()} exists but may require specific conditions");
                }
            }
        }
        
        // Ensure we have at least one static method
        $this->assertGreaterThan(0, count($ownStaticMethods), 'BaseHelper should have static methods');
    }

    public function testBaseHelperConstants()
    {
        $reflection = new ReflectionClass('BaseHelper');
        $constants = $reflection->getConstants();
        
        // Test that we have expected constants
        $this->assertArrayHasKey('VERSION', $constants, 'Should have VERSION constant');
        $this->assertArrayHasKey('DEFAULT_ENCODING', $constants, 'Should have DEFAULT_ENCODING constant');
        
        foreach ($constants as $name => $value) {
            $this->assertIsString($name, 'Constant name should be string');
            $this->assertNotEmpty($name, 'Constant name should not be empty');
        }
    }

    public function testBaseHelperProperties()
    {
        $reflection = new ReflectionClass('BaseHelper');
        $properties = $reflection->getProperties();
        
        foreach ($properties as $property) {
            $this->assertIsString($property->getName(), 'Property name should be string');
            
            if ($property->isStatic() && $property->isPublic()) {
                $value = $property->getValue();
                $this->assertTrue(true, "Static property {$property->getName()} is accessible");
            }
        }
        
        // Test passes if no exceptions
        $this->assertTrue(true, 'Properties are accessible');
    }

    public function testBaseHelperIntegrationWithYii()
    {
        // Test that BaseHelper works properly with Yii framework
        if (class_exists('BaseHelper')) {
            $reflection = new ReflectionClass('BaseHelper');
            
            // If it extends CComponent, test component behavior
            if ($reflection->isSubclassOf('CComponent')) {
                try {
                    $instance = new BaseHelper();
                    
                    // Test basic CComponent functionality
                    $this->assertTrue(method_exists($instance, '__get'), 'Should have magic getter');
                    $this->assertTrue(method_exists($instance, '__set'), 'Should have magic setter');
                    $this->assertTrue(method_exists($instance, 'hasProperty'), 'Should have hasProperty method');
                    
                } catch (Exception $e) {
                    $this->markTestSkipped('Cannot test BaseHelper integration: ' . $e->getMessage());
                }
            }
        }
        
        $this->assertTrue(true, 'Integration test completed');
    }

    public function testBaseHelperErrorHandling()
    {
        // Test that BaseHelper methods handle errors gracefully
        if (class_exists('BaseHelper')) {
            $reflection = new ReflectionClass('BaseHelper');
            $methods = $reflection->getMethods(ReflectionMethod::IS_PUBLIC);
            
            foreach ($methods as $method) {
                if ($method->isStatic() && $method->getNumberOfRequiredParameters() === 0) {
                    try {
                        $method->invoke(null);
                        $this->assertTrue(true, "Method {$method->getName()} handles execution without errors");
                    } catch (Exception $e) {
                        // Ensure exceptions are appropriate types
                        $this->assertInstanceOf('Exception', $e, 'Should throw proper exceptions');
                    }
                }
            }
        }
        
        $this->assertTrue(true, 'Error handling test completed');
    }

    public function testBaseHelperStaticMethodsWork()
    {
        // Test specific static methods
        $this->assertEquals('1.0.0', BaseHelper::getVersion());
        $this->assertEquals('UTF-8', BaseHelper::getEncoding());
        $this->assertTrue(BaseHelper::isAvailable());
    }
}