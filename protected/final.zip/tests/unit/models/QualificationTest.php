<?php
 
/**
* @runTestsInSeparateProcesses
* @preserveGlobalState disabled
*/
 
 
use Mockery as m;
use \Mockery\Adapter\Phpunit\MockeryTestCase;

class QualificationTest extends MockeryTestCase
{
    protected $qualification;
    
    protected function setUp(): void
    {
        // Partial mock to avoid calling parent constructor or DB connection
        $this->qualification = m::mock(Qualification::class)->makePartial();
    }
    
    public function testGetCollectionName()
    {
        $this->assertEquals('qualifications', $this->qualification->getCollectionName());
    }
    
    public function testRules()
    {
        $rules = $this->qualification->rules();
        $this->assertIsArray($rules);
        
        // Test that we have exactly the expected number of rules
        $this->assertCount(4, $rules);
        
        // Check that required rule contains expected fields
        $foundRequired = false;
        foreach ($rules as $rule) {
            if ($rule[1] === 'required' && $rule[0] === '_id degree, field, institute, year, grade') {
                $foundRequired = true;
                break;
            }
        }
        $this->assertTrue($foundRequired, 'Required rule for qualification fields not found');
        
        // Check length validation for text fields
        $foundLengthRule = false;
        foreach ($rules as $rule) {
            if ($rule[1] === 'length' && $rule[0] === 'degree, field, institute' && $rule['max'] === 255) {
                $foundLengthRule = true;
                break;
            }
        }
        $this->assertTrue($foundLengthRule, 'Length validation rule for degree, field, institute not found');
        
        // Check year numerical validation
        $foundYearRule = false;
        foreach ($rules as $rule) {
            if ($rule[0] === 'year' && $rule[1] === 'numerical' && $rule['integerOnly'] === true) {
                $foundYearRule = true;
                break;
            }
        }
        $this->assertTrue($foundYearRule, 'Year numerical validation rule not found');
        
        // Check grade numerical validation
        $foundGradeRule = false;
        foreach ($rules as $rule) {
            if ($rule[0] === 'grade' && $rule[1] === 'numerical') {
                $foundGradeRule = true;
                break;
            }
        }
        $this->assertTrue($foundGradeRule, 'Grade numerical validation rule not found');
    }
    
    public function testPublicProperties()
    {
        // Test that all expected public properties exist
        $expectedProperties = [
            'degree', 'field', 'institute', 'year', 'grade'
        ];
        
        foreach ($expectedProperties as $property) {
            $this->assertTrue(property_exists($this->qualification, $property), "Property {$property} does not exist");
        }
        
        // Test that we can set and get these properties
        $this->qualification->degree = 'PhD';
        $this->qualification->field = 'Computer Science';
        $this->qualification->institute = 'MIT';
        $this->qualification->year = 2020;
        $this->qualification->grade = 3.8;
        
        $this->assertEquals('PhD', $this->qualification->degree);
        $this->assertEquals('Computer Science', $this->qualification->field);
        $this->assertEquals('MIT', $this->qualification->institute);
        $this->assertEquals(2020, $this->qualification->year);
        $this->assertEquals(3.8, $this->qualification->grade);
    }
    
    public function testRequiredFields()
    {
        // Test that required fields are properly identified
        $rules = $this->qualification->rules();
        $requiredFields = null;
        
        foreach ($rules as $rule) {
            if ($rule[1] === 'required') {
                $requiredFields = explode(', ', $rule[0]);
                break;
            }
        }
        
        $this->assertNotNull($requiredFields);
        $expectedRequired = ['_id degree', 'field', 'institute', 'year', 'grade'];
        $this->assertEquals($expectedRequired, $requiredFields);
    }
    
    public function testNumericalValidation()
    {
        // Test year numerical validation
        $rules = $this->qualification->rules();
        $yearRule = null;
        $gradeRule = null;
        
        foreach ($rules as $rule) {
            if ($rule[0] === 'year' && $rule[1] === 'numerical') {
                $yearRule = $rule;
            }
            if ($rule[0] === 'grade' && $rule[1] === 'numerical') {
                $gradeRule = $rule;
            }
        }
        
        $this->assertNotNull($yearRule);
        $this->assertNotNull($gradeRule);
        
        // Test that year has integerOnly constraint
        $this->assertTrue(isset($yearRule['integerOnly']) && $yearRule['integerOnly'] === true);
        
        // Test that grade doesn't have integerOnly constraint (can be decimal)
        $this->assertFalse(isset($gradeRule['integerOnly']));
    }
    
    public function testLengthValidation()
    {
        // Test that length rules are properly defined
        $rules = $this->qualification->rules();
        $lengthRule = null;
        
        foreach ($rules as $rule) {
            if ($rule[1] === 'length' && isset($rule['max']) && $rule['max'] === 255) {
                $lengthRule = $rule;
                break;
            }
        }
        
        $this->assertNotNull($lengthRule);
        $lengthFields = explode(', ', $lengthRule[0]);
        $expectedLengthFields = ['degree', 'field', 'institute'];
        $this->assertEquals($expectedLengthFields, $lengthFields);
        
        // Test that year and grade are not in length validation (they have numerical validation)
        $this->assertNotContains('year', $lengthFields);
        $this->assertNotContains('grade', $lengthFields);
    }
    
    public function testMethodsExistence()
    {
        // Test that all required methods exist
        $requiredMethods = ['rules', 'getCollectionName'];
        
        foreach ($requiredMethods as $method) {
            $this->assertTrue(method_exists($this->qualification, $method), "Method {$method} does not exist");
        }
    }
    
    public function testEmbeddedDocumentNature()
    {
        // Test that Qualification extends EMongoEmbeddedDocument
        $this->assertInstanceOf('EMongoEmbeddedDocument', $this->qualification);
        
        // Note: This model has getCollectionName which is unusual for embedded documents
        // but we test what's actually implemented
        $this->assertTrue(method_exists($this->qualification, 'getCollectionName'));
    }
    
    public function testValidDataTypes()
    {
        // Test setting valid data types
        $this->qualification->degree = 'Masters';
        $this->qualification->field = 'Engineering';
        $this->qualification->institute = 'Stanford University';
        $this->qualification->year = 2021;
        $this->qualification->grade = 85.5;
        
        $this->assertIsString($this->qualification->degree);
        $this->assertIsString($this->qualification->field);
        $this->assertIsString($this->qualification->institute);
        $this->assertIsInt($this->qualification->year);
        $this->assertIsFloat($this->qualification->grade);
    }
    
    public function testCommonQualificationScenarios()
    {
        // Test Bachelor's degree scenario
        $this->qualification->degree = 'Bachelor';
        $this->qualification->field = 'Business Administration';
        $this->qualification->institute = 'Harvard Business School';
        $this->qualification->year = 2018;
        $this->qualification->grade = 92.0;
        
        $this->assertEquals('Bachelor', $this->qualification->degree);
        $this->assertEquals('Business Administration', $this->qualification->field);
        $this->assertEquals('Harvard Business School', $this->qualification->institute);
        $this->assertEquals(2018, $this->qualification->year);
        $this->assertEquals(92.0, $this->qualification->grade);
        
        // Test PhD scenario
        $this->qualification->degree = 'PhD';
        $this->qualification->field = 'Physics';
        $this->qualification->institute = 'Caltech';
        $this->qualification->year = 2023;
        $this->qualification->grade = 4.0;
        
        $this->assertEquals('PhD', $this->qualification->degree);
        $this->assertEquals('Physics', $this->qualification->field);
        $this->assertEquals('Caltech', $this->qualification->institute);
        $this->assertEquals(2023, $this->qualification->year);
        $this->assertEquals(4.0, $this->qualification->grade);
    }
    
    public function testRulesStructure()
    {
        // Test that all rules have proper structure
        $rules = $this->qualification->rules();
        
        foreach ($rules as $rule) {
            $this->assertIsArray($rule);
            $this->assertGreaterThanOrEqual(2, count($rule)); // At least field and validator
            $this->assertIsString($rule[0]); // Field name(s)
            $this->assertIsString($rule[1]); // Validator name
        }
    }
}