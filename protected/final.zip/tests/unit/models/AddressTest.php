<?php
 
/**
* @runTestsInSeparateProcesses
* @preserveGlobalState disabled
*/
 
 
use Mockery as m;
use \Mockery\Adapter\Phpunit\MockeryTestCase;

class AddressTest extends MockeryTestCase
{
    protected $address;
    
    protected function setUp(): void
    {
        // Partial mock to avoid calling parent constructor or DB connection
        $this->address = m::mock(Address::class)->makePartial();
    }
    
    public function testRules()
    {
        $rules = $this->address->rules();
        $this->assertIsArray($rules);
        
        // Test that we have exactly the expected number of rules
        $this->assertCount(3, $rules);
        
        // Check that required rule contains expected fields
        $foundRequired = false;
        foreach ($rules as $rule) {
            if ($rule[1] === 'required' && $rule[0] === 'address_line1, city, state, zip, country') {
                $foundRequired = true;
                break;
            }
        }
        $this->assertTrue($foundRequired, 'Required rule for address fields not found');
        
        // Check zip pattern validation rule
        $foundZipRule = false;
        foreach ($rules as $rule) {
            if ($rule[0] === 'zip' && $rule[1] === 'match' && $rule['pattern'] === '/^[0-9\-]{4,10}$/') {
                $foundZipRule = true;
                break;
            }
        }
        $this->assertTrue($foundZipRule, 'ZIP pattern validation rule not found');
        
        // Check length validation for address fields
        $foundLengthRule = false;
        foreach ($rules as $rule) {
            if ($rule[1] === 'length' && $rule[0] === 'address_line1, address_line2, city, state, country' && $rule['max'] === 100) {
                $foundLengthRule = true;
                break;
            }
        }
        $this->assertTrue($foundLengthRule, 'Length validation rule for address fields not found');
    }
    
    public function testAttributeLabels()
    {
        $labels = $this->address->attributeLabels();
        $expectedLabels = [
            'address_line1' => 'Address Line 1',
            'address_line2' => 'Address Line 2',
            'city' => 'City',
            'state' => 'State',
            'zip' => 'ZIP Code',
            'country' => 'Country',
        ];
        
        $this->assertIsArray($labels);
        $this->assertEquals($expectedLabels, $labels);
        $this->assertCount(6, $labels);
    }
    
    public function testPublicProperties()
    {
        // Test that all expected public properties exist
        $expectedProperties = [
            'address_line1', 'address_line2', 'city', 'state', 'zip', 'country'
        ];
        
        foreach ($expectedProperties as $property) {
            $this->assertTrue(property_exists($this->address, $property), "Property {$property} does not exist");
        }
        
        // Test that we can set and get these properties
        $this->address->address_line1 = '123 Main St';
        $this->address->address_line2 = 'Apt 4B';
        $this->address->city = 'New York';
        $this->address->state = 'NY';
        $this->address->zip = '10001';
        $this->address->country = 'USA';
        
        $this->assertEquals('123 Main St', $this->address->address_line1);
        $this->assertEquals('Apt 4B', $this->address->address_line2);
        $this->assertEquals('New York', $this->address->city);
        $this->assertEquals('NY', $this->address->state);
        $this->assertEquals('10001', $this->address->zip);
        $this->assertEquals('USA', $this->address->country);
    }
    
    public function testValidZipCodes()
    {
        // Test various valid ZIP code formats
        $validZips = ['12345', '12345-6789', '1234', '123456789', '12-34'];
        
        foreach ($validZips as $zip) {
            $this->address->zip = $zip;
            // Check if zip matches the pattern from rules
            $pattern = '/^[0-9\-]{4,10}$/';
            $this->assertEquals(1, preg_match($pattern, $zip), "ZIP code {$zip} should be valid");
        }
    }
    
    public function testInvalidZipCodes()
    {
        // Test various invalid ZIP code formats based on pattern /^[0-9\-]{4,10}$/
        // The pattern allows digits and hyphens, length 4-10, so we test actual invalid cases
        $invalidZips = ['123', '12345678901', 'ABCDE', '123 45', '123ab', 'ab123'];
        
        foreach ($invalidZips as $zip) {
            $this->address->zip = $zip;
            // Check if zip doesn't match the pattern from rules
            $pattern = '/^[0-9\-]{4,10}$/';
            $this->assertEquals(0, preg_match($pattern, $zip), "ZIP code {$zip} should be invalid");
        }
    }
    
    public function testRequiredFields()
    {
        // Test that required fields are properly identified
        $rules = $this->address->rules();
        $requiredFields = null;
        
        foreach ($rules as $rule) {
            if ($rule[1] === 'required') {
                $requiredFields = explode(', ', $rule[0]);
                break;
            }
        }
        
        $this->assertNotNull($requiredFields);
        $expectedRequired = ['address_line1', 'city', 'state', 'zip', 'country'];
        $this->assertEquals($expectedRequired, $requiredFields);
        
        // Test that address_line2 is not required
        $this->assertNotContains('address_line2', $requiredFields);
    }
    
    public function testMethodsExistence()
    {
        // Test that all required methods exist
        $requiredMethods = ['rules', 'attributeLabels'];
        
        foreach ($requiredMethods as $method) {
            $this->assertTrue(method_exists($this->address, $method), "Method {$method} does not exist");
        }
    }
    
    public function testEmbeddedDocumentNature()
    {
        // Test that Address extends EMongoEmbeddedDocument
        $this->assertInstanceOf('EMongoEmbeddedDocument', $this->address);
        
        // Test that Address doesn't have static model method (embedded documents shouldn't)
        $this->assertFalse(method_exists('Address', 'model'), 'Embedded documents should not have static model method');
        
        // Test that Address doesn't have getCollectionName method (embedded documents shouldn't)
        $this->assertFalse(method_exists($this->address, 'getCollectionName'), 'Embedded documents should not have getCollectionName method');
    }
    
    public function testLengthLimitations()
    {
        // Test that length rules are properly defined
        $rules = $this->address->rules();
        $lengthRule = null;
        
        foreach ($rules as $rule) {
            if ($rule[1] === 'length' && isset($rule['max']) && $rule['max'] === 100) {
                $lengthRule = $rule;
                break;
            }
        }
        
        $this->assertNotNull($lengthRule);
        $lengthFields = explode(', ', $lengthRule[0]);
        $expectedLengthFields = ['address_line1', 'address_line2', 'city', 'state', 'country'];
        $this->assertEquals($expectedLengthFields, $lengthFields);
        
        // Test that zip is not in length validation (it has its own pattern validation)
        $this->assertNotContains('zip', $lengthFields);
    }
}