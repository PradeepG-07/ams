<?php
 
/**
* @runTestsInSeparateProcesses
* @preserveGlobalState disabled
*/
 
 
use Mockery as m;
use \Mockery\Adapter\Phpunit\MockeryTestCase;

class ClassRoomTest extends MockeryTestCase
{
    protected $classRoom;
    
    protected function setUp(): void
    {
        // Partial mock to avoid calling parent constructor or DB connection
        $this->classRoom = m::mock(ClassRoom::class)->makePartial();
    }
    
    public function testGetCollectionName()
    {
        $this->assertEquals('classrooms', $this->classRoom->getCollectionName());
    }
    
    public function testRules()
    {
        $rules = $this->classRoom->rules();
        $this->assertIsArray($rules);
        
        // Test that we have exactly the expected number of rules
        $this->assertCount(5, $rules);
        
        // Check that required rule contains expected fields
        $foundRequired = false;
        foreach ($rules as $rule) {
            if ($rule[1] === 'required' && $rule[0] === 'class_name, class_teacher_id, subject, academic_year') {
                $foundRequired = true;
                break;
            }
        }
        $this->assertTrue($foundRequired, 'Required rule for class_name, class_teacher_id, subject, academic_year not found');
        
        // Check class_name length validation
        $foundClassNameRule = false;
        foreach ($rules as $rule) {
            if ($rule[0] === 'class_name' && $rule[1] === 'length' && $rule['max'] === 255) {
                $foundClassNameRule = true;
                break;
            }
        }
        $this->assertTrue($foundClassNameRule, 'Class name length validation rule not found');
        
        // Check safe rule for students and attendance
        $foundSafeRule = false;
        foreach ($rules as $rule) {
            if ($rule[0] === 'students,attendance' && $rule[1] === 'safe') {
                $foundSafeRule = true;
                break;
            }
        }
        $this->assertTrue($foundSafeRule, 'Safe rule for students,attendance not found');
        
        // Check subject length validation
        $foundSubjectRule = false;
        foreach ($rules as $rule) {
            if ($rule[0] === 'subject' && $rule[1] === 'length' && $rule['max'] === 100) {
                $foundSubjectRule = true;
                break;
            }
        }
        $this->assertTrue($foundSubjectRule, 'Subject length validation rule not found');
        
        // Check academic_year length validation
        $foundAcademicYearRule = false;
        foreach ($rules as $rule) {
            if ($rule[0] === 'academic_year' && $rule[1] === 'length' && $rule['max'] === 20) {
                $foundAcademicYearRule = true;
                break;
            }
        }
        $this->assertTrue($foundAcademicYearRule, 'Academic year length validation rule not found');
    }
    
    public function testAttributeLabels()
    {
        $labels = $this->classRoom->attributeLabels();
        $expectedLabels = [
            'class_name' => 'Class Name',
            'class_teacher_id' => 'Class Teacher ID',
            'students' => 'Students',
            'subject' => 'Subject',
            'academic_year' => 'Academic Year',
        ];
        
        $this->assertIsArray($labels);
        $this->assertEquals($expectedLabels, $labels);
        $this->assertCount(5, $labels);
    }
    
    public function testStaticModelReturnsInstance()
    {
        // Create a real instance for this test since we need to test the static method
        $modelInstance = ClassRoom::model();
        $this->assertInstanceOf('ClassRoom', $modelInstance);
    }
    
    public function testPublicProperties()
    {
        // Test that all expected public properties exist
        $expectedProperties = [
            'class_name', 'class_teacher_id', 'students', 'subject', 'academic_year', 'attendance'
        ];
        
        foreach ($expectedProperties as $property) {
            $this->assertTrue(property_exists($this->classRoom, $property), "Property {$property} does not exist");
        }
        
        // Test that we can set and get these properties
        $this->classRoom->class_name = 'Grade 10A';
        $this->classRoom->class_teacher_id = 'teacher123';
        $this->classRoom->students = ['student1', 'student2'];
        $this->classRoom->subject = 'Mathematics';
        $this->classRoom->academic_year = '2023-2024';
        $this->classRoom->attendance = ['2023-01-01' => ['student1', 'student2']];
        
        $this->assertEquals('Grade 10A', $this->classRoom->class_name);
        $this->assertEquals('teacher123', $this->classRoom->class_teacher_id);
        $this->assertEquals(['student1', 'student2'], $this->classRoom->students);
        $this->assertEquals('Mathematics', $this->classRoom->subject);
        $this->assertEquals('2023-2024', $this->classRoom->academic_year);
        $this->assertEquals(['2023-01-01' => ['student1', 'student2']], $this->classRoom->attendance);
    }
    
    public function testArrayProperties()
    {
        // Test that students and attendance are initialized as arrays
        $this->classRoom->students = [];
        $this->classRoom->attendance = [];
        
        $this->assertIsArray($this->classRoom->students);
        $this->assertIsArray($this->classRoom->attendance);
        $this->assertEquals([], $this->classRoom->students);
        $this->assertEquals([], $this->classRoom->attendance);
        
        // Test adding students
        $this->classRoom->students = ['student1', 'student2', 'student3'];
        $this->assertCount(3, $this->classRoom->students);
        $this->assertContains('student1', $this->classRoom->students);
        $this->assertContains('student2', $this->classRoom->students);
        $this->assertContains('student3', $this->classRoom->students);
        
        // Test attendance tracking
        $this->classRoom->attendance = [
            '2023-01-01' => ['student1', 'student2'],
            '2023-01-02' => ['student1', 'student3'],
        ];
        $this->assertCount(2, $this->classRoom->attendance);
        $this->assertArrayHasKey('2023-01-01', $this->classRoom->attendance);
        $this->assertArrayHasKey('2023-01-02', $this->classRoom->attendance);
    }
    
    public function testRequiredFields()
    {
        // Test that required fields are properly identified
        $rules = $this->classRoom->rules();
        $requiredFields = null;
        
        foreach ($rules as $rule) {
            if ($rule[1] === 'required') {
                $requiredFields = explode(', ', $rule[0]);
                break;
            }
        }
        
        $this->assertNotNull($requiredFields);
        $expectedRequired = ['class_name', 'class_teacher_id', 'subject', 'academic_year'];
        $this->assertEquals($expectedRequired, $requiredFields);
        
        // Test that students and attendance are not required (they're safe)
        $this->assertNotContains('students', $requiredFields);
        $this->assertNotContains('attendance', $requiredFields);
    }
    
    public function testLengthValidations()
    {
        $rules = $this->classRoom->rules();
        
        // Check class_name max length
        $classNameRule = null;
        $subjectRule = null;
        $academicYearRule = null;
        
        foreach ($rules as $rule) {
            if ($rule[0] === 'class_name' && $rule[1] === 'length') {
                $classNameRule = $rule;
            }
            if ($rule[0] === 'subject' && $rule[1] === 'length') {
                $subjectRule = $rule;
            }
            if ($rule[0] === 'academic_year' && $rule[1] === 'length') {
                $academicYearRule = $rule;
            }
        }
        
        $this->assertNotNull($classNameRule);
        $this->assertEquals(255, $classNameRule['max']);
        
        $this->assertNotNull($subjectRule);
        $this->assertEquals(100, $subjectRule['max']);
        
        $this->assertNotNull($academicYearRule);
        $this->assertEquals(20, $academicYearRule['max']);
    }
    
    public function testSafeFields()
    {
        $rules = $this->classRoom->rules();
        $safeRule = null;
        
        foreach ($rules as $rule) {
            if ($rule[1] === 'safe') {
                $safeRule = $rule;
                break;
            }
        }
        
        $this->assertNotNull($safeRule);
        $this->assertEquals('students,attendance', $safeRule[0]);
    }
    
    public function testMethodsExistence()
    {
        // Test that all required methods exist
        $requiredMethods = [
            'getCollectionName', 'rules', 'attributeLabels'
        ];
        
        foreach ($requiredMethods as $method) {
            $this->assertTrue(method_exists($this->classRoom, $method), "Method {$method} does not exist");
        }
        
        // Test that static model method exists
        $this->assertTrue(method_exists('ClassRoom', 'model'), 'Static model method does not exist');
    }
    
    public function testDocumentNature()
    {
        // Test that ClassRoom extends EMongoDocument
        $this->assertInstanceOf('EMongoDocument', $this->classRoom);
        
        // Test that ClassRoom has getCollectionName method (regular documents should have this)
        $this->assertTrue(method_exists($this->classRoom, 'getCollectionName'));
    }
    
    public function testCommonClassRoomScenarios()
    {
        // Test elementary school scenario
        $this->classRoom->class_name = 'Grade 3B';
        $this->classRoom->class_teacher_id = 'teacher_001';
        $this->classRoom->subject = 'General Studies';
        $this->classRoom->academic_year = '2023-24';
        $this->classRoom->students = ['student_001', 'student_002', 'student_003'];
        
        $this->assertEquals('Grade 3B', $this->classRoom->class_name);
        $this->assertEquals('teacher_001', $this->classRoom->class_teacher_id);
        $this->assertEquals('General Studies', $this->classRoom->subject);
        $this->assertEquals('2023-24', $this->classRoom->academic_year);
        $this->assertCount(3, $this->classRoom->students);
        
        // Test high school scenario
        $this->classRoom->class_name = 'AP Physics';
        $this->classRoom->class_teacher_id = 'teacher_physics';
        $this->classRoom->subject = 'Advanced Physics';
        $this->classRoom->academic_year = '2023-2024';
        $this->classRoom->students = ['student_101', 'student_102'];
        
        $this->assertEquals('AP Physics', $this->classRoom->class_name);
        $this->assertEquals('teacher_physics', $this->classRoom->class_teacher_id);
        $this->assertEquals('Advanced Physics', $this->classRoom->subject);
        $this->assertEquals('2023-2024', $this->classRoom->academic_year);
        $this->assertCount(2, $this->classRoom->students);
    }
    
    public function testAttendanceTracking()
    {
        // Test attendance tracking functionality
        $this->classRoom->students = ['student1', 'student2', 'student3'];
        $this->classRoom->attendance = [];
        
        // Add attendance for different days
        $this->classRoom->attendance['2023-01-01'] = ['student1', 'student2'];
        $this->classRoom->attendance['2023-01-02'] = ['student1', 'student3'];
        $this->classRoom->attendance['2023-01-03'] = ['student1', 'student2', 'student3'];
        
        $this->assertCount(3, $this->classRoom->attendance);
        $this->assertEquals(['student1', 'student2'], $this->classRoom->attendance['2023-01-01']);
        $this->assertEquals(['student1', 'student3'], $this->classRoom->attendance['2023-01-02']);
        $this->assertEquals(['student1', 'student2', 'student3'], $this->classRoom->attendance['2023-01-03']);
        
        // Test perfect attendance day
        $perfectAttendanceDay = '2023-01-03';
        $this->assertCount(3, $this->classRoom->attendance[$perfectAttendanceDay]);
        $this->assertEquals(count($this->classRoom->students), count($this->classRoom->attendance[$perfectAttendanceDay]));
    }
    
    public function testRulesValidation()
    {
        // Test that all rules have proper structure
        $rules = $this->classRoom->rules();
        
        foreach ($rules as $rule) {
            $this->assertIsArray($rule);
            $this->assertGreaterThanOrEqual(2, count($rule)); // At least field and validator
            $this->assertIsString($rule[0]); // Field name(s)
            $this->assertIsString($rule[1]); // Validator name
        }
        
        // Test specific rule configurations
        $lengthRules = array_filter($rules, function($rule) {
            return $rule[1] === 'length';
        });
        
        foreach ($lengthRules as $rule) {
            $this->assertArrayHasKey('max', $rule);
            $this->assertIsInt($rule['max']);
        }
    }
}