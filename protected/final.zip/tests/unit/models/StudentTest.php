<?php
 
/**
* @runTestsInSeparateProcesses
* @preserveGlobalState disabled
*/
 
 
use Mockery as m;
use \Mockery\Adapter\Phpunit\MockeryTestCase;

class StudentTest extends MockeryTestCase
{
    protected $student;
    
    protected function setUp(): void
    {
        // Partial mock to avoid calling parent constructor or DB connection
        $this->student = m::mock(Student::class)->makePartial();
    }
    
    public function testGetCollectionName()
    {
        $this->assertEquals('students', $this->student->getCollectionName());
    }
    
    public function testRules()
    {
        $rules = $this->student->rules();
        $this->assertIsArray($rules);
        
        // Test that we have exactly the expected number of rules
        $this->assertCount(10, $rules);
        
        // Check that required rule contains email and password
        $foundRequired = false;
        foreach ($rules as $rule) {
            if ($rule[1] === 'required' && $rule[0] === 'email, password') {
                $foundRequired = true;
                break;
            }
        }
        $this->assertTrue($foundRequired, 'Required rule for email, password not found');
        
        // Check email validation rule
        $foundEmailRule = false;
        foreach ($rules as $rule) {
            if ($rule[0] === 'email' && $rule[1] === 'email') {
                $foundEmailRule = true;
                break;
            }
        }
        $this->assertTrue($foundEmailRule, 'Email validation rule not found');
        
        // Check length validation for first_name, last_name, email, password
        $foundLengthRule = false;
        foreach ($rules as $rule) {
            if ($rule[1] === 'length' && $rule[0] === 'first_name, last_name, email, password' && $rule['max'] === 255) {
                $foundLengthRule = true;
                break;
            }
        }
        $this->assertTrue($foundLengthRule, 'Length validation rule for names, email, password not found');
        
        // Check roll_no length validation
        $foundRollNoLengthRule = false;
        foreach ($rules as $rule) {
            if ($rule[0] === 'roll_no' && $rule[1] === 'length' && $rule['max'] === 10) {
                $foundRollNoLengthRule = true;
                break;
            }
        }
        $this->assertTrue($foundRollNoLengthRule, 'Roll number length validation rule not found');
        
        // Check percentage numerical validation
        $foundNumericalRule = false;
        foreach ($rules as $rule) {
            if ($rule[0] === 'percentage' && $rule[1] === 'numerical') {
                $foundNumericalRule = true;
                break;
            }
        }
        $this->assertTrue($foundNumericalRule, 'Percentage numerical validation rule not found');
        
        // Check safe rules
        $safeFields = ['classes', 'today_attendance', 'address', 'profile_picture'];
        foreach ($safeFields as $field) {
            $foundSafeRule = false;
            foreach ($rules as $rule) {
                if ($rule[0] === $field && $rule[1] === 'safe') {
                    $foundSafeRule = true;
                    break;
                }
            }
            $this->assertTrue($foundSafeRule, "Safe rule for {$field} not found");
        }
        
        // Check email safe rule on search scenario
        $foundEmailSearchRule = false;
        foreach ($rules as $rule) {
            if ($rule[0] === 'email' && $rule[1] === 'safe' && isset($rule['on']) && $rule['on'] === 'search') {
                $foundEmailSearchRule = true;
                break;
            }
        }
        $this->assertTrue($foundEmailSearchRule, 'Email safe rule for search scenario not found');
    }
    
    public function testAttributeLabels()
    {
        $labels = $this->student->attributeLabels();
        $expectedLabels = [
            'first_name' => 'First Name',
            'last_name' => 'Last Name',
            'email' => 'Email',
            'password' => 'Password',
            'roll_no' => 'Roll No',
            'classes' => 'Classes',
            'percentage' => 'Percentage',
            'address' => 'Address',
            'profile_picture' => 'Profile Picture',
        ];
        
        $this->assertIsArray($labels);
        $this->assertEquals($expectedLabels, $labels);
        $this->assertCount(9, $labels);
    }
    
    public function testHashPassword()
    {
        $plainPassword = 'mypassword123';
        $hashedPassword = $this->student->hashPassword($plainPassword);
        
        $this->assertNotEquals($plainPassword, $hashedPassword);
        $this->assertTrue(password_verify($plainPassword, $hashedPassword));
        $this->assertStringStartsWith('$2y$', $hashedPassword); // BCrypt hash format
        
        // Test with different password
        $anotherPassword = 'differentpassword';
        $anotherHash = $this->student->hashPassword($anotherPassword);
        $this->assertNotEquals($hashedPassword, $anotherHash);
        
        // Test with empty password
        $emptyHash = $this->student->hashPassword('');
        $this->assertTrue(password_verify('', $emptyHash));
    }
    
    public function testBehaviors()
    {
        $behaviors = $this->student->behaviors();
        $this->assertIsArray($behaviors);
        $this->assertArrayHasKey('EMongoDocumentBehavior', $behaviors);
        
        $mongoDocumentBehavior = $behaviors['EMongoDocumentBehavior'];
        $this->assertIsArray($mongoDocumentBehavior);
        $this->assertEquals('ext.YiiMongoDbSuite.behaviors.EMongoDocumentBehavior', $mongoDocumentBehavior['class']);
        $this->assertCount(1, $behaviors); // Should only have one behavior
    }
    
    public function testEmbeddedDocuments()
    {
        $embeddedDocs = $this->student->embeddedDocuments();
        $this->assertIsArray($embeddedDocs);
        $this->assertArrayHasKey('address', $embeddedDocs);
        $this->assertEquals('Address', $embeddedDocs['address']);
        $this->assertCount(1, $embeddedDocs); // Should only have address embedded
    }
    
    public function testInitEmbeddedDocuments()
    {
        // Test that initEmbeddedDocuments initializes address
        $this->student->initEmbeddedDocuments();
        
        $this->assertInstanceOf('Address', $this->student->address);
        $this->assertNotNull($this->student->address);
        
        // Test that classes and attendance are initialized as empty arrays
        $this->assertIsArray($this->student->classes);
        $this->assertEmpty($this->student->classes);
        
        $this->assertIsArray($this->student->attendance);
        $this->assertEmpty($this->student->attendance);
    }
    
    public function testStaticModelReturnsInstance()
    {
        // Create a real instance for this test since we need to test the static method
        $modelInstance = Student::model();
        $this->assertInstanceOf('Student', $modelInstance);
    }
    
    public function testPublicProperties()
    {
        // Test that all expected public properties exist
        $expectedProperties = [
            'first_name', 'last_name', 'email', 'password', 
            'roll_no', 'classes', 'attendance', 'percentage', 'address'
        ];
        
        foreach ($expectedProperties as $property) {
            $this->assertTrue(property_exists($this->student, $property), "Property {$property} does not exist");
        }
        
        // Test that we can set and get these properties
        $this->student->first_name = 'Jane';
        $this->student->last_name = 'Smith';
        $this->student->email = 'jane.smith@example.com';
        $this->student->password = 'hashedpassword';
        $this->student->roll_no = 'STU001';
        $this->student->classes = ['class1', 'class2'];
        $this->student->attendance = ['2023-01-01', '2023-01-02'];
        $this->student->percentage = 85.5;
        
        $this->assertEquals('Jane', $this->student->first_name);
        $this->assertEquals('Smith', $this->student->last_name);
        $this->assertEquals('jane.smith@example.com', $this->student->email);
        $this->assertEquals('hashedpassword', $this->student->password);
        $this->assertEquals('STU001', $this->student->roll_no);
        $this->assertEquals(['class1', 'class2'], $this->student->classes);
        $this->assertEquals(['2023-01-01', '2023-01-02'], $this->student->attendance);
        $this->assertEquals(85.5, $this->student->percentage);
        
        // Test default array values
        $freshStudent = m::mock(Student::class)->makePartial();
        $freshStudent->classes = [];
        $freshStudent->attendance = [];
        
        $this->assertEquals([], $freshStudent->classes);
        $this->assertEquals([], $freshStudent->attendance);
        $this->assertIsArray($freshStudent->classes);
        $this->assertIsArray($freshStudent->attendance);
    }
    
    public function testStudentSpecificProperties()
    {
        // Test roll_no specifically (different from Teacher's EmployeeID)
        $this->student->roll_no = 'S12345';
        $this->assertEquals('S12345', $this->student->roll_no);
        
        // Test percentage property (Teacher doesn't have this)
        $this->student->percentage = 92.5;
        $this->assertEquals(92.5, $this->student->percentage);
        
        // Test attendance property (Teacher doesn't have this)
        $this->student->attendance = ['2023-01-01', '2023-01-02', '2023-01-03'];
        $this->assertEquals(['2023-01-01', '2023-01-02', '2023-01-03'], $this->student->attendance);
        $this->assertCount(3, $this->student->attendance);
        
        // Test that Student doesn't have Teacher-specific properties
        $this->assertFalse(property_exists($this->student, 'EmployeeID'));
        $this->assertFalse(property_exists($this->student, 'Qualifications'));
        
        // Test that Student has attendance (Teacher doesn't)
        $this->assertTrue(property_exists($this->student, 'attendance'));
        $this->assertTrue(property_exists($this->student, 'percentage'));
    }
    
    public function testMethodsExistence()
    {
        // Test that all required methods exist
        $requiredMethods = [
            'getCollectionName', 'rules', 'attributeLabels', 
            'hashPassword', 'behaviors', 'embeddedDocuments', 
            'initEmbeddedDocuments'
        ];
        
        foreach ($requiredMethods as $method) {
            $this->assertTrue(method_exists($this->student, $method), "Method {$method} does not exist");
        }
        
        // Test that static model method exists
        $this->assertTrue(method_exists('Student', 'model'), 'Static model method does not exist');
    }
    
    public function testRulesValidation()
    {
        // Test that all rules have proper structure
        $rules = $this->student->rules();
        
        foreach ($rules as $rule) {
            $this->assertIsArray($rule);
            $this->assertGreaterThanOrEqual(2, count($rule)); // At least field and validator
            $this->assertIsString($rule[0]); // Field name(s)
            $this->assertIsString($rule[1]); // Validator name
        }
        
        // Test specific rule configurations
        $lengthRules = array_filter($rules, function($rule) {
            return $rule[1] === 'length';
        });
        
        foreach ($lengthRules as $rule) {
            $this->assertArrayHasKey('max', $rule);
            $this->assertIsInt($rule['max']);
        }
    }
}