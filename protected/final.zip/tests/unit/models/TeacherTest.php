<?php
 
/**
* @runTestsInSeparateProcesses
* @preserveGlobalState disabled
*/
 
 
use Mockery as m;
use \Mockery\Adapter\Phpunit\MockeryTestCase;

// NOTE: For this test to run in isolation, dummy classes for `EMongoDocument` and `Address` 
// would be needed, as PHP will try to load them. e.g.:
// if (!class_exists('Address')) { class Address {} }
// if (!class_exists('EMongoDocument')) { abstract class EMongoDocument { public function initEmbeddedDocuments(){} public static function model($c){return new $c;} } }


class TeacherTest extends MockeryTestCase
{
    protected $teacher;
    
    protected function setUp(): void
    {
        // Partial mock to avoid calling parent constructor or DB connection
        $this->teacher = m::mock(Teacher::class)->makePartial();
    }
    
    public function testGetCollectionName()
    {
        $this->assertEquals('teachers', $this->teacher->getCollectionName());
    }
    
    public function testRules()
    {
        $rules = $this->teacher->rules();
        $this->assertIsArray($rules);
        
        // Test that we have exactly the expected number of rules
        $this->assertCount(6, $rules);
        
        // Check that required rule contains email and password
        $foundRequired = false;
        foreach ($rules as $rule) {
            if ($rule[1] === 'required' && $rule[0] === 'email, password') {
                $foundRequired = true;
                break;
            }
        }
        $this->assertTrue($foundRequired, 'Required rule for email, password not found');
        
        // Check email validation rule
        $foundEmailRule = false;
        foreach ($rules as $rule) {
            if ($rule[0] === 'email' && $rule[1] === 'email') {
                $foundEmailRule = true;
                break;
            }
        }
        $this->assertTrue($foundEmailRule, 'Email validation rule not found');
        
        // Check length validation for first_name, last_name, email, password
        $foundLengthRule = false;
        foreach ($rules as $rule) {
            if ($rule[1] === 'length' && $rule[0] === 'first_name, last_name, email, password' && $rule['max'] === 255) {
                $foundLengthRule = true;
                break;
            }
        }
        $this->assertTrue($foundLengthRule, 'Length validation rule for names, email, password not found');
        
        // Check EmployeeID length validation
        $foundEmployeeIDLengthRule = false;
        foreach ($rules as $rule) {
            if ($rule[0] === 'EmployeeID' && $rule[1] === 'length' && $rule['max'] === 10) {
                $foundEmployeeIDLengthRule = true;
                break;
            }
        }
        $this->assertTrue($foundEmployeeIDLengthRule, 'EmployeeID length validation rule not found');
        
        // Check address safe rule
        $foundAddressSafeRule = false;
        foreach ($rules as $rule) {
            if ($rule[0] === 'address' && $rule[1] === 'safe') {
                $foundAddressSafeRule = true;
                break;
            }
        }
        $this->assertTrue($foundAddressSafeRule, 'Safe rule for address not found');
        
        // Check email safe rule on search scenario
        $foundEmailSearchRule = false;
        foreach ($rules as $rule) {
            if ($rule[0] === 'email' && $rule[1] === 'safe' && isset($rule['on']) && $rule['on'] === 'search') {
                $foundEmailSearchRule = true;
                break;
            }
        }
        $this->assertTrue($foundEmailSearchRule, 'Email safe rule for search scenario not found');
    }
    
    public function testAttributeLabels()
    {
        $labels = $this->teacher->attributeLabels();
        $expectedLabels = [
            'first_name' => 'First Name',
            'last_name' => 'Last Name',
            'email' => 'Email',
            'password' => 'Password',
            'EmployeeID' => 'Employee ID',
            'Qualifications' => 'Qualifications',
            'classes' => 'Classes',
            'address' => 'Address',
        ];
        
        $this->assertIsArray($labels);
        $this->assertEquals($expectedLabels, $labels);
        $this->assertCount(8, $labels);
    }
    
    public function testHashPassword()
    {
        $plainPassword = 'mypassword123';
        $hashedPassword = $this->teacher->hashPassword($plainPassword);
        
        $this->assertNotEquals($plainPassword, $hashedPassword);
        $this->assertTrue(password_verify($plainPassword, $hashedPassword));
        $this->assertStringStartsWith('$2y$', $hashedPassword); // BCrypt hash format
        
        // Test with different password
        $anotherPassword = 'differentpassword';
        $anotherHash = $this->teacher->hashPassword($anotherPassword);
        $this->assertNotEquals($hashedPassword, $anotherHash);
        
        // Test with empty password
        $emptyHash = $this->teacher->hashPassword('');
        $this->assertTrue(password_verify('', $emptyHash));
    }
    
    public function testBehaviors()
    {
        $behaviors = $this->teacher->behaviors();
        $this->assertIsArray($behaviors);
        $this->assertArrayHasKey('embeddedArrays', $behaviors);
        
        $embeddedArraysBehavior = $behaviors['embeddedArrays'];
        $this->assertIsArray($embeddedArraysBehavior);
        $this->assertEquals('ext.YiiMongoDbSuite.extra.EEmbeddedArraysBehavior', $embeddedArraysBehavior['class']);
        $this->assertEquals('Qualifications', $embeddedArraysBehavior['arrayPropertyName']);
        $this->assertEquals('Qualification', $embeddedArraysBehavior['arrayDocClassName']);
        $this->assertCount(1, $behaviors); // Should only have one behavior
    }
    
    public function testEmbeddedDocuments()
    {
        $embeddedDocs = $this->teacher->embeddedDocuments();
        $this->assertIsArray($embeddedDocs);
        $this->assertArrayHasKey('address', $embeddedDocs);
        $this->assertEquals('Address', $embeddedDocs['address']);
        $this->assertCount(1, $embeddedDocs); // Should only have address embedded
    }
    
    public function testInitEmbeddedDocuments()
    {
        // === Test Case 1: Properties are initially null ===
        
        // Create a teacher instance where properties are null by default or set them explicitly
        $teacher = m::mock(Teacher::class)->makePartial();
        $teacher->address = null;
        $teacher->Qualifications = null;
        $teacher->classes = null;
        
        // We need a dummy Address class for this to work
        
        
        // Call the method to be tested
        $teacher->initEmbeddedDocuments();

        // Assert that null properties were initialized
        $this->assertInstanceOf('Address', $teacher->address, 'Address should be initialized to an Address object.');
        $this->assertIsArray($teacher->Qualifications, 'Qualifications should be initialized to an array.');
        $this->assertEmpty($teacher->Qualifications, 'Qualifications should be initialized as an empty array.');
        $this->assertIsArray($teacher->classes, 'Classes should be initialized to an array.');
        $this->assertEmpty($teacher->classes, 'Classes should be initialized as an empty array.');
        
        
        // === Test Case 2: Properties are already set and should not be changed ===

        // Create a new teacher instance with pre-populated properties
        $teacherWithData = m::mock(Teacher::class)->makePartial();

        // Use distinct objects/arrays to ensure they are not replaced
        $preSetAddress = new Address();
        $preSetQualifications = ['PhD in Computer Science'];
        $preSetClasses = ['CS101', 'AI202'];

        $teacherWithData->address = $preSetAddress;
        $teacherWithData->Qualifications = $preSetQualifications;
        $teacherWithData->classes = $preSetClasses;
        
        // Call the method again
        $teacherWithData->initEmbeddedDocuments();

        // Assert that the pre-set data was not overwritten
        $this->assertSame($preSetAddress, $teacherWithData->address, 'Pre-set address object should not be replaced.');
        $this->assertEquals($preSetQualifications, $teacherWithData->Qualifications, 'Pre-set Qualifications array should not be changed.');
        $this->assertEquals($preSetClasses, $teacherWithData->classes, 'Pre-set classes array should not be changed.');
    }
    
    public function testStaticModelReturnsInstance()
    {
        // For this test to pass without the full framework, a dummy EMongoDocument class is required.
        // Assuming a test bootstrap file handles this.
        if (class_exists('EMongoDocument')) {
            $modelInstance = Teacher::model();
            $this->assertInstanceOf('Teacher', $modelInstance);
        } else {
            $this->markTestSkipped('EMongoDocument class not available. Skipping testStaticModelReturnsInstance.');
        }
    }
    
    public function testPublicProperties()
    {
        // Test that all expected public properties exist
        $expectedProperties = [
            'first_name', 'last_name', 'email', 'password', 
            'EmployeeID', 'classes', 'address', 'Qualifications'
        ];
        
        foreach ($expectedProperties as $property) {
            $this->assertTrue(property_exists($this->teacher, $property), "Property {$property} does not exist");
        }
        
        // Test that we can set and get these properties
        $this->teacher->first_name = 'John';
        $this->teacher->last_name = 'Doe';
        $this->teacher->email = 'john.doe@example.com';
        $this->teacher->password = 'hashedpassword';
        $this->teacher->EmployeeID = 'EMP001';
        $this->teacher->classes = ['class1', 'class2'];
        $this->teacher->Qualifications = ['PhD'];
        
        $this->assertEquals('John', $this->teacher->first_name);
        $this->assertEquals('Doe', $this->teacher->last_name);
        $this->assertEquals('john.doe@example.com', $this->teacher->email);
        $this->assertEquals('hashedpassword', $this->teacher->password);
        $this->assertEquals('EMP001', $this->teacher->EmployeeID);
        $this->assertEquals(['class1', 'class2'], $this->teacher->classes);
        $this->assertEquals(['PhD'], $this->teacher->Qualifications);
        
        // Test default array values
        $freshTeacher = m::mock(Teacher::class)->makePartial();
        $freshTeacher->classes = [];
        $freshTeacher->Qualifications = [];
        
        $this->assertEquals([], $freshTeacher->classes);
        $this->assertEquals([], $freshTeacher->Qualifications);
        $this->assertIsArray($freshTeacher->classes);
        $this->assertIsArray($freshTeacher->Qualifications);
    }
    
    public function testTeacherSpecificProperties()
    {
        // Test EmployeeID specifically (different from Student's roll_no)
        $this->teacher->EmployeeID = 'T12345';
        $this->assertEquals('T12345', $this->teacher->EmployeeID);
        
        // Test that Teacher doesn't have Student-specific properties
        $this->assertFalse(property_exists($this->teacher, 'roll_no'));
        $this->assertFalse(property_exists($this->teacher, 'percentage'));
        $this->assertFalse(property_exists($this->teacher, 'attendance'));
        $this->assertFalse(property_exists($this->teacher, 'today_attendance'));
        
        // Test that Teacher has Qualifications (Student doesn't)
        $this->assertTrue(property_exists($this->teacher, 'Qualifications'));
    }
    
    public function testMethodsExistence()
    {
        // Test that all required methods exist
        $requiredMethods = [
            'getCollectionName', 'rules', 'attributeLabels', 
            'hashPassword', 'behaviors', 'embeddedDocuments', 
            'initEmbeddedDocuments'
        ];
        
        foreach ($requiredMethods as $method) {
            $this->assertTrue(method_exists($this->teacher, $method), "Method {$method} does not exist");
        }
        
        // Test that static model method exists
        $this->assertTrue(method_exists('Teacher', 'model'), 'Static model method does not exist');
    }

    public function tearDown(): void
    {
        m::close();
    }
}