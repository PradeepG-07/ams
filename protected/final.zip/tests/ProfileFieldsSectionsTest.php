<?php

use Mockery\Adapter\Phpunit\MockeryTestCase;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\Attributes\TestWith;

/**
 * @runTestsInSeparateProcesses
 * @preserveGlobalState disabled
 */

class ProfileFieldsSectionsTest extends MockeryTestCase
{
    private $mongoMock;
    private $yiiAppMock;
    private $profile_fields_sections;

    protected function setUp(): void
    {
        $this->mongoMock = new MongoMock();
        $this->mongoMock->mock(ProfileFieldsSections::class);
        $this->profile_fields_sections = new ProfileFieldsSections();
        $this->yiiAppMock = new YiiAppMock();
        parent::setUp();
    }

    protected function tearDown(): void
    {
        $this->mongoMock->close();
        $this->yiiAppMock->close();
        Mockery::close();
        parent::tearDown();
    }

    public function testGetCollectionName()
    {
        $this->assertEquals('profile_fields_sections', $this->profile_fields_sections->getCollectionName());
    }

    public function testPrimaryKey()
    {
        $this->assertEquals('id', $this->profile_fields_sections->primaryKey());
    }

    public static function beforeSaveDataProvider()
    {
        return [
            [
                'isNewRecord' => true,
                'section_key' => 'biographical',
                'section_data' => [
                    '_label' => [],
                    'custom_fields' => [],
                ],
                'tenant_id' => null,
                'created_on' => null,
                'created_by' => 'user1',
                'expected' => [
                    'section_data' => [
                        'firstname' => [
                            'settings' => [
                                'enable_for_recruitment' => true,
                                'enable_for_candidate_profile' => true,
                                'mandatory_for_candidate_profile' => true,
                                'can_override_for_rec_module' => false,
                            ],
                        ],
                        '_label' => [],
                        'custom_fields' => (object) null,
                    ],
                ],
            ],
            [
                'isNewRecord' => true,
                'section_key' => 'biographical',
                'section_data' => [],
                'tenant_id' => null,
                'created_on' => null,
                'created_by' => '',
                'expected' => [
                    'section_data' => [
                        'firstname' => [
                            'settings' => [
                                'enable_for_recruitment' => true,
                                'enable_for_candidate_profile' => true,
                                'mandatory_for_candidate_profile' => true,
                                'can_override_for_rec_module' => false,
                            ],
                        ],
                    ],
                ],
            ],
            [
                'isNewRecord' => false,
                'section_key' => 'contact',
                'section_data' => [],
                'tenant_id' => 'existing_tenant_id',
                'created_on' => (object) ['sec' => time()],
                'created_by' => '',
                'expected' => [
                    'section_data' => [
                        'additional_email_onb' => [
                            'settings' => [
                                'enable_for_recruitment' => true,
                                'enable_for_candidate_profile' => true,
                                'mandatory_for_candidate_profile' => true,
                                'can_override_for_rec_module' => false,
                            ],
                        ],
                        'phone_country_code' => [
                            'settings' => [
                                'enable_for_recruitment' => true,
                                'enable_for_candidate_profile' => true,
                                'mandatory_for_candidate_profile' => true,
                                'can_override_for_rec_module' => false,
                            ],
                        ],
                        'phone' => [
                            'settings' => [
                                'enable_for_recruitment' => true,
                                'enable_for_candidate_profile' => true,
                                'mandatory_for_candidate_profile' => true,
                                'can_override_for_rec_module' => false,
                            ],
                        ],
                    ],
                    'updated_by' => 'logged_in_user',
                ],
            ],
            [
                'isNewRecord' => false,
                'section_key' => 'contact',
                'section_data' => [],
                'tenant_id' => 'existing_tenant_id',
                'created_on' => (object) ['sec' => time()],
                'created_by' => 'user1',
                'expected' => [
                    'section_data' => [
                        'additional_email_onb' => [
                            'settings' => [
                                'enable_for_recruitment' => true,
                                'enable_for_candidate_profile' => true,
                                'mandatory_for_candidate_profile' => true,
                                'can_override_for_rec_module' => false,
                            ],
                        ],
                        'phone_country_code' => [
                            'settings' => [
                                'enable_for_recruitment' => true,
                                'enable_for_candidate_profile' => true,
                                'mandatory_for_candidate_profile' => true,
                                'can_override_for_rec_module' => false,
                            ],
                        ],
                        'phone' => [
                            'settings' => [
                                'enable_for_recruitment' => true,
                                'enable_for_candidate_profile' => true,
                                'mandatory_for_candidate_profile' => true,
                                'can_override_for_rec_module' => false,
                            ],
                        ],
                    ],
                    'updated_by' => 'user1',
                ],
            ],
        ];
    }

    #[DataProvider('beforeSaveDataProvider')]
    public function testBeforeSave(
        $isNewRecord,
        $section_key,
        $section_data,
        $tenant_id,
        $created_on,
        $created_by,
        $expected,
    ) {
        $backtrace_log = [
            1264316523 => ['log'],
            1254316523 => ['log'],
            1254216523 => ['log'],
            1250316523 => ['log'],
            1287536312 => ['log'],
            1437178732 => ['log'],
        ];
        $mock_uniqid = 'a23273fe';
        $mock_time = 1574576635;
        Mockery::mock('alias:' . PhpWrapper::class)->shouldReceive(['uniqid' => $mock_uniqid, 'time' => $mock_time]);
        Mockery::mock('alias:' . UserMongoView::class)
            ->shouldReceive('getLoggedInUserId')
            ->andReturn('logged_in_user');
        Mockery::mock('alias:' . TenantProfile::class)
            ->shouldReceive('isCandProfEmailReg')
            ->andReturn(true);
        Mockery::mock('alias:' . CJSON::class)
            ->shouldReceive('encode')
            ->andReturn([$mock_time => 'log']);

        $this->profile_fields_sections->isNewRecord = $isNewRecord;
        $this->profile_fields_sections->section_key = $section_key;
        $this->profile_fields_sections->section_data = $section_data;
        $this->profile_fields_sections->tenant_id = $tenant_id;
        $this->profile_fields_sections->created_on = $created_on;
        $this->profile_fields_sections->backtrace_log = $backtrace_log;

        $backtrace_log[] = [$mock_time => 'log'];

        $this->yiiAppMock->mockUser(2, $created_by);
        if (empty($created_by)) {
            $created_by = 'logged_in_user';
        }

        $result = $this->profile_fields_sections->beforeSave();

        $this->assertTrue($result);
        $this->assertEquals($expected['section_data'], $this->profile_fields_sections->section_data);

        if ($isNewRecord) {
            $this->assertEquals($mock_uniqid, $this->profile_fields_sections->id);
            $this->assertEquals($mock_time, $this->profile_fields_sections->created_on->sec);
            $this->assertEquals($created_by, $this->profile_fields_sections->created_by);
            $this->assertEquals(2, $this->profile_fields_sections->tenant_id);
        } else {
            $this->assertEquals($mock_time, $this->profile_fields_sections->updated_on->sec);
            $this->assertEquals($expected['updated_by'], $this->profile_fields_sections->updated_by);
        }
        $this->assertEquals(array_slice($backtrace_log, -6), $this->profile_fields_sections->backtrace_log);
    }

    public function testRules()
    {
        $this->assertIsArray($this->profile_fields_sections->rules());
    }

    public static function checkDependentsEnabledDataProvider()
    {
        return [
            [
                'section_key' => 'dependent_details',
                'section_data' => [
                    'dependent_national_id_number' => ['isEnabled' => true],
                    'dependent_national_id_type' => ['isEnabled' => false],
                    'dependent_employee' => ['isEnabled' => true],
                    'dependent_is_employee' => ['isEnabled' => false],
                ],
            ],
            [
                'section_key' => '',
                'section_data' => [],
            ],
        ];
    }

    #[DataProvider('checkDependentsEnabledDataProvider')]
    public function testCheckDependentsEnabled($section_key, $section_data)
    {
        $this->profile_fields_sections = Mockery::mock(
            ProfileFieldsSections::class . '[hasErrors, getErrors, addError]',
        )->makePartial();
        if ($section_key == 'dependent_details') {
            if (
                !empty($section_data['dependent_national_id_number']['isEnabled']) &&
                empty(!empty($section_data['dependent_national_id_type']['isEnabled']))
            ) {
                $this->profile_fields_sections
                    ->shouldReceive('addError')
                    ->withArgs([
                        'dependent_national_id_number',
                        '\'National ID Type\' should be enabled to enable \'National ID Number\'',
                    ])
                    ->andReturnNull();
            }
            if (
                !empty($section_data['dependent_employee']['isEnabled']) &&
                empty(!empty($section_data['dependent_is_employee']['isEnabled']))
            ) {
                $this->profile_fields_sections
                    ->shouldReceive('addError')
                    ->withArgs([
                        'dependent_employee',
                        '\'Is a Related Employee\' should be enabled to enable \'Dependent Employee\'',
                    ])
                    ->andReturnNull();
            }
        }
        $this->profile_fields_sections->shouldReceive('getErrors')->andReturn('Error');
        $this->profile_fields_sections->section_key = $section_key;
        $this->profile_fields_sections->section_data = $section_data;
        $this->profile_fields_sections->checkDependentsEnabled();
        $this->assertEquals('Error', $this->profile_fields_sections->getErrors());
    }

    #[
        TestWith([
            0 => 2,
        ]),
    ]
    #[
        TestWith([
            0 => null,
        ]),
    ]
    public function testTenant($tenantId)
    {
        $this->profile_fields_sections = Mockery::mock(ProfileFieldsSections::class)->makePartial();
        $dbCriteriaMock = Mockery::mock();
        $this->profile_fields_sections->shouldReceive('getDbCriteria')->andReturn($dbCriteriaMock);

        $this->yiiAppMock->mockUser(2, 'user');

        $dbCriteriaMock
            ->shouldReceive('mergeWith')
            ->once()
            ->with([
                'conditions' => [
                    'tenant_id' => [
                        '==' => $tenantId ? $tenantId : 2,
                    ],
                ],
            ]);

        $this->profile_fields_sections->tenant($tenantId);
        $this->assertTrue(true);
    }

    public static function getProfileFieldsObjectFromSectionsProvider()
    {
        return [
            [
                'tenant_id' => 'tenant_1',
                'section' => null,
                'get_personal' => false,
                'get_CF_only' => true,
                'profile_sections' => [
                    (object) [
                        'section_key' => 'common',
                        'section_data' => ['field_1' => 'value_1'],
                    ],
                    (object) [
                        'section_key' => 'general',
                        'section_data' => ['field_2' => 'value_2'],
                    ],
                ],
                'translated_value' => false,
                'expected_result' => [
                    'all' => (object) [
                        '_label' => 'All',
                        '_order' => '1',
                        'common' => (object) ['field_1' => 'value_1'],
                    ],
                    'personal' => (object) [
                        '_label' => 'Personal Details',
                        '_order' => '2',
                        'general' => (object) ['field_2' => 'value_2'],
                    ],
                ],
                'return_as_object' => true,
            ],
            [
                'tenant_id' => 'tenant_2',
                'section' => ['general'],
                'get_personal' => false,
                'get_CF_only' => null,
                'profile_sections' => [
                    (object) [
                        'section_key' => 'general',
                        'section_data' => ['field_2' => 'value_2'],
                    ],
                ],
                'translated_value' => false,
                'expected_result' => [
                    'personal' => [
                        'general' => ['field_2' => 'value_2'],
                    ],
                ],
            ],
            [
                'tenant_id' => 'tenant_3',
                'section' => null,
                'get_personal' => true,
                'get_CF_only' => null,
                'profile_sections' => [
                    (object) [
                        'section_key' => 'personal',
                        'section_data' => ['field_3' => 'value_3'],
                    ],
                ],
                'translated_value' => false,
                'expected_result' => [
                    'all' => [
                        '_label' => 'All',
                        '_order' => '1',
                    ],
                    'personal' => [
                        '_label' => 'Personal Details',
                        '_order' => '2',
                        'personal' => ['field_3' => 'value_3'],
                    ],
                ],
            ],
            [
                'tenant_id' => 'tenant_3',
                'section' => null,
                'get_personal' => true,
                'get_CF_only' => null,
                'profile_sections' => [],
                'translated_value' => false,
                'expected_result' => null,
            ],
        ];
    }

    #[DataProvider('getProfileFieldsObjectFromSectionsProvider')]
    public function testGetProfileFieldsObjectFromSections(
        $tenant_id,
        $section,
        $get_personal,
        $get_CF_only,
        $profile_sections,
        $translated_value,
        $expected_result,
        $return_as_object = false,
    ) {
        Mockery::mock('alias:' . PhpWrapper::class)->shouldreceive([
            'json_encode' => 'encoded_data',
            'json_decode' => 'data',
        ]);
        $this->mongoMock->mockFindAll(ProfileFieldsSections::class, $profile_sections);

        $result = ProfileFieldsSections::getProfileFieldsObjectFromSections(
            $tenant_id,
            $section,
            $get_personal,
            $get_CF_only,
            $profile_sections,
            $translated_value,
            $return_as_object,
        );

        if ($return_as_object) {
            $this->assertEquals('data', $result);
        } elseif (is_null($result)) {
            $this->assertEquals($expected_result, $result);
        } else {
            $this->assertEquals($expected_result['all'] ?? null, $result->all ?? null);
            $this->assertEquals($expected_result['personal'] ?? null, $result->personal ?? null);
        }
    }

    public static function createProfileFieldsSectionsObjectProvider()
    {
        return [
            [
                'tenant_id' => 1,
                'profile_settings' => [
                    'personal' => ['field_1' => 'value_1'],
                    'common' => ['field_2' => 'value_2'],
                ],
                'expected_result' => [
                    'personal' => ['field_1' => 'value_1'],
                    'common' => ['field_2' => 'value_2'],
                ],
            ],
            [
                'tenant_id' => 2,
                'profile_settings' => null,
                'expected_result' => [
                    'personal' => ['field_3' => 'value_3'],
                    'common' => ['field_4' => 'value_4'],
                ],
            ],
        ];
    }

    #[DataProvider('createProfileFieldsSectionsObjectProvider')]
    public function testCreateProfileFieldsSectionsObject($tenant_id, $profile_settings, $expected_result)
    {
        $php_wrapper = Mockery::mock('alias:' . PhpWrapper::class);
        $php_wrapper->shouldReceive('file_get_contents')->andReturn();
        $php_wrapper->shouldReceive('json_decode')->andReturn();

        $profile_fields = Mockery::mock('alias:' . ProfileFields::class);
        $profile_fields->shouldReceive('model')->andReturnSelf();
        $profile_fields->shouldReceive('tenant')->andReturnSelf();
        $profile_fields->shouldReceive('find')->andReturn($profile_settings);

        if (empty($profile_settings)) {
            $profile_settings = [
                'personal' => ['field_3' => 'value_3'],
                'common' => ['field_4' => 'value_4'],
            ];
        }
        $profile_fields->shouldReceive('getConfigFilePath')->andReturn('/xfqsdxs/kyufdket');

        $this->profile_fields_sections = Mockery::mock(ProfileFieldsSections::class)->makePartial();
        $this->profile_fields_sections->shouldReceive('createProfileFieldsInSections')->andReturn($profile_settings);

        $result = $this->profile_fields_sections->createProfileFieldsSectionsObject($tenant_id);

        $this->assertEquals($expected_result, $result);
    }

    public static function createProfileFieldsInSectionsProvider()
    {
        return [
            [
                'profile_settings' => [
                    'personal' => ['field_1' => 'value_1'],
                    'all' => ['common_field' => 'value_2'],
                ],
                'tenant_id' => 'tenant_1',
                'save' => true,
                'return_object' => false,
                'expected_result' => [
                    'personal' => [],
                    'all' => [],
                ],
            ],
            [
                'profile_settings' => (object) [
                    'personal' => ['field_1' => 'value_1', '_label' => true, '_order' => true],
                    'all' => ['common_field' => 'value_2'],
                    'created_on' => 1734092162,
                ],
                'tenant_id' => 'tenant_2',
                'save' => false,
                'return_object' => true,
                'expected_result' => [
                    'constructed_objects' => [
                        'field_1' => (object) [
                            'tenant_id' => 'tenant_2',
                            'section_key' => 'common_field',
                            'section_data' => 'value_2',
                            'created_on' => 1734092162,
                        ],
                        'common_field' => (object) [
                            'tenant_id' => 'tenant_2',
                            'section_key' => 'common_field',
                            'section_data' => 'value_2',
                            'created_on' => 1734092162,
                        ],
                    ],
                    'profile_fields_object' => [
                        'personal' => [],
                        'all' => [],
                    ],
                ],
            ],
            [
                'profile_settings' => ['personal' => [], 'all' => []],
                'tenant_id' => 'tenant_3',
                'save' => false,
                'return_object' => false,
                'expected_result' => [],
            ],
        ];
    }

    #[DataProvider('createProfileFieldsInSectionsProvider')]
    public function testCreateProfileFieldsInSections(
        $profile_settings,
        $tenant_id,
        $save,
        $return_object,
        $expected_result,
    ) {
        $mock_time = 1574576635;
        Mockery::mock('alias:' . PhpWrapper::class)->shouldReceive(['time' => $mock_time]);
        $this->profile_fields_sections = Mockery::mock('ProfileFieldsSections')->makePartial();

        $this->profile_fields_sections->shouldReceive('save')->andReturn(true);
        $this->profile_fields_sections
            ->shouldReceive('getProfileFieldsObjectFromSections')
            ->andReturn(['personal' => [], 'all' => []]);
        $this->profile_fields_sections->shouldReceive('setDownloadPermissions')->andReturnNull();
        if ($save) {
            $this->profile_fields_sections->shouldReceive('getInstance')->andReturnSelf();
        } else {
            $this->profile_fields_sections->shouldReceive('getInstance')->andReturn((object) []);
        }

        $result = $this->profile_fields_sections->createProfileFieldsInSections(
            $profile_settings,
            $tenant_id,
            $save,
            $return_object,
        );

        if ($save) {
            $this->assertEquals($expected_result, $result);
        } elseif ($return_object) {
            $this->assertEquals($expected_result['constructed_objects'], $result[0]);
            $this->assertEquals($expected_result['profile_fields_object'], $result[1]);
        } else {
            $this->assertEquals($expected_result, $result);
        }
    }

    public static function setDownloadPermissionsProvider()
    {
        return [
            [
                'profile_fields_section' => (object) [
                    'section_data' => [
                        'custom_fields' => [
                            'field_1' => [
                                '_type' => 'attachment',
                                'permissions' => [
                                    'R' => ['user1', 'user2'],
                                    'U' => ['user2', 'user3'],
                                    'D' => ['user4'],
                                ],
                            ],
                        ],
                    ],
                ],
                'expected' => (object) [
                    'section_data' => [
                        'custom_fields' => [
                            'field_1' => [
                                '_type' => 'attachment',
                                'permissions' => [
                                    'R' => ['user1', 'user2'],
                                    'U' => ['user2', 'user3'],
                                    'D' => ['user4'],
                                    'DO' => ['user1', 'user2', 'user3', 'user4'],
                                ],
                            ],
                        ],
                    ],
                ],
            ],
            [
                'profile_fields_section' => (object) [
                    'section_data' => [
                        'field_1' => [
                            '_type' => 'attachment_array',
                            'permissions' => [
                                'R' => ['userA'],
                                'U' => ['userB', 'userA'],
                                'D' => ['userC'],
                            ],
                        ],
                    ],
                ],
                'expected' => (object) [
                    'section_data' => [
                        'field_1' => [
                            '_type' => 'attachment_array',
                            'permissions' => [
                                'R' => ['userA'],
                                'U' => ['userB', 'userA'],
                                'D' => ['userC'],
                                'DO' => ['userA', 'userB', 'userC'],
                            ],
                        ],
                    ],
                ],
            ],
            [
                'profile_fields_section' => (object) [
                    'section_data' => [],
                ],
                'expected' => (object) [
                    'section_data' => [],
                ],
            ],
            [
                'profile_fields_section' => (object) [],
                'expected' => (object) [],
            ],
            [
                'profile_fields_section' => (object) [
                    'section_data' => [
                        'field_1' => [
                            '_type' => 'text',
                            'permissions' => [
                                'R' => ['userA'],
                                'U' => ['userB'],
                                'D' => ['userC'],
                            ],
                        ],
                    ],
                ],
                'expected' => (object) [
                    'section_data' => [
                        'field_1' => [
                            '_type' => 'text',
                            'permissions' => [
                                'R' => ['userA'],
                                'U' => ['userB'],
                                'D' => ['userC'],
                            ],
                        ],
                    ],
                ],
            ],
        ];
    }

    #[DataProvider('setDownloadPermissionsProvider')]
    public function testSetDownloadPermissions($profile_fields_section, $expected)
    {
        $this->profile_fields_sections->setDownloadPermissions($profile_fields_section);

        $this->assertEquals($expected, $profile_fields_section);
    }

    public static function getFieldsDataByIdsforProfileApprovalProvider()
    {
        return [
            [
                'tenant_id' => 'tenant_1',
                'section_key' => 'section_1',
                'field_ids' => ['custom_field_1'],
                'mocked_section_data' => [
                    'custom_fields' => [
                        'custom_field_1' => ['_label' => 'Label 1', '_type' => 'type_1'],
                        'custom_field_2' => ['_label' => 'Label 2', '_type' => 'type_2'],
                    ],
                    'default_field_1' => ['_label' => 'Label 3', '_type' => 'type_3'],
                ],
                'expected_result' => [
                    'custom_fields' => [
                        'custom_field_1' => ['_label' => 'Label 1', '_type' => 'type_1'],
                    ],
                ],
            ],
            [
                'tenant_id' => 'tenant_2',
                'section_key' => 'section_2',
                'field_ids' => ['default_field_1'],
                'mocked_section_data' => [
                    'custom_fields' => [
                        'custom_field_1' => ['_label' => 'Label 1', '_type' => 'type_1'],
                    ],
                    'default_field_1' => ['_label' => 'Label 3', '_type' => 'type_3'],
                ],
                'expected_result' => [
                    'default_fields' => [
                        'default_field_1' => ['_label' => 'Label 3', '_type' => 'type_3'],
                    ],
                ],
            ],
            [
                'tenant_id' => 'tenant_3',
                'section_key' => 'section_3',
                'field_ids' => ['nonexistent_field'],
                'mocked_section_data' => [
                    'custom_fields' => [
                        'custom_field_1' => ['_label' => 'Label 1', '_type' => 'type_1'],
                    ],
                    'default_field_1' => ['_label' => 'Label 3', '_type' => 'type_3'],
                ],
                'expected_result' => [],
            ],
            [
                'tenant_id' => 'tenant_4',
                'section_key' => 'section_4',
                'field_ids' => [],
                'mocked_section_data' => [
                    'custom_fields' => [
                        'custom_field_1' => ['_label' => 'Label 1', '_type' => 'type_1'],
                    ],
                    'default_field_1' => ['_label' => 'Label 3', '_type' => 'type_3'],
                ],
                'expected_result' => [
                    'custom_fields' => [
                        'custom_field_1' => ['_label' => 'Label 1', '_type' => 'type_1'],
                    ],
                    'default_fields' => [
                        'default_field_1' => ['_label' => 'Label 3', '_type' => 'type_3'],
                    ],
                ],
            ],
            [
                'tenant_id' => 'tenant_5',
                'section_key' => 'section_5',
                'field_ids' => [],
                'mocked_section_data' => [],
                'expected_result' => [],
            ],
        ];
    }

    #[DataProvider('getFieldsDataByIdsforProfileApprovalProvider')]
    public function testGetFieldsDataByIdsforProfileApproval(
        $tenant_id,
        $section_key,
        $field_ids,
        $mocked_section_data,
        $expected_result,
    ) {
        $this->mongoMock->mockFind(ProfileFieldsSections::class, (object) ['section_data' => $mocked_section_data]);

        $result = $this->profile_fields_sections->getFieldsDataByIdsforProfileApproval(
            $tenant_id,
            $section_key,
            $field_ids,
        );

        $this->assertEquals($expected_result, $result);
    }

    public static function getCustomArrayFieldsProvider()
    {
        return [
            [
                'tenant_id' => 'tenant_1',
                'is_candidate' => false,
                'mocked_section_data' => [
                    (object) [
                        'section_key' => 'section_1',
                        'section_data' => [
                            '_label' => 'Custom Array Section 1',
                            'custom_fields' => [
                                'field_1' => [
                                    '_label' => 'Field 1',
                                    '_type' => 'textfield',
                                    'isEnabled' => true,
                                    'isActive' => true,
                                    'settings' => [],
                                ],
                                'field_2' => [
                                    '_label' => 'Field 2',
                                    '_type' => 'select',
                                    'isEnabled' => true,
                                    'isActive' => true,
                                    'settings' => [],
                                ],
                            ],
                        ],
                    ],
                ],
                'expected_result' => [
                    'section_1' => [
                        'name' => 'Custom Array Section 1',
                        'field_1' => 'Field 1',
                        'field_2' => 'Field 2',
                    ],
                ],
                'expected_custom_variables_list' => [
                    'Custom Array Section 1.Field 1',
                    'Custom Array Section 1.Field 2',
                ],
            ],
            [
                'tenant_id' => 'tenant_2',
                'is_candidate' => false,
                'mocked_section_data' => [
                    (object) [
                        'section_key' => 'section_2',
                        'section_data' => [
                            '_label' => 'Custom Array Section 2',
                            'custom_fields' => [
                                'field_1' => [
                                    '_label' => 'Field 1',
                                    '_type' => 'textfield',
                                    'isEnabled' => false,
                                    'isActive' => true,
                                    'settings' => [],
                                ],
                                'field_2' => [
                                    '_label' => 'Field 2',
                                    '_type' => 'select',
                                    'isEnabled' => true,
                                    'isActive' => false,
                                    'settings' => [],
                                ],
                            ],
                        ],
                    ],
                ],
                'expected_result' => ['section_2' => ['name' => 'Custom Array Section 2']],
                'expected_custom_variables_list' => [],
            ],
            [
                'tenant_id' => 'tenant_3',
                'is_candidate' => true,
                'mocked_section_data' => [
                    (object) [
                        'section_key' => 'section_3',
                        'section_data' => [
                            '_label' => 'Candidate Section',
                            'custom_fields' => [
                                'field_1' => [
                                    '_label' => 'Candidate Field',
                                    '_type' => 'textfield',
                                    'isEnabled' => true,
                                    'isActive' => true,
                                    'settings' => ['enable_for_candidate_profile' => true],
                                ],
                            ],
                        ],
                    ],
                ],
                'expected_result' => [
                    'section_3' => [
                        'name' => 'Candidate Section',
                        'field_1' => 'Candidate Field',
                    ],
                ],
                'expected_custom_variables_list' => ['Candidate Section.Candidate Field'],
            ],
            [
                'tenant_id' => 'tenant_4',
                'is_candidate' => false,
                'mocked_section_data' => [],
                'expected_result' => [],
                'expected_custom_variables_list' => [],
            ],
        ];
    }

    #[DataProvider('getCustomArrayFieldsProvider')]
    public function testGetCustomArrayFields(
        $tenant_id,
        $is_candidate,
        $mocked_section_data,
        $expected_result,
        $expected_custom_variables_list,
    ) {
        $this->mongoMock->mockFindAll(ProfileFieldsSections::class, $mocked_section_data);

        $custom_variables_list = [];

        $result = $this->profile_fields_sections->getCustomArrayFields(
            $tenant_id,
            $is_candidate,
            $custom_variables_list,
        );

        $this->assertEquals($expected_result, $result);
        $this->assertEquals($expected_custom_variables_list, $custom_variables_list);
    }

    public function testGetSectionWiseData()
    {
        $mock_value = (object) [
            'section_key' => 'section_a',
            'section_data' => [
                '_label' => 'Section A',
                'custom_fields' => [
                    [
                        'customizeOptions' => true,
                        'isActive' => true,
                        'isEnabled' => true,
                        'options' => ['A', 'B'],
                        '_type' => 'select',
                    ],
                ],
            ],
        ];

        $this->mongoMock->mockFindByAttributes(ProfileFieldsSections::class, $mock_value);
        $result = $this->profile_fields_sections->getSectionWiseData('2', 2);
        foreach ($mock_value as $key => $value) {
            $this->assertEquals($mock_value->$key, $result->$key);
        }
    }

    public function testGetCustomizedOptionFields()
    {
        $this->mongoMock->mockFindAll(ProfileFieldsSections::class, [
            (object) [
                'section_key' => 'section_a',
                'section_data' => [
                    '_label' => 'Section A',
                    'custom_fields' => [
                        [
                            'customizeOptions' => true,
                            'isActive' => true,
                            'isEnabled' => true,
                            'options' => ['A', 'B'],
                            '_type' => 'select',
                        ],
                    ],
                ],
            ],
        ]);
        $result = $this->profile_fields_sections->getCustomizedOptionFields('2');
        $this->assertEquals($result, [
            [
                'field' => [
                    'customizeOptions' => true,
                    'isActive' => true,
                    'options' => ['A', 'B'],
                    'isEnabled' => true,
                    '_type' => 'select',
                ],
                'section_key' => 'section_a',
                'section_label' => 'Section A',
            ],
        ]);
    }

    public function testGetTypes()
    {
        $custom_fields = ['23456sadfhj' => ['field' => ['_label' => 'CF 1'], 'section_label' => 'Section A']];
        $result = $this->profile_fields_sections->getTypes($custom_fields);
        $this->assertEquals($result, ['23456sadfhj' => 'CF 1 - Section A']);
    }

    public function testGetOptions()
    {
        $custom_fields = ['1wqdf' => ['field' => ['options' => ['A', 'B']]]];
        $result = $this->profile_fields_sections->getOptions($custom_fields, '1wqdf');
        $this->assertEquals($result, ['A' => 'A', 'B' => 'B']);
    }

    #[
        TestWith([
            0 => [],
        ]),
    ]
    public function testGetProfileFieldSectionsFromSectionKey($select_attributes)
    {
        $this->mongoMock->mockFind(
            ProfileFieldsSections::class,
            (object) ['section_data' => ['custom_fields' => ['1wqdf' => ['field' => ['options' => 'A']]]]],
        );
        $result = $this->profile_fields_sections->getProfileFieldSectionsFromSectionKey(
            ['section_data.custom_fields'],
            $select_attributes,
        );
        $this->assertInstanceOf(ProfileFieldsSections::class, $result);
    }

    public static function changeOptionsOfCustomFieldsDataProvider()
    {
        return [
            [
                'type' => '1wqdf',
                'options' => ['A', 'B'],
                'section_key' => 'addresses',
                'section_data' => ['custom_fields' => ['1wqdf' => ['options' => 'A']]],
                'profile_fields_personal' => [
                    'addresses' => ['custom_fields' => ['1wqdf' => ['options' => ['A', 'B']]]],
                ],
                'expected_section_data' => ['custom_fields' => ['1wqdf' => ['options' => ['A', 'B']]]],
                'expected_profile_fields_personal' => [
                    'addresses' => ['custom_fields' => ['1wqdf' => ['options' => ['A', 'B']]]],
                ],
            ],
            [
                'type' => 'nonexistent',
                'options' => ['X', 'Y'],
                'section_key' => 'addresses',
                'section_data' => ['custom_fields' => []],
                'profile_fields_personal' => ['addresses' => ['custom_fields' => []]],
                'expected_section_data' => ['custom_fields' => []],
                'expected_profile_fields_personal' => ['addresses' => ['custom_fields' => []]],
            ],
            [
                'type' => '1wqdf',
                'options' => ['C', 'D'],
                'section_key' => 'nonexistent',
                'section_data' => ['custom_fields' => ['1wqdf' => ['options' => 'A']]],
                'profile_fields_personal' => [],
                'expected_section_data' => ['custom_fields' => ['1wqdf' => ['options' => ['C', 'D']]]],
                'expected_profile_fields_personal' => [],
            ],
        ];
    }

    #[DataProvider('changeOptionsOfCustomFieldsDataProvider')]
    public function testChangeOptionsOfCustomFields(
        $type,
        $options,
        $section_key,
        $section_data,
        $profile_fields_personal,
        $expected_section_data,
        $expected_profile_fields_personal,
    ) {
        $this->profile_fields_sections = Mockery::mock(ProfileFieldsSections::class)->makePartial();
        $this->profile_fields_sections->section_key = $section_key;
        $this->profile_fields_sections->section_data = $section_data;
        $this->profile_fields_sections->shouldReceive('save')->andReturn(true);
        $this->profile_fields_sections->shouldReceive('getProfileFieldSectionsFromSectionKey')->andReturnSelf();

        $mockProfileFields = Mockery::mock('alias:' . ProfileFields::class);
        $mockProfileFields->personal = $profile_fields_personal;
        $mockProfileFields->shouldReceive('save')->andReturn(true);
        $mockProfileFields->shouldReceive('model')->andReturnSelf();
        $mockProfileFields->shouldReceive('tenant')->andReturnSelf();
        $mockProfileFields->shouldReceive('find')->andReturnSelf();

        $this->profile_fields_sections->changeOptionsOfCustomFields($type, $options, $section_key);

        $this->assertEquals($expected_section_data, $this->profile_fields_sections->section_data);
        if (!empty($profile_fields_personal)) {
            $this->assertEquals($expected_profile_fields_personal, $mockProfileFields->personal);
        }
    }

    public static function getAllFieldsDataProvider()
    {
        return [
            [
                'tenant_id' => 'tenant_1',
                'selected_fields' => [],
                'profile_fields_sections' => [
                    (object) [
                        'section_key' => 'general',
                        'section_data' => [
                            'custom_fields' => [
                                'field_1' => ['_label' => 'Field 1', 'permissions' => ['read']],
                                'field_2' => ['_label' => 'Field 2', 'permissions' => ['write']],
                            ],
                        ],
                    ],
                ],
                'expected_result' => [
                    'field_1' => ['label' => 'Field 1', 'permission' => ['read']],
                    'field_2' => ['label' => 'Field 2', 'permission' => ['write']],
                ],
            ],
            [
                'tenant_id' => 'tenant_2',
                'selected_fields' => ['name', 'email'],
                'profile_fields_sections' => [
                    (object) [
                        'section_key' => 'general',
                        'section_data' => [
                            'name' => ['_label' => 'Name', 'permissions' => ['read']],
                            'email' => ['_label' => 'Email', 'permissions' => ['write']],
                            'phone' => ['_label' => 'Phone', 'permissions' => ['read']],
                        ],
                    ],
                ],
                'expected_result' => [
                    'name' => ['label' => 'Name', 'permission' => ['read'], 'isEnabled' => []],
                    'email' => ['label' => 'Email', 'permission' => ['write'], 'isEnabled' => []],
                ],
            ],
            [
                'tenant_id' => 'tenant_3',
                'selected_fields' => [],
                'profile_fields_sections' => [
                    (object) [
                        'section_key' => 'common',
                        'section_data' => [
                            'dotted_line_manager' => ['_label' => 'Dotted Line Manager', 'permissions' => ['read']],
                            'pms_manager' => ['_label' => 'PMS Manager', 'permissions' => ['write']],
                            'hrbp_role' => ['_label' => 'HRBP Role', 'permissions' => ['read']],
                            'other_field' => ['_label' => 'Other', 'permissions' => ['read']],
                        ],
                    ],
                ],
                'expected_result' => [
                    'dotted_line_manager' => ['label' => 'Dotted Line Manager', 'permission' => ['read']],
                    'pms_manager' => ['label' => 'PMS Manager', 'permission' => ['write']],
                    'hrbp_role' => ['label' => 'HRBP Role', 'permission' => ['read']],
                ],
            ],
        ];
    }

    #[DataProvider('getAllFieldsDataProvider')]
    public function testGetAllFieldsData($tenant_id, $selected_fields, $profile_fields_sections, $expected_result)
    {
        $this->mongoMock->mockFindAll(ProfileFieldsSections::class, $profile_fields_sections);

        $result = $this->profile_fields_sections->getAllFielsData($tenant_id, $selected_fields);

        $this->assertEquals($expected_result, $result);
    }

    public static function getCountryWiseNationIdsDataProvider()
    {
        return [
            [
                'country' => 104,
                'profile_fields' => (object) [
                    'personal' => (object) [
                        'personal_identity' => [
                            '_label' => [],
                            'common' => (object) ['_label' => 'india', 'settings' => (object) ['countryId' => [104]]],
                        ],
                    ],
                ],
                'expected_result' => ['common' => 'india'],
            ],
            [
                'country' => 0,
                'profile_fields' => null,
                'expected_result' => ['common' => 'india'],
            ],
        ];
    }

    #[DataProvider('getCountryWiseNationIdsDataProvider')]
    public function testGetCountryWiseNationIds($country, $profile_fields, $expected_result)
    {
        $this->profile_fields_sections = Mockery::mock(ProfileFieldsSections::class)->makePartial();
        $this->profile_fields_sections->shouldReceive('getProfileFieldsObjectFromSections')->andReturn(
            (object) [
                'personal' => (object) [
                    'personal_identity' => ['_label' => [], 'common' => (object) ['_label' => 'india']],
                ],
            ],
        );
        $result = $this->profile_fields_sections->getCountryWiseNationIds($country, $profile_fields);
        $this->assertEquals($expected_result, $result);
    }

    public static function saveBusinessFlowsForProfileViewSettingsDataProvider()
    {
        return [
            [
                'section_id' => 'id1',
                'flow_id' => 1,
                'profile_field_section' => (object) [
                    '_id' => 1,
                    'section_data' => ['_business_flows' => []],
                ],
                'profile_settings_object' => (object) [
                    'personal' => ['id1' => ['_business_flows' => []]],
                ],
                'expected_count' => [10, 1],
            ],
            [
                'section_id' => 'id2',
                'flow_id' => 2,
                'profile_field_section' => (object) [
                    '_id' => 1,
                    'section_data' => ['_business_flows' => [1]],
                ],
                'profile_settings_object' => (object) [
                    'personal' => ['id2' => ['_business_flows' => [1]]],
                ],
                'expected_count' => [10, 1],
            ],
            [
                'section_id' => 'id2',
                'flow_id' => 2,
                'profile_field_section' => null,
                'profile_settings_object' => null,
                'expected_count' => [0, 0],
            ],
        ];
    }

    #[DataProvider('saveBusinessFlowsForProfileViewSettingsDataProvider')]
    public function testSaveBusinessFlowsForProfileViewSettings(
        $section_id,
        $flow_id,
        $profile_field_section,
        $profile_settings_object,
        $expected_count,
    ) {
        $save_attributes_1 = [];
        $save_attributes_2 = [];

        $this->mongoMock->mockSave(ProfileFieldsSections::class, $save_attributes_1);
        $this->mongoMock->mockFindByAttributes(ProfileFieldsSections::class, $profile_field_section);
        $this->mongoMock->mock(ProfileFields::class);
        $this->mongoMock->mockSaveAttributes(ProfileFields::class, $save_attributes_2);
        $this->mongoMock->mockFind(ProfileFields::class, $profile_settings_object);

        $this->profile_fields_sections->saveBusinessFlowsForProfileViewSettings($section_id, $flow_id);
        $this->assertCount($expected_count[0], $save_attributes_1);
        $this->assertCount($expected_count[1], $save_attributes_2);
    }

    public static function getSectionFieldLabelsDataProvider()
    {
        return [
            'Empty section key' => [2, [], [], []],
            'Single section with custom fields' => [
                2,
                ['section1'],
                [
                    (object) [
                        'section_key' => 'section1',
                        'section_data' => [
                            'custom_fields' => [
                                'field1' => ['_label' => 'Custom Field 1'],
                                'field2' => ['_label' => 'Custom Field 2'],
                            ],
                        ],
                    ],
                ],
                [
                    'section1' => [
                        'field1' => 'Custom Field 1',
                        'field2' => 'Custom Field 2',
                    ],
                ],
            ],
            'Multiple sections with normal fields' => [
                2,
                ['section1', 'section2'],
                [
                    (object) [
                        'section_key' => 'section1',
                        'section_data' => [
                            'field_a' => ['_label' => 'Field A Label'],
                            'field_b' => ['_label' => 'Field B Label'],
                        ],
                    ],
                    (object) [
                        'section_key' => 'section2',
                        'section_data' => [
                            'custom_fields' => [
                                'field_x' => ['_label' => 'Custom Field X'],
                            ],
                        ],
                    ],
                ],
                [
                    'section1' => [
                        'field_a' => 'Field A Label',
                        'field_b' => 'Field B Label',
                    ],
                    'section2' => [
                        'field_x' => 'Custom Field X',
                    ],
                ],
            ],
        ];
    }

    #[DataProvider('getSectionFieldLabelsDataProvider')]
    public function testGetSectionFieldLabels($tenant_id, $section_keys, $mock_sections, $expected_result)
    {
        $this->mongoMock->mockFindAll(ProfileFieldsSections::class, $mock_sections);
        $result = $this->profile_fields_sections->getSectionFieldLabels($tenant_id, $section_keys);
        $this->assertEquals($expected_result, $result);
    }

    public function testGetInstance()
    {
        $result = $this->profile_fields_sections->getInstance();
        $this->assertInstanceOf(ProfileFieldsSections::class, $result);
    }

    public function testGetAllActiveCustomFieldsByTypeForUserAssignments()
    {
        $this->mongoMock->mockFindAll(ProfileFieldsSections::class, [
            (object) [
                'section_key' => 'section_a',
                'section_data' => [
                    '_label' => 'Section A',
                    'custom_fields' => [
                        '2345678o' => [
                            'customizeOptions' => true,
                            'isActive' => true,
                            'isEnabled' => true,
                            'options' => ['A', 'B'],
                            '_type' => 'select',
                            '_label' => 'Custom Field',
                        ],
                    ],
                ],
            ],
        ]);
        $result = $this->profile_fields_sections->getAllActiveCustomFieldsByTypeForUserAssignments('2', ['select']);
        $this->assertEquals($result, [
            'custom_field__2345678o__section_a' => 'Custom Field - Section A',
        ]);
    }

    public static function getOptionsOfCustomFieldByIdDataProvider()
    {
        return [
            [
                (object) [
                    'section_key' => 'section_a',
                    'section_data' => [
                        '_label' => 'Section A',
                        'custom_fields' => [
                            '2345678o' => [
                                'customizeOptions' => true,
                                'isActive' => true,
                                'isEnabled' => true,
                                'options' => ['A', 'B'],
                                '_type' => 'select',
                                '_label' => 'Custom Field',
                            ],
                        ],
                    ],
                ],
                '2345678o',
                'section_a',
                [['A' => 'A', 'B' => 'B'], 'select'],
            ],
            [
                (object) [
                    'section_key' => 'section_a',
                    'section_data' => [
                        '_label' => 'Section A',
                        'custom_fields' => [
                            '2345678o' => [
                                'customizeOptions' => true,
                                'isActive' => true,
                                'isEnabled' => true,
                                'options' => ['A', 'B'],
                                '_type' => TenantCustomFields::TYPE_CHECKBOX,
                                '_label' => 'Custom Field',
                            ],
                        ],
                    ],
                ],
                '2345678o',
                'section_a',
                [[1 => 'Yes', 2 => 'No'], 'checkbox'],
            ],
        ];
    }

    #[DataProvider('getOptionsOfCustomFieldByIdDataProvider')]
    public function testGetOptionsOfCustomFieldById($section, $custom_field_id, $section_key, $expected_result)
    {
        $this->profile_fields_sections = Mockery::mock(ProfileFieldsSections::class)->makePartial();
        $this->profile_fields_sections->shouldReceive('getProfileFieldSectionsFromSectionKey')->andReturn($section);

        $result = $this->profile_fields_sections->getOptionsOfCustomFieldById($custom_field_id, $section_key, 2);
        $this->assertEquals($result, $expected_result);
    }
}
