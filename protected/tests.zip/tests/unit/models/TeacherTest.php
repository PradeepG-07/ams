<?php

use Mockery as m;

class TeacherTest extends \Mockery\Adapter\Phpunit\MockeryTestCase
{
    protected $teacher;
    protected $mongoMock;

    protected function setUp(): void
    {
        parent::setUp();
        $this->mongoMock = new MongoMock();
        $this->mongoMock->mock(Teacher::class);
        $this->teacher = new Teacher();
    }

    public function testGetCollectionName()
    {
        $this->assertEquals('teachers', $this->teacher->getCollectionName());
    }

    public function testRules()
    {
        $rules = $this->teacher->rules();

        $this->assertIsArray($rules);
        $this->assertNotEmpty($rules);

        // Check that 'emp_id' and 'user_id' are required
        $required = array_filter($rules, function ($rule) {
            return in_array('required', $rule);
        });
        $this->assertNotEmpty($required);

        // Check that salary is validated as numerical
        $numerical = array_filter($rules, function ($rule) {
            return in_array('salary', (array)$rule[0]) && $rule[1] === 'numerical';
        });
        $this->assertNotEmpty($numerical);
    }

    public function testAttributeLabels()
    {
        $labels = $this->teacher->attributeLabels();

        $this->assertEquals('Employee ID', $labels['emp_id']);
        $this->assertEquals('User ID', $labels['user_id']);
        $this->assertEquals('Salary', $labels['salary']);
        $this->assertEquals('Designation', $labels['designation']);
        $this->assertEquals('Classes', $labels['classes']);
    }

    public function testModel()
    {
        $model = Teacher::model();
        $this->assertInstanceOf(Teacher::class, $model);
    }

    public function testValidTeacher()
    {
        $this->teacher->emp_id = 'EMP001';
        $this->teacher->user_id = 'USR001';
        $this->teacher->salary = 50000;
        $this->teacher->designation = 'Assistant Professor';
        $this->teacher->classes = ['Math101', 'Physics102'];

        $this->assertTrue($this->teacher->validate());
    }

    public function testInvalidTeacherSalary()
    {
        $this->teacher->emp_id = 'EMP002';
        $this->teacher->user_id = 'USR002';
        $this->teacher->salary = 'not_a_number';
        $this->teacher->designation = 'Lecturer';

        $this->assertFalse($this->teacher->validate(['salary']));
        $this->assertArrayHasKey('salary', $this->teacher->getErrors());
    }

    protected function tearDown(): void
    {
        m::close();
        $this->mongoMock->close();
        parent::tearDown();
    }
}
