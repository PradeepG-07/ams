<?php
 
use Mockery as m;
 
class HobbyTest extends \Mockery\Adapter\Phpunit\MockeryTestCase
{
    public function testRules()
    {
        $model = new Hobby();
        $rules = $model->rules();
 
        $this->assertContains(['name', 'required'], $rules);
        $this->assertContains(['name', 'length', 'max' => 50], $rules);
        $this->assertContains(['name,description', 'safe'], $rules);
    }
 
    public function testAttributeLabels()
    {
        $model = new Hobby();
        $labels = $model->attributeLabels();
 
        $this->assertEquals('Hobby Name', $labels['name']);
        $this->assertEquals('Hobby Description', $labels['description']);
    }
 
    public function testValidationFailsWhenNameMissing()
    {
        $model = new Hobby();
        $model->name = null;
        $this->assertFalse($model->validate());
        $this->assertArrayHasKey('name', $model->getErrors());
    }
 
    public function testValidationFailsWhenNameTooLong()
    {
        $model = new Hobby();
        $model->name = str_repeat('a', 51);
        $this->assertFalse($model->validate());
        $this->assertArrayHasKey('name', $model->getErrors());
    }
 
    public function testValidationPasses()
    {
        $model = new Hobby();
        $model->name = 'Photography';
        $model->description = 'Capturing moments';
        $this->assertTrue($model->validate());
    }
}
 
 