<?php

use Mockery as m;

class UserTest extends \Mockery\Adapter\Phpunit\MockeryTestCase
{
    protected $user;
    protected $mongoMock;

    protected function setUp(): void
    {
        parent::setUp();
        $this->mongoMock = new MongoMock();
        $this->mongoMock->mock(User::class);
        $this->user = new User();
    }

    public function testConstants()
    {
        $this->assertEquals('admin', User::ROLE_ADMIN);
        $this->assertEquals('teacher', User::ROLE_TEACHER);
        $this->assertEquals('student', User::ROLE_STUDENT);
    }

    public function testRules()
    {
        $rules = $this->user->rules();
        $this->assertIsArray($rules);
        $this->assertNotEmpty($rules);
    }

    public function testAttributeLabels()
    {
        $labels = $this->user->attributeLabels();

        $this->assertEquals('Full Name', $labels['name']);
        $this->assertEquals('Email Address', $labels['email']);
        $this->assertEquals('Password', $labels['password']);
        $this->assertEquals('Role', $labels['role']);
        $this->assertEquals('Address', $labels['address']);
        $this->assertEquals('Created At', $labels['created_at']);
        $this->assertEquals('Updated At', $labels['updated_at']);
    }

    public function testEmbeddedDocuments()
    {
        $embedded = $this->user->embeddedDocuments();
        $this->assertArrayHasKey('address', $embedded);
        $this->assertEquals('Address', $embedded['address']);
    }
    public function testInitEmbeddedDocumentsWithNull()
    {
        $this->user->address = null;
        $this->user->initEmbeddedDocuments();
    
        $this->assertInstanceOf(Address::class, $this->user->address);
    }
    

    public function testCheckUniqueEmailWhenNotNew()
    {
        $this->user->isNewRecord = false;
        $result = $this->user->checkUniqueEmail('email', []);
        $this->assertTrue($result);
    }

    public function testCheckUniqueEmailWhenAlreadyExists()
    {
        $this->user->isNewRecord = true;
        $this->user->email = 'test@example.com';

        // Simulate that email already exists
        $mock = $this->mongoMock->mockCount(User::class, 1, ['email' => 'test@example.com']);
        $result = $this->user->checkUniqueEmail('email', []);
        $this->assertFalse($result);
    }

    public function testCheckUniqueEmailWhenNewAndUnique()
    {
        $this->user->isNewRecord = true;
        $this->user->email = 'unique@example.com';

        $mock = $this->mongoMock->mockCount(User::class, 0, ['email' => 'unique@example.com']);
        $result = $this->user->checkUniqueEmail('email', []);
        $this->assertTrue($result);
    }

    public function testBeforeSaveForNewRecord()
    {
        $this->user->isNewRecord = true;
        $this->user->password = 'password123';

        $mockPwdHelper = m::mock('alias:CPasswordHelper');
        $mockPwdHelper->shouldReceive('hashPassword')
                      ->with('password123')
                      ->andReturn('hashed_password');

        $this->assertTrue($this->user->beforeSave());
        $this->assertEquals('hashed_password', $this->user->password);
        $this->assertInstanceOf(MongoDate::class, $this->user->created_at);
        $this->assertInstanceOf(MongoDate::class, $this->user->updated_at);
    }

    public function testBeforeSaveForExistingRecord()
    {
        $this->user->isNewRecord = false;
        $this->user->password = 'password123';

        $this->assertTrue($this->user->beforeSave());
        $this->assertInstanceOf(MongoDate::class, $this->user->updated_at);
        $this->assertEquals('password123', $this->user->password);
        $this->assertNull($this->user->created_at);
    }

    public function testGetRoles()
    {
        $roles = User::getRoles();
        $this->assertArrayHasKey(User::ROLE_ADMIN, $roles);
        $this->assertArrayHasKey(User::ROLE_TEACHER, $roles);
        $this->assertArrayHasKey(User::ROLE_STUDENT, $roles);
        $this->assertEquals('Administrator', $roles[User::ROLE_ADMIN]);
    }

    public function testModel()
    {
        $model = User::model();
        $this->assertInstanceOf(User::class, $model);
    }

    protected function tearDown(): void
    {
        m::close();
        $this->mongoMock->close();
        parent::tearDown();
    }
}
