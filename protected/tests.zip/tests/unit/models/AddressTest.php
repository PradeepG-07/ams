<?php

class AddressTest extends \Mockery\Adapter\Phpunit\MockeryTestCase
{
    protected $address;

    protected function setUp(): void
    {
        parent::setUp();
        $this->address = new Address();
    }

    public function testRules()
    {
        $rules = $this->address->rules();
        $this->assertIsArray($rules);
        $this->assertNotEmpty($rules);

        $requiredFields = array_column(array_filter($rules, fn($r) => $r[1] === 'required'), 0);
        $this->assertContains('address_line1, city, state, zip, country', $requiredFields);
    }

    public function testAttributeLabels()
    {
        $labels = $this->address->attributeLabels();

        $this->assertEquals('Address Line 1', $labels['address_line1']);
        $this->assertEquals('Address Line 2', $labels['address_line2']);
        $this->assertEquals('City', $labels['city']);
        $this->assertEquals('State', $labels['state']);
        $this->assertEquals('ZIP Code', $labels['zip']);
        $this->assertEquals('Country', $labels['country']);
    }

    public function testValidZip()
    {
        $this->address->address_line1 = '123 Street';
        $this->address->city = 'City';
        $this->address->state = 'State';
        $this->address->country = 'Country';
    
        $this->address->zip = '12345-6789';
        $this->assertTrue($this->address->validate(['zip']));
    }

    public function testInvalidZip()
{
    $this->address->address_line1 = '123 Street';
    $this->address->city = 'City';
    $this->address->state = 'State';
    $this->address->country = 'Country';

    $this->address->zip = 'ZIP123'; // Invalid format
    $this->assertFalse($this->address->validate(['zip']));
    $this->assertArrayHasKey('zip', $this->address->getErrors());
}


    protected function tearDown(): void
    {
        parent::tearDown();
    }
}
