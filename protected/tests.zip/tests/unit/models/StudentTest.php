<?php

use Mockery as m;

class StudentTest extends \Mockery\Adapter\Phpunit\MockeryTestCase
{
    protected $student;
    protected $mongoMock;

    protected function setUp(): void
    {
        parent::setUp();

        // Instantiate MongoMock and stub the collection access for Student model
        $this->mongoMock = new MongoMock();
        $this->mongoMock->mock(Student::class);

        // Now safely instantiate the model without triggering DB access
        $this->student = new Student();
    }

    public function testGetCollectionName()
    {
        $this->assertEquals('students', $this->student->getCollectionName());
    }

    public function testRules()
    {
        $rules = $this->student->rules();

        $this->assertIsArray($rules);
        $this->assertNotEmpty($rules);
    }

    public function testAttributeLabels()
    {
        $labels = $this->student->attributeLabels();

        $this->assertEquals('Roll No', $labels['roll_no']);
        $this->assertEquals('User ID', $labels['user_id']);
        $this->assertEquals('CGPA', $labels['cgpa']);
        $this->assertEquals('Class', $labels['class']);
        $this->assertEquals('Hobbies', $labels['hobbies']);
    }

    public function testBehaviors()
    {
        $behaviors = $this->student->behaviors();

        $this->assertArrayHasKey('embeddedArrays', $behaviors);
        $this->assertEquals('ext.YiiMongoDbSuite.extra.EEmbeddedArraysBehavior', $behaviors['embeddedArrays']['class']);
        $this->assertEquals('hobbies', $behaviors['embeddedArrays']['arrayPropertyName']);
        $this->assertEquals('Hobby', $behaviors['embeddedArrays']['arrayDocClassName']);
    }

    public function testGetProfileUrlWhenKeyIsEmpty()
    {
        $this->student->profile_picture_key = null;
        $this->assertNull($this->student->getProfileUrl());
    }

    public function testGetProfileUrlWithKey()
    {
        $key = 'student-profile/image.png';

        $mockS3Helper = m::mock('alias:S3Helper');
        $mockS3Helper->shouldReceive('generateGETObjectUrl')
                     ->once()
                     ->with($key)
                     ->andReturn("https://bucket.s3.amazonaws.com/{$key}");

        $this->student->profile_picture_key = $key;
        $this->assertEquals("https://bucket.s3.amazonaws.com/{$key}", $this->student->getProfileUrl());
    }

    public function testModelMethod()
    {
        $model = Student::model();
        $this->assertInstanceOf(Student::class, $model);
    }

    protected function tearDown(): void
    {
        m::close();
        $this->mongoMock->close();
        parent::tearDown();
    }
}
