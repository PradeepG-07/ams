<?php
 
use Mockery as m;
 
class AttendanceTest extends \Mockery\Adapter\Phpunit\MockeryTestCase
{
    protected $attendance;
    protected $mongoMock;
 
    protected function setUp(): void
    {
        parent::setUp();
        $this->mongoMock = new MongoMock();
        $this->mongoMock->mock(Attendance::class);
        $this->attendance = new Attendance();
    }
 
    public function testCollectionName()
    {
        $this->assertEquals('attendance', $this->attendance->getCollectionName());
    }
 
    public function testRules()
    {
        $rules = $this->attendance->rules();
        $this->assertIsArray($rules);
        $this->assertNotEmpty($rules);
 
        $requiredFields = array_column($rules, 0);
        $this->assertContains('date', $requiredFields);
    }
 
    public function testAttributeLabels()
    {
        $labels = $this->attendance->attributeLabels();
 
        $this->assertEquals('Date', $labels['date']);
        $this->assertEquals('Class', $labels['class_id']);
        $this->assertEquals('Students', $labels['student_ids']);
    }
 
    public function testModel()
    {
        $model = Attendance::model();
        $this->assertInstanceOf(Attendance::class, $model);
    }
 
    protected function tearDown(): void
    {
        m::close();
        $this->mongoMock->close();
        parent::tearDown();
    }
}
 
 