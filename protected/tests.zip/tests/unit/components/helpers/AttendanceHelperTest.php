<?php
/**
 * @runTestsInSeparateProcesses
 * @preserveGlobalState disabled
 */
use Mockery\Adapter\Phpunit\MockeryTestCase;
use Mockery as m;
use MongoDB\BSON\ObjectID;
use MongoDB\BSON\UTCDateTime;

class AttendanceHelperTest extends MockeryTestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        putenv('S3_BUCKET_NAME=somebucket');
    }

    protected function tearDown(): void
    {
        putenv('S3_BUCKET_NAME');
    }

    /**
     * Test saveAttendance - success with new attendance record
     */
    public function testSaveAttendanceSuccess()
    {
        $classId = new ObjectID();
        $studentId1 = new ObjectID();
        $studentId2 = new ObjectID();
        $attendanceData = [
            'class_id' => (string)$classId,
            'date' => date('Y-m-d'),
            'student_ids' => [(string)$studentId1, (string)$studentId2]
        ];

        // Mock ClassesHelper::loadClassById
        $mockClass = m::mock();
        m::mock('alias:ClassesHelper')
            ->shouldReceive('loadClassById')
            ->once()
            ->with(m::type(ObjectID::class))
            ->andReturn($mockClass);

        // Mock StudentHelper::validateStudentIds
        m::mock('alias:StudentHelper')
            ->shouldReceive('validateStudentIds')
            ->once()
            ->with($attendanceData['student_ids'])
            ->andReturn(true);

        // Mock Attendance model for checking existing record
        $mockAttendanceModel = m::mock();
        $mockAttendanceModel->shouldReceive('findByAttributes')
            ->once()
            ->with([
                'class_id' => m::type(ObjectID::class),
                'date' => date('Y-m-d')
            ])
            ->andReturn(null); // No existing record

        m::mock('alias:Attendance')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockAttendanceModel);

        // Mock new Attendance instance
        $mockAttendance = m::mock('overload:Attendance');
        $mockAttendance->shouldReceive('save')->once()->andReturn(true);

        $result = AttendanceHelper::saveAttendance($attendanceData);

        $this->assertTrue($result['success']);
        $this->assertEquals('Attendance saved successfully!', $result['message']);
    }

    /**
     * Test saveAttendance - success with existing record replacement
     */
    public function testSaveAttendanceSuccessWithExistingRecord()
    {
        $classId = new ObjectID();
        $studentId1 = new ObjectID();
        $attendanceData = [
            'class_id' => (string)$classId,
            'date' => date('Y-m-d'),
            'student_ids' => [(string)$studentId1]
        ];

        // Mock ClassesHelper::loadClassById
        $mockClass = m::mock();
        m::mock('alias:ClassesHelper')
            ->shouldReceive('loadClassById')
            ->once()
            ->with(m::type(ObjectID::class))
            ->andReturn($mockClass);

        // Mock StudentHelper::validateStudentIds
        m::mock('alias:StudentHelper')
            ->shouldReceive('validateStudentIds')
            ->once()
            ->with($attendanceData['student_ids'])
            ->andReturn(true);

        // Mock existing Attendance record
        $mockExistingAttendance = m::mock();
        $mockExistingAttendance->shouldReceive('delete')->once()->andReturn(true);

        // Mock Attendance model for checking existing record
        $mockAttendanceModel = m::mock();
        $mockAttendanceModel->shouldReceive('findByAttributes')
            ->once()
            ->with([
                'class_id' => m::type(ObjectID::class),
                'date' => date('Y-m-d')
            ])
            ->andReturn($mockExistingAttendance);

        m::mock('alias:Attendance')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockAttendanceModel);

        // Mock new Attendance instance
        $mockAttendance = m::mock('overload:Attendance');
        $mockAttendance->shouldReceive('save')->once()->andReturn(true);

        $result = AttendanceHelper::saveAttendance($attendanceData);

        $this->assertTrue($result['success']);
        $this->assertEquals('Attendance saved successfully!', $result['message']);
    }

    /**
     * Test saveAttendance - invalid date (future date)
     */
    public function testSaveAttendanceInvalidFutureDate()
    {
        $classId = new ObjectID();
        $studentId = new ObjectID();
        $futureDate = date('Y-m-d', strtotime('+1 day'));
        $attendanceData = [
            'class_id' => (string)$classId,
            'date' => $futureDate,
            'student_ids' => [(string)$studentId]
        ];

        $result = AttendanceHelper::saveAttendance($attendanceData);

        $this->assertFalse($result['success']);
        $this->assertEquals('Invalid date provided. Date must be today or earlier.', $result['message']);
    }

    /**
     * Test saveAttendance - missing date
     */
    public function testSaveAttendanceMissingDate()
    {
        $classId = new ObjectID();
        $studentId = new ObjectID();
        $attendanceData = [
            'class_id' => (string)$classId,
            'student_ids' => [(string)$studentId]
        ];

        $result = AttendanceHelper::saveAttendance($attendanceData);

        $this->assertFalse($result['success']);
        $this->assertEquals('Invalid date provided. Date must be today or earlier.', $result['message']);
    }

    /**
     * Test saveAttendance - invalid date format
     */
    public function testSaveAttendanceInvalidDateFormat()
    {
        $classId = new ObjectID();
        $studentId = new ObjectID();
        $attendanceData = [
            'class_id' => (string)$classId,
            'date' => 'invalid-date',
            'student_ids' => [(string)$studentId]
        ];

        $result = AttendanceHelper::saveAttendance($attendanceData);

        $this->assertFalse($result['success']);
        $this->assertEquals('Invalid date provided. Date must be today or earlier.', $result['message']);
    }

    /**
     * Test saveAttendance - missing class_id
     */
    public function testSaveAttendanceMissingClassId()
    {
        $studentId = new ObjectID();
        $attendanceData = [
            'date' => date('Y-m-d'),
            'student_ids' => [(string)$studentId]
        ];

        $result = AttendanceHelper::saveAttendance($attendanceData);

        $this->assertFalse($result['success']);
        $this->assertEquals('Invalid class ID provided.', $result['message']);
    }

    /**
     * Test saveAttendance - invalid class_id format
     */
    public function testSaveAttendanceInvalidClassIdFormat()
    {
        $studentId = new ObjectID();
        $attendanceData = [
            'class_id' => 123, // Not a string
            'date' => date('Y-m-d'),
            'student_ids' => [(string)$studentId]
        ];

        $result = AttendanceHelper::saveAttendance($attendanceData);

        $this->assertFalse($result['success']);
        $this->assertEquals('Invalid class ID provided.', $result['message']);
    }

    /**
     * Test saveAttendance - class not found
     */
    public function testSaveAttendanceClassNotFound()
    {
        $classId = new ObjectID();
        $studentId = new ObjectID();
        $attendanceData = [
            'class_id' => (string)$classId,
            'date' => date('Y-m-d'),
            'student_ids' => [(string)$studentId]
        ];

        // Mock ClassesHelper::loadClassById to return null
        m::mock('alias:ClassesHelper')
            ->shouldReceive('loadClassById')
            ->once()
            ->with(m::type(ObjectID::class))
            ->andReturn(null);

        $result = AttendanceHelper::saveAttendance($attendanceData);

        $this->assertFalse($result['success']);
        $this->assertEquals('Invalid class ID provided.', $result['message']);
    }

    /**
     * Test saveAttendance - missing student_ids
     */
    public function testSaveAttendanceMissingStudentIds()
    {
        $classId = new ObjectID();
        $attendanceData = [
            'class_id' => (string)$classId,
            'date' => date('Y-m-d')
        ];

        // Mock ClassesHelper::loadClassById
        $mockClass = m::mock();
        m::mock('alias:ClassesHelper')
            ->shouldReceive('loadClassById')
            ->once()
            ->with(m::type(ObjectID::class))
            ->andReturn($mockClass);

        $result = AttendanceHelper::saveAttendance($attendanceData);

        $this->assertFalse($result['success']);
        $this->assertEquals('No student IDs provided or invalid format.', $result['message']);
    }

    /**
     * Test saveAttendance - empty student_ids array
     */
    public function testSaveAttendanceEmptyStudentIds()
    {
        $classId = new ObjectID();
        $attendanceData = [
            'class_id' => (string)$classId,
            'date' => date('Y-m-d'),
            'student_ids' => []
        ];

        // Mock ClassesHelper::loadClassById
        $mockClass = m::mock();
        m::mock('alias:ClassesHelper')
            ->shouldReceive('loadClassById')
            ->once()
            ->with(m::type(ObjectID::class))
            ->andReturn($mockClass);

        $result = AttendanceHelper::saveAttendance($attendanceData);

        $this->assertFalse($result['success']);
        $this->assertEquals('No student IDs provided or invalid format.', $result['message']);
    }

    /**
     * Test saveAttendance - invalid student_ids format
     */
    public function testSaveAttendanceInvalidStudentIdsFormat()
    {
        $classId = new ObjectID();
        $attendanceData = [
            'class_id' => (string)$classId,
            'date' => date('Y-m-d'),
            'student_ids' => 'not-an-array'
        ];

        // Mock ClassesHelper::loadClassById
        $mockClass = m::mock();
        m::mock('alias:ClassesHelper')
            ->shouldReceive('loadClassById')
            ->once()
            ->with(m::type(ObjectID::class))
            ->andReturn($mockClass);

        $result = AttendanceHelper::saveAttendance($attendanceData);

        $this->assertFalse($result['success']);
        $this->assertEquals('No student IDs provided or invalid format.', $result['message']);
    }

    /**
     * Test saveAttendance - invalid student IDs
     */
    public function testSaveAttendanceInvalidStudentIds()
    {
        $classId = new ObjectID();
        $studentId = new ObjectID();
        $attendanceData = [
            'class_id' => (string)$classId,
            'date' => date('Y-m-d'),
            'student_ids' => [(string)$studentId, 'invalid-id']
        ];

        // Mock ClassesHelper::loadClassById
        $mockClass = m::mock();
        m::mock('alias:ClassesHelper')
            ->shouldReceive('loadClassById')
            ->once()
            ->with(m::type(ObjectID::class))
            ->andReturn($mockClass);

        // Mock StudentHelper::validateStudentIds to return false
        m::mock('alias:StudentHelper')
            ->shouldReceive('validateStudentIds')
            ->once()
            ->with($attendanceData['student_ids'])
            ->andReturn(false);

        $result = AttendanceHelper::saveAttendance($attendanceData);

        $this->assertFalse($result['success']);
        $this->assertEquals('Invalid student IDs provided.', $result['message']);
    }

    /**
     * Test saveAttendance - save failure
     */
    public function testSaveAttendanceSaveFailure()
    {
        $classId = new ObjectID();
        $studentId = new ObjectID();
        $attendanceData = [
            'class_id' => (string)$classId,
            'date' => date('Y-m-d'),
            'student_ids' => [(string)$studentId]
        ];

        // Mock ClassesHelper::loadClassById
        $mockClass = m::mock();
        m::mock('alias:ClassesHelper')
            ->shouldReceive('loadClassById')
            ->once()
            ->with(m::type(ObjectID::class))
            ->andReturn($mockClass);

        // Mock StudentHelper::validateStudentIds
        m::mock('alias:StudentHelper')
            ->shouldReceive('validateStudentIds')
            ->once()
            ->with($attendanceData['student_ids'])
            ->andReturn(true);

        // Mock Attendance model for checking existing record
        $mockAttendanceModel = m::mock();
        $mockAttendanceModel->shouldReceive('findByAttributes')
            ->once()
            ->with([
                'class_id' => m::type(ObjectID::class),
                'date' => date('Y-m-d')
            ])
            ->andReturn(null);

        m::mock('alias:Attendance')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockAttendanceModel);

        // Mock new Attendance instance that fails to save
        $mockAttendance = m::mock('overload:Attendance');
        $mockAttendance->shouldReceive('save')->once()->andReturn(false);
        $mockAttendance->shouldReceive('getErrors')->once()->andReturn(['date' => ['Date is required']]);

        $result = AttendanceHelper::saveAttendance($attendanceData);

        $this->assertFalse($result['success']);
        $this->assertStringContainsString('Failed to save attendance:', $result['message']);
    }

    /**
     * Test saveAttendance - exception in ClassesHelper::loadClassById
     */
    public function testSaveAttendanceClassHelperException()
    {
        $classId = new ObjectID();
        $studentId = new ObjectID();
        $attendanceData = [
            'class_id' => (string)$classId,
            'date' => date('Y-m-d'),
            'student_ids' => [(string)$studentId]
        ];

        // Mock ClassesHelper::loadClassById to throw exception
        m::mock('alias:ClassesHelper')
            ->shouldReceive('loadClassById')
            ->once()
            ->with(m::type(ObjectID::class))
            ->andThrow(new Exception('Database connection error'));

        $result = AttendanceHelper::saveAttendance($attendanceData);

        $this->assertFalse($result['success']);
        $this->assertStringContainsString('An error occurred while validating attendance data:', $result['message']);
        $this->assertStringContainsString('Database connection error', $result['message']);
    }

    /**
     * Test saveAttendance - exception in StudentHelper::validateStudentIds
     */
    public function testSaveAttendanceStudentHelperException()
    {
        $classId = new ObjectID();
        $studentId = new ObjectID();
        $attendanceData = [
            'class_id' => (string)$classId,
            'date' => date('Y-m-d'),
            'student_ids' => [(string)$studentId]
        ];

        // Mock ClassesHelper::loadClassById
        $mockClass = m::mock();
        m::mock('alias:ClassesHelper')
            ->shouldReceive('loadClassById')
            ->once()
            ->with(m::type(ObjectID::class))
            ->andReturn($mockClass);

        // Mock StudentHelper::validateStudentIds to throw exception
        m::mock('alias:StudentHelper')
            ->shouldReceive('validateStudentIds')
            ->once()
            ->with($attendanceData['student_ids'])
            ->andThrow(new Exception('Student validation error'));

        $result = AttendanceHelper::saveAttendance($attendanceData);

        $this->assertFalse($result['success']);
        $this->assertStringContainsString('An error occurred while validating attendance data:', $result['message']);
        $this->assertStringContainsString('Student validation error', $result['message']);
    }

    /**
     * Test saveAttendance - exception during save
     */
    public function testSaveAttendanceSaveException()
    {
        $classId = new ObjectID();
        $studentId = new ObjectID();
        $attendanceData = [
            'class_id' => (string)$classId,
            'date' => date('Y-m-d'),
            'student_ids' => [(string)$studentId]
        ];

        // Mock ClassesHelper::loadClassById
        $mockClass = m::mock();
        m::mock('alias:ClassesHelper')
            ->shouldReceive('loadClassById')
            ->once()
            ->with(m::type(ObjectID::class))
            ->andReturn($mockClass);

        // Mock StudentHelper::validateStudentIds
        m::mock('alias:StudentHelper')
            ->shouldReceive('validateStudentIds')
            ->once()
            ->with($attendanceData['student_ids'])
            ->andReturn(true);

        // Mock Attendance model for checking existing record
        $mockAttendanceModel = m::mock();
        $mockAttendanceModel->shouldReceive('findByAttributes')
            ->once()
            ->with([
                'class_id' => m::type(ObjectID::class),
                'date' => date('Y-m-d')
            ])
            ->andReturn(null);

        m::mock('alias:Attendance')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockAttendanceModel);

        // Mock new Attendance instance that throws exception during save
        $mockAttendance = m::mock('overload:Attendance');
        $mockAttendance->shouldReceive('save')->once()->andThrow(new Exception('Database write error'));

        $result = AttendanceHelper::saveAttendance($attendanceData);

        $this->assertFalse($result['success']);
        $this->assertStringContainsString('An error occurred while validating attendance data:', $result['message']);
        $this->assertStringContainsString('Database write error', $result['message']);
    }

    /**
     * Test saveAttendance - with past date (valid)
     */
    public function testSaveAttendanceWithPastDate()
    {
        $classId = new ObjectID();
        $studentId = new ObjectID();
        $pastDate = date('Y-m-d', strtotime('-1 day'));
        $attendanceData = [
            'class_id' => (string)$classId,
            'date' => $pastDate,
            'student_ids' => [(string)$studentId]
        ];

        // Mock ClassesHelper::loadClassById
        $mockClass = m::mock();
        m::mock('alias:ClassesHelper')
            ->shouldReceive('loadClassById')
            ->once()
            ->with(m::type(ObjectID::class))
            ->andReturn($mockClass);

        // Mock StudentHelper::validateStudentIds
        m::mock('alias:StudentHelper')
            ->shouldReceive('validateStudentIds')
            ->once()
            ->with($attendanceData['student_ids'])
            ->andReturn(true);

        // Mock Attendance model for checking existing record
        $mockAttendanceModel = m::mock();
        $mockAttendanceModel->shouldReceive('findByAttributes')
            ->once()
            ->with([
                'class_id' => m::type(ObjectID::class),
                'date' => $pastDate
            ])
            ->andReturn(null);

        m::mock('alias:Attendance')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockAttendanceModel);

        // Mock new Attendance instance
        $mockAttendance = m::mock('overload:Attendance');
        $mockAttendance->shouldReceive('save')->once()->andReturn(true);

        $result = AttendanceHelper::saveAttendance($attendanceData);

        $this->assertTrue($result['success']);
        $this->assertEquals('Attendance saved successfully!', $result['message']);
    }

    /**
     * Test saveAttendance - with today's date (valid)
     */
    public function testSaveAttendanceWithTodayDate()
    {
        $classId = new ObjectID();
        $studentId = new ObjectID();
        $todayDate = date('Y-m-d');
        $attendanceData = [
            'class_id' => (string)$classId,
            'date' => $todayDate,
            'student_ids' => [(string)$studentId]
        ];

        // Mock ClassesHelper::loadClassById
        $mockClass = m::mock();
        m::mock('alias:ClassesHelper')
            ->shouldReceive('loadClassById')
            ->once()
            ->with(m::type(ObjectID::class))
            ->andReturn($mockClass);

        // Mock StudentHelper::validateStudentIds
        m::mock('alias:StudentHelper')
            ->shouldReceive('validateStudentIds')
            ->once()
            ->with($attendanceData['student_ids'])
            ->andReturn(true);

        // Mock Attendance model for checking existing record
        $mockAttendanceModel = m::mock();
        $mockAttendanceModel->shouldReceive('findByAttributes')
            ->once()
            ->with([
                'class_id' => m::type(ObjectID::class),
                'date' => $todayDate
            ])
            ->andReturn(null);

        m::mock('alias:Attendance')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockAttendanceModel);

        // Mock new Attendance instance
        $mockAttendance = m::mock('overload:Attendance');
        $mockAttendance->shouldReceive('save')->once()->andReturn(true);

        $result = AttendanceHelper::saveAttendance($attendanceData);

        $this->assertTrue($result['success']);
        $this->assertEquals('Attendance saved successfully!', $result['message']);
    }

    /**
     * Test saveAttendance - with multiple students
     */
    public function testSaveAttendanceWithMultipleStudents()
    {
        $classId = new ObjectID();
        $studentId1 = new ObjectID();
        $studentId2 = new ObjectID();
        $studentId3 = new ObjectID();
        $attendanceData = [
            'class_id' => (string)$classId,
            'date' => date('Y-m-d'),
            'student_ids' => [(string)$studentId1, (string)$studentId2, (string)$studentId3]
        ];

        // Mock ClassesHelper::loadClassById
        $mockClass = m::mock();
        m::mock('alias:ClassesHelper')
            ->shouldReceive('loadClassById')
            ->once()
            ->with(m::type(ObjectID::class))
            ->andReturn($mockClass);

        // Mock StudentHelper::validateStudentIds
        m::mock('alias:StudentHelper')
            ->shouldReceive('validateStudentIds')
            ->once()
            ->with($attendanceData['student_ids'])
            ->andReturn(true);

        // Mock Attendance model for checking existing record
        $mockAttendanceModel = m::mock();
        $mockAttendanceModel->shouldReceive('findByAttributes')
            ->once()
            ->with([
                'class_id' => m::type(ObjectID::class),
                'date' => date('Y-m-d')
            ])
            ->andReturn(null);

        m::mock('alias:Attendance')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockAttendanceModel);

        // Mock new Attendance instance
        $mockAttendance = m::mock('overload:Attendance');
        $mockAttendance->shouldReceive('save')->once()->andReturn(true);

        $result = AttendanceHelper::saveAttendance($attendanceData);

        $this->assertTrue($result['success']);
        $this->assertEquals('Attendance saved successfully!', $result['message']);
    }
}
