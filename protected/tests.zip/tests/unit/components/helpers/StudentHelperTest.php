<?php
/**
 * @runTestsInSeparateProcesses
 * @preserveGlobalState disabled
 */
use Mockery\Adapter\Phpunit\MockeryTestCase;
use Mockery as m;
use MongoDB\BSON\ObjectID;
use MongoDB\BSON\UTCDateTime;

class StudentHelperTest extends MockeryTestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        putenv('S3_BUCKET_NAME=somebucket');
    }

    protected function tearDown(): void
    {
        putenv('S3_BUCKET_NAME');
    }

    /**
     * Test loadStudentById - successful case
     */
    public function testLoadStudentByIdSuccess()
    {
        $id = new ObjectID();
        $mockStudent = m::mock();

        // Mock the Student model's findByPk method
        $mockStudentModel = m::mock();
        $mockStudentModel->shouldReceive('findByPk')
            ->once()
            ->with($id)
            ->andReturn($mockStudent);

        // Mock the alias to return the model
        m::mock('alias:Student')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockStudentModel);

        $result = StudentHelper::loadStudentById($id);
        $this->assertSame($mockStudent, $result);
    }

    /**
     * Test loadStudentById - student not found
     */
    public function testLoadStudentByIdNotFound()
    {
        $id = new ObjectID();
        
        // Mock Student model
        $mockStudentModel = m::mock();
        $mockStudentModel->shouldReceive('findByPk')
            ->once()
            ->with($id)
            ->andReturn(null);
        
        m::mock('alias:Student')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockStudentModel);

        $this->expectExceptionObject(new CHttpException(404, 'The requested student does not exist.'));
        StudentHelper::loadStudentById($id);
    }

    /**
     * Test loadStudentById - unknown error
     */
    public function testLoadStudentByIdUnknownError()
    {
        $id = new ObjectID();
        
        // Mock Student model
        $mockStudentModel = m::mock();
        $mockStudentModel->shouldReceive('findByPk')
            ->once()
            ->with($id)
            ->andThrow(new Exception("Database error"));
        
        m::mock('alias:Student')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockStudentModel);

        $this->assertTrue(true);
        StudentHelper::loadStudentById($id);
    }

    /**
     * Test loadStudentByUserId - successful case
     */
    public function testLoadStudentByUserIdSuccess()
    {
        $userId = new ObjectID();
        $mockStudent = m::mock();

        // Mock EMongoCriteria
        $mockCriteria = m::mock('overload:EMongoCriteria');
        $mockCriteria->shouldReceive('addCond')
            ->once()
            ->with('user_id', '==', $userId);

        // Mock the Student model's find method
        $mockStudentModel = m::mock();
        $mockStudentModel->shouldReceive('find')
            ->once()
            ->with(m::type('EMongoCriteria'))
            ->andReturn($mockStudent);

        m::mock('alias:Student')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockStudentModel);

        $result = StudentHelper::loadStudentByUserId($userId);
        $this->assertSame($mockStudent, $result);
    }

    /**
     * Test loadStudentByUserId - student not found
     */
    public function testLoadStudentByUserIdNotFound()
    {
        $userId = new ObjectID();

        // Mock EMongoCriteria
        $mockCriteria = m::mock('overload:EMongoCriteria');
        $mockCriteria->shouldReceive('addCond')
            ->once()
            ->with('user_id', '==', $userId);

        // Mock Student model
        $mockStudentModel = m::mock();
        $mockStudentModel->shouldReceive('find')
            ->once()
            ->with(m::type('EMongoCriteria'))
            ->andReturn(null);
        
        m::mock('alias:Student')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockStudentModel);

        $this->expectExceptionObject(new CHttpException(404, 'The requested student does not exist.'));
        StudentHelper::loadStudentByUserId($userId);
    }

    /**
     * Test createStudent - success
     */
    public function testCreateStudentSuccess()
    {
        $userId = new ObjectID();
        $classId = new ObjectID();
        $studentData = [
            'name' => 'John Doe',
            'class' => (string)$classId,
            'grade' => 'A',
            'profile_picture' => null
        ];

        // Mock Student instance
        $mockStudent = m::mock('overload:Student');
        $mockStudent->_id = new ObjectID();
        $mockStudent->user_id = $userId;
        $mockStudent->name = 'John Doe';
        $mockStudent->class = $classId;
        $mockStudent->grade = 'A';
        $mockStudent->profile_picture_key = null;
        
        $mockStudent->shouldReceive('validate')->once()->andReturn(true);
        $mockStudent->shouldReceive('save')->once()->andReturn(true);

        // Mock CUploadedFile::getInstance to return null (no file upload)
        m::mock('alias:CUploadedFile')
            ->shouldReceive('getInstance')
            ->once()
            ->with($mockStudent, 'profile_picture')
            ->andReturn(null);

        $result = StudentHelper::createStudent($studentData, $userId);
        
        $this->assertTrue($result['success']);
        $this->assertInstanceOf(Student::class, $result['model']);
        $this->assertStringContainsString('Student created successfully!', $result['message']);
    }

    /**
     * Test createStudent - validation failure
     */
    public function testCreateStudentValidationFailure()
    {
        $userId = new ObjectID();
        $classId = new ObjectID();
        $studentData = [
            'name' => 'John Doe',
            'class' => (string)$classId
        ];

        // Mock Student instance
        $mockStudent = m::mock('overload:Student');
        $mockStudent->user_id = $userId;
        $mockStudent->class = $classId;
        $mockStudent->profile_picture_key = null;
        
        $mockStudent->shouldReceive('validate')->once()->andReturn(false);
        $mockStudent->shouldReceive('save')->never();
        $mockStudent->shouldReceive('getErrors')->once()->andReturn(['grade' => ['Grade is required']]);

        // Mock CUploadedFile::getInstance to return null
        m::mock('alias:CUploadedFile')
            ->shouldReceive('getInstance')
            ->once()
            ->with($mockStudent, 'profile_picture')
            ->andReturn(null);

        $result = StudentHelper::createStudent($studentData, $userId);
        
        $this->assertFalse($result['success']);
        $this->assertInstanceOf(Student::class, $result['model']);
        $this->assertStringContainsString('Failed to save student:', $result['message']);
    }

    /**
     * Test createStudent - with profile picture upload
     */
    public function testCreateStudentWithProfilePictureUpload()
    {
        $userId = new ObjectID();
        $classId = new ObjectID();
        $studentData = [
            'name' => 'John Doe',
            'class' => (string)$classId,
            'profile_picture' => 'test-file.jpg'
        ];

        // Mock Student instance
        $mockStudent = m::mock('overload:Student');
        $mockStudent->_id = new ObjectID();
        $mockStudent->user_id = $userId;
        $mockStudent->class = $classId;
        $mockStudent->profile_picture_key = null;
        
        $mockStudent->shouldReceive('validate')->once()->andReturn(true);
        $mockStudent->shouldReceive('save')->once()->andReturn(true);

        // Mock uploaded file
        $mockUploadedFile = m::mock();
        $mockUploadedFile->shouldReceive('getExtensionName')->once()->andReturn('jpg');
        $mockUploadedFile->tempName = '/tmp/test-file.jpg';

        // Mock CUploadedFile::getInstance to return the uploaded file
        m::mock('alias:CUploadedFile')
            ->shouldReceive('getInstance')
            ->once()
            ->with($mockStudent, 'profile_picture')
            ->andReturn($mockUploadedFile);

        // Mock file_get_contents
        m::mock('alias:file_get_contents')
            ->shouldReceive('file_get_contents')
            ->once()
            ->with('/tmp/test-file.jpg')
            ->andReturn('file content');

        // Mock S3Helper
        $mockS3Result = m::mock();
        m::mock('alias:S3Helper')
            ->shouldReceive('uploadObject')
            ->once()
            ->andReturn($mockS3Result);

        $result = StudentHelper::createStudent($studentData, $userId);
        
        $this->assertTrue($result['success']);
        $this->assertInstanceOf(Student::class, $result['model']);
    }

    /**
     * Test createStudent - invalid file type
     */
    public function testCreateStudentInvalidFileType()
    {
        $userId = new ObjectID();
        $classId = new ObjectID();
        $studentData = [
            'name' => 'John Doe',
            'class' => (string)$classId,
            'profile_picture' => 'test-file.txt'
        ];

        // Mock Student instance
        $mockStudent = m::mock('overload:Student');
        $mockStudent->_id = new ObjectID();
        $mockStudent->user_id = $userId;
        $mockStudent->class = $classId;
        $mockStudent->profile_picture_key = null;

        // Mock uploaded file with invalid extension
        $mockUploadedFile = m::mock();
        $mockUploadedFile->shouldReceive('getExtensionName')->once()->andReturn('txt');

        // Mock CUploadedFile::getInstance to return the uploaded file
        m::mock('alias:CUploadedFile')
            ->shouldReceive('getInstance')
            ->once()
            ->with($mockStudent, 'profile_picture')
            ->andReturn($mockUploadedFile);

        // Mock Yii::app()->user->setFlash
        $mockUser = m::mock();
        $mockUser->shouldReceive('setFlash')->once()->with('error', 'Invalid file type. Only JPG, JPEG, and PNG files are allowed.');
        
        $mockApp = m::mock();
        $mockApp->user = $mockUser;
        
        m::mock('alias:Yii')
            ->shouldReceive('app')
            ->once()
            ->andReturn($mockApp);

        $result = StudentHelper::createStudent($studentData, $userId);
        
        $this->assertFalse($result['success']);
        $this->assertStringContainsString('Invalid file type', $result['message']);
    }

    /**
     * Test updateStudent - success
     */
    public function testUpdateStudentSuccess()
    {
        $studentId = new ObjectID();
        $classId = new ObjectID();
        $studentData = [
            'name' => 'Jane Doe',
            'class' => (string)$classId,
            'grade' => 'B'
        ];

        // Mock Student instance
        $mockStudent = m::mock('overload:Student');
        $mockStudent->_id = $studentId;
        $mockStudent->name = 'Jane Doe';
        $mockStudent->class = $classId;
        $mockStudent->grade = 'B';
        $mockStudent->profile_picture_key = null;

        $mockStudent->shouldReceive('findByPk')->once()->with($studentId)->andReturnSelf();
        $mockStudent->shouldReceive('model')->once()->andReturnSelf();
        $mockStudent->shouldReceive('validate')->once()->andReturn(true);
        $mockStudent->shouldReceive('save')->once()->andReturn(true);

        // Mock CUploadedFile::getInstance to return null
        m::mock('alias:CUploadedFile')
            ->shouldReceive('getInstance')
            ->once()
            ->with($mockStudent, 'profile_picture')
            ->andReturn(null);

        $result = StudentHelper::updateStudent($studentId, $studentData);
        
        $this->assertTrue($result['success']);
        $this->assertEquals($mockStudent, $result['model']);
        $this->assertStringContainsString('Student updated successfully!', $result['message']);
    }

    /**
     * Test updateStudent - student not found
     */
    public function testUpdateStudentNotFound()
    {
        $studentId = new ObjectID();
        $studentData = ['name' => 'Jane Doe'];

        // Mock Student model
        $mockStudentModel = m::mock();
        $mockStudentModel->shouldReceive('findByPk')
            ->once()
            ->with($studentId)
            ->andReturn(null);
        
        m::mock('alias:Student')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockStudentModel);

        $this->expectExceptionObject(new CHttpException(404, 'The requested student does not exist.'));
        StudentHelper::updateStudent($studentId, $studentData);
    }

    /**
     * Test listStudents - success
     */
    public function testListStudentsSuccess()
    {
        $page = 1;
        $expectedStudents = [
            [
                '_id' => new ObjectID(),
                'name' => 'John Doe',
                'grade' => 'A',
                'profile_picture_key' => 'profile_pictures/test.jpg',
                'user' => ['name' => 'John', 'email' => 'john@example.com'],
                'class_info' => ['_id' => new ObjectID(), 'class_name' => 'Math 101']
            ]
        ];

        // Mock aggregation pipeline
        $mockAggregation = m::mock();
        $mockAggregation->shouldReceive('addStage')->times(4)->andReturnSelf();
        $mockAggregation->shouldReceive('sort')->once()->andReturnSelf();
        $mockAggregation->shouldReceive('skip')->once()->andReturnSelf();
        $mockAggregation->shouldReceive('limit')->once()->andReturnSelf();
        $mockAggregation->shouldReceive('aggregate')->once()->andReturn(['result' => $expectedStudents]);

        // Mock Student model
        $mockStudentModel = m::mock();
        $mockStudentModel->shouldReceive('startAggregation')
            ->once()
            ->andReturn($mockAggregation);

        m::mock('alias:Student')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockStudentModel);

        // Mock S3Helper
        m::mock('alias:S3Helper')
            ->shouldReceive('generateGETObjectUrl')
            ->once()
            ->with('profile_pictures/test.jpg')
            ->andReturn('https://s3.amazonaws.com/bucket/profile_pictures/test.jpg');

        $result = StudentHelper::listStudents($page);
        
        $this->assertIsArray($result);
        $this->assertArrayHasKey('profile_picture_url', $result[0]);
        $this->assertEquals('https://s3.amazonaws.com/bucket/profile_pictures/test.jpg', $result[0]['profile_picture_url']);
    }

    /**
     * Test listStudents - default page
     */
    public function testListStudentsDefaultPage()
    {
        $expectedStudents = [
            [
                '_id' => new ObjectID(),
                'name' => 'John Doe',
                'profile_picture_key' => null
            ]
        ];

        // Mock aggregation pipeline
        $mockAggregation = m::mock();
        $mockAggregation->shouldReceive('addStage')->times(4)->andReturnSelf();
        $mockAggregation->shouldReceive('sort')->once()->andReturnSelf();
        $mockAggregation->shouldReceive('skip')->once()->andReturnSelf();
        $mockAggregation->shouldReceive('limit')->once()->andReturnSelf();
        $mockAggregation->shouldReceive('aggregate')->once()->andReturn(['result' => $expectedStudents]);

        // Mock Student model
        $mockStudentModel = m::mock();
        $mockStudentModel->shouldReceive('startAggregation')
            ->once()
            ->andReturn($mockAggregation);

        m::mock('alias:Student')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockStudentModel);

        $result = StudentHelper::listStudents();
        
        $this->assertIsArray($result);
        $this->assertNull($result[0]['profile_picture_url']);
    }

    /**
     * Test count - without conditions
     */
    public function testCountWithoutConditions()
    {
        $expectedCount = 15;

        // Mock EMongoCriteria
        $mockCriteria = m::mock('overload:EMongoCriteria');

        // Mock Student model
        $mockStudentModel = m::mock();
        $mockStudentModel->shouldReceive('count')
            ->once()
            ->with(m::type('EMongoCriteria'))
            ->andReturn($expectedCount);
        
        m::mock('alias:Student')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockStudentModel);
        
        $result = StudentHelper::count();
        
        $this->assertEquals($expectedCount, $result);
    }

    /**
     * Test count - with conditions
     */
    public function testCountWithConditions()
    {
        $conditions = [
            ['grade', '==', 'A'],
            ['status', '==', 'active']
        ];
        $expectedCount = 8;

        // Mock EMongoCriteria
        $mockCriteria = m::mock('overload:EMongoCriteria');
        $mockCriteria->shouldReceive('addCond')->twice();

        // Mock Student model
        $mockStudentModel = m::mock();
        $mockStudentModel->shouldReceive('count')
            ->once()
            ->with(m::type('EMongoCriteria'))
            ->andReturn($expectedCount);
        
        m::mock('alias:Student')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockStudentModel);
        
        $result = StudentHelper::count($conditions);
        
        $this->assertEquals($expectedCount, $result);
    }

    /**
     * Test count - invalid conditions format
     */
    public function testCountInvalidConditions()
    {
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Conditions must be an array.');
        
        StudentHelper::count('invalid');
    }

    /**
     * Test deleteStudentByUserId - success
     */
    public function testDeleteStudentByUserIdSuccess()
    {
        $userId = new ObjectID();

        // Mock EMongoCriteria for loadStudentByUserId
        $mockCriteria = m::mock('overload:EMongoCriteria');
        $mockCriteria->shouldReceive('addCond')
            ->once()
            ->with('user_id', '==', $userId);

        // Mock Student instance
        $mockStudent = m::mock();
        $mockStudent->shouldReceive('delete')->once()->andReturn(true);

        // Mock Student model
        $mockStudentModel = m::mock();
        $mockStudentModel->shouldReceive('find')
            ->once()
            ->with(m::type('EMongoCriteria'))
            ->andReturn($mockStudent);

        m::mock('alias:Student')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockStudentModel);

        $result = StudentHelper::deleteStudentByUserId($userId);
        
        $this->assertTrue($result['success']);
        $this->assertEquals('Student deleted successfully!', $result['message']);
    }

    /**
     * Test deleteStudentByUserId - delete failure
     */
    public function testDeleteStudentByUserIdFailure()
    {
        $userId = new ObjectID();

        // Mock EMongoCriteria for loadStudentByUserId
        $mockCriteria = m::mock('overload:EMongoCriteria');
        $mockCriteria->shouldReceive('addCond')
            ->once()
            ->with('user_id', '==', $userId);

        // Mock Student instance
        $mockStudent = m::mock();
        $mockStudent->shouldReceive('delete')->once()->andReturn(false);

        // Mock Student model
        $mockStudentModel = m::mock();
        $mockStudentModel->shouldReceive('find')
            ->once()
            ->with(m::type('EMongoCriteria'))
            ->andReturn($mockStudent);

        m::mock('alias:Student')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockStudentModel);

        $result = StudentHelper::deleteStudentByUserId($userId);
        
        $this->assertFalse($result['success']);
        $this->assertEquals('Failed to delete student.', $result['message']);
    }

    /**
     * Test deleteStudentByUserId - exception handling
     */
    public function testDeleteStudentByUserIdException()
    {
        $userId = new ObjectID();

        // Mock EMongoCriteria for loadStudentByUserId
        $mockCriteria = m::mock('overload:EMongoCriteria');
        $mockCriteria->shouldReceive('addCond')
            ->once()
            ->with('user_id', '==', $userId);

        // Mock Student model that throws exception
        $mockStudentModel = m::mock();
        $mockStudentModel->shouldReceive('find')
            ->once()
            ->with(m::type('EMongoCriteria'))
            ->andThrow(new Exception('Database error'));

        m::mock('alias:Student')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockStudentModel);

        $result = StudentHelper::deleteStudentByUserId($userId);
        
        $this->assertFalse($result['success']);
        $this->assertStringContainsString('An error occurred:', $result['message']);
    }

    /**
     * Test getStudentsFromClassName - success
     */
    public function testGetStudentsFromClassNameSuccess()
    {
        $classId = new ObjectID();
        $expectedStudents = [
            [
                '_id' => new ObjectID(),
                'name' => 'John Doe',
                'class' => $classId,
                'user' => ['name' => 'John Doe']
            ]
        ];

        // Mock aggregation pipeline
        $mockAggregation = m::mock();
        $mockAggregation->shouldReceive('addStage')->times(3)->andReturnSelf();
        $mockAggregation->shouldReceive('aggregate')->once()->andReturn(['result' => $expectedStudents]);

        // Mock Student model
        $mockStudentModel = m::mock();
        $mockStudentModel->shouldReceive('startAggregation')
            ->once()
            ->andReturn($mockAggregation);

        m::mock('alias:Student')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockStudentModel);

        $result = StudentHelper::getStudentsFromClassName($classId);
        
        $this->assertEquals($expectedStudents, $result);
    }

    /**
     * Test getStudentsFromClassName - no students found
     */
    public function testGetStudentsFromClassNameNoStudents()
    {
        $classId = new ObjectID();

        // Mock aggregation pipeline
        $mockAggregation = m::mock();
        $mockAggregation->shouldReceive('addStage')->times(3)->andReturnSelf();
        $mockAggregation->shouldReceive('aggregate')->once()->andReturn(['result' => []]);

        // Mock Student model
        $mockStudentModel = m::mock();
        $mockStudentModel->shouldReceive('startAggregation')
            ->once()
            ->andReturn($mockAggregation);

        m::mock('alias:Student')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockStudentModel);

        $result = StudentHelper::getStudentsFromClassName($classId);
        
        $this->assertEquals([], $result);
    }

    /**
     * Test getStudentsFromClassName - exception handling
     */
    public function testGetStudentsFromClassNameException()
    {
        $classId = new ObjectID();

        // Mock Student model that throws exception
        $mockStudentModel = m::mock();
        $mockStudentModel->shouldReceive('startAggregation')
            ->once()
            ->andThrow(new Exception('Database error'));

        m::mock('alias:Student')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockStudentModel);

        $this->expectExceptionObject(new CHttpException(500, 'An error occurred while fetching students: Database error'));
        StudentHelper::getStudentsFromClassName($classId);
    }

    /**
     * Test validateStudentIds - valid IDs
     */
    public function testValidateStudentIdsValid()
    {
        $studentIds = [(string)new ObjectID(), (string)new ObjectID()];

        // Mock EMongoCriteria
        $mockCriteria = m::mock('overload:EMongoCriteria');
        $mockCriteria->shouldReceive('addCond')->once();

        // Mock Student model
        $mockStudentModel = m::mock();
        $mockStudentModel->shouldReceive('count')
            ->once()
            ->with(m::type('EMongoCriteria'))
            ->andReturn(2); // Same count as input array

        m::mock('alias:Student')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockStudentModel);

        $result = StudentHelper::validateStudentIds($studentIds);
        
        $this->assertTrue($result);
    }

    /**
     * Test validateStudentIds - invalid IDs
     */
    public function testValidateStudentIdsInvalid()
    {
        $studentIds = [(string)new ObjectID(), (string)new ObjectID()];

        // Mock EMongoCriteria
        $mockCriteria = m::mock('overload:EMongoCriteria');
        $mockCriteria->shouldReceive('addCond')->once();

        // Mock Student model
        $mockStudentModel = m::mock();
        $mockStudentModel->shouldReceive('count')
            ->once()
            ->with(m::type('EMongoCriteria'))
            ->andReturn(1); // Different count than input array

        m::mock('alias:Student')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockStudentModel);

        $result = StudentHelper::validateStudentIds($studentIds);
        
        $this->assertFalse($result);
    }

    /**
     * Test validateStudentIds - invalid input format
     */
    public function testValidateStudentIdsInvalidFormat()
    {
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Student IDs must be a non-empty array.');
        
        StudentHelper::validateStudentIds('invalid');
    }

    /**
     * Test validateStudentIds - empty array
     */
    public function testValidateStudentIdsEmptyArray()
    {
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Student IDs must be a non-empty array.');
        
        StudentHelper::validateStudentIds([]);
    }

    /**
     * Test _update method exception handling through createStudent
     */
    public function testCreateStudentExceptionHandling()
    {
        $userId = new ObjectID();
        $classId = new ObjectID();
        $studentData = [
            'name' => 'John Doe',
            'class' => (string)$classId
        ];

        // Mock Student instance that throws exception
        $mockStudent = m::mock('overload:Student');
        $mockStudent->user_id = $userId;
        $mockStudent->class = $classId;
        $mockStudent->profile_picture_key = null;
        
        $mockStudent->shouldReceive('validate')->once()->andThrow(new Exception('Database connection error'));

        // Mock CUploadedFile::getInstance to return null
        m::mock('alias:CUploadedFile')
            ->shouldReceive('getInstance')
            ->once()
            ->with($mockStudent, 'profile_picture')
            ->andReturn(null);

        $result = StudentHelper::createStudent($studentData, $userId);
        
        $this->assertFalse($result['success']);
        $this->assertInstanceOf(Student::class, $result['model']);
        $this->assertStringContainsString('An error occurred:', $result['message']);
    }

    /**
     * Test updateStudent with existing profile picture replacement
     */
    public function testUpdateStudentReplaceProfilePicture()
    {
        $studentId = new ObjectID();
        $classId = new ObjectID();
        $studentData = [
            'name' => 'Jane Doe',
            'class' => (string)$classId,
            'profile_picture' => 'new-file.png'
        ];

        // Mock Student instance
        $mockStudent = m::mock('overload:Student');
        $mockStudent->_id = $studentId;
        $mockStudent->class = $classId;
        $mockStudent->profile_picture_key = 'profile_pictures/old_picture.jpg'; // Existing picture
        
        $mockStudent->shouldReceive('findByPk')->once()->with($studentId)->andReturnSelf();
        $mockStudent->shouldReceive('model')->once()->andReturnSelf();
        $mockStudent->shouldReceive('validate')->once()->andReturn(true);
        $mockStudent->shouldReceive('save')->once()->andReturn(true);

        // Mock uploaded file
        $mockUploadedFile = m::mock();
        $mockUploadedFile->shouldReceive('getExtensionName')->once()->andReturn('png');
        $mockUploadedFile->tempName = '/tmp/new-file.png';

        // Mock CUploadedFile::getInstance to return the uploaded file
        m::mock('alias:CUploadedFile')
            ->shouldReceive('getInstance')
            ->once()
            ->with($mockStudent, 'profile_picture')
            ->andReturn($mockUploadedFile);

        // Mock file_get_contents
        m::mock('alias:file_get_contents')
            ->shouldReceive('file_get_contents')
            ->once()
            ->with('/tmp/new-file.png')
            ->andReturn('new file content');

        // Mock S3Helper for delete and upload
        m::mock('alias:S3Helper')
            ->shouldReceive('deleteObject')
            ->once()
            ->with('profile_pictures/old_picture.jpg', 'somebucket')
            ->andReturn(true);

        m::mock('alias:S3Helper')
            ->shouldReceive('uploadObject')
            ->once()
            ->andReturn(m::mock());

        $result = StudentHelper::updateStudent($studentId, $studentData);
        
        $this->assertTrue($result['success']);
        $this->assertInstanceOf(Student::class, $result['model']);
    }
}
