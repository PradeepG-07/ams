<?php
/**
 * @runTestsInSeparateProcesses
 * @preserveGlobalState disabled
 */
use Mockery\Adapter\Phpunit\MockeryTestCase;
use Mockery as m;
use MongoDB\BSON\ObjectID;
use MongoDB\BSON\UTCDateTime;

class TeacherHelperTest extends MockeryTestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        putenv('S3_BUCKET_NAME=somebucket');
    }

    protected function tearDown(): void
    {
        putenv('S3_BUCKET_NAME');
    }

    /**
     * Test loadTeacherById - successful case
     */
    public function testLoadTeacherByIdSuccess()
    {
        $id = new ObjectID();
        $mockTeacher = m::mock();

        // Mock the Teacher model's findByPk method
        $mockTeacherModel = m::mock();
        $mockTeacherModel->shouldReceive('findByPk')
            ->once()
            ->with($id)
            ->andReturn($mockTeacher);

        // Mock the alias to return the model
        m::mock('alias:Teacher')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockTeacherModel);

        $result = TeacherHelper::loadTeacherById($id);
        $this->assertSame($mockTeacher, $result);
    }

    /**
     * Test loadTeacherById - teacher not found
     */
    public function testLoadTeacherByIdNotFound()
    {
        $id = new ObjectID();
        
        // Mock Teacher model
        $mockTeacherModel = m::mock();
        $mockTeacherModel->shouldReceive('findByPk')
            ->once()
            ->with($id)
            ->andReturn(null);
        
        m::mock('alias:Teacher')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockTeacherModel);

        $this->expectExceptionObject(new CHttpException(404, 'The requested teacher does not exist.'));
        TeacherHelper::loadTeacherById($id);
    }

    /**
     * Test loadTeacherById - unknown error
     */
    public function testLoadTeacherByIdUnknownError()
    {
        $id = new ObjectID();
        
        // Mock Teacher model
        $mockTeacherModel = m::mock();
        $mockTeacherModel->shouldReceive('findByPk')
            ->once()
            ->with($id)
            ->andThrow(new Exception("Database error"));
        
        m::mock('alias:Teacher')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockTeacherModel);

        $this->assertTrue(true);
        TeacherHelper::loadTeacherById($id);
    }

    /**
     * Test loadTeacherByUserId - successful case
     */
    public function testLoadTeacherByUserIdSuccess()
    {
        $userId = new ObjectID();
        $mockTeacher = m::mock();

        // Mock EMongoCriteria
        $mockCriteria = m::mock('overload:EMongoCriteria');
        $mockCriteria->shouldReceive('addCond')
            ->once()
            ->with('user_id', '==', $userId);

        // Mock the Teacher model's find method
        $mockTeacherModel = m::mock();
        $mockTeacherModel->shouldReceive('find')
            ->once()
            ->with(m::type('EMongoCriteria'))
            ->andReturn($mockTeacher);

        m::mock('alias:Teacher')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockTeacherModel);

        $result = TeacherHelper::loadTeacherByUserId($userId);
        $this->assertSame($mockTeacher, $result);
    }

    /**
     * Test loadTeacherByUserId - teacher not found
     */
    public function testLoadTeacherByUserIdNotFound()
    {
        $userId = new ObjectID();

        // Mock EMongoCriteria
        $mockCriteria = m::mock('overload:EMongoCriteria');
        $mockCriteria->shouldReceive('addCond')
            ->once()
            ->with('user_id', '==', $userId);

        // Mock Teacher model
        $mockTeacherModel = m::mock();
        $mockTeacherModel->shouldReceive('find')
            ->once()
            ->with(m::type('EMongoCriteria'))
            ->andReturn(null);
        
        m::mock('alias:Teacher')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockTeacherModel);

        $this->expectExceptionObject(new CHttpException(404, 'The requested teacher does not exist.'));
        TeacherHelper::loadTeacherByUserId($userId);
    }

    /**
     * Test createTeacher - success
     */
    public function testCreateTeacherSuccess()
    {
        $userId = new ObjectID();
        $teacherData = [
            'name' => 'John Doe',
            'subject' => 'Mathematics',
            'classes' => [new ObjectID(), new ObjectID()]
        ];

        // Mock Teacher instance
        $mockTeacher = m::mock('overload:Teacher');
        $mockTeacher->_id = new ObjectID();
        $mockTeacher->user_id = $userId;
        $mockTeacher->name = 'John Doe';
        $mockTeacher->subject = 'Mathematics';
        $mockTeacher->classes = $teacherData['classes'];
        
        $mockTeacher->shouldReceive('validate')->once()->andReturn(true);
        $mockTeacher->shouldReceive('save')->once()->andReturn(true);

        $result = TeacherHelper::createTeacher($teacherData, $userId);
        
        $this->assertTrue($result['success']);
        $this->assertInstanceOf(Teacher::class, $result['model']);
        $this->assertStringContainsString('Teacher created successfully!', $result['message']);
    }

    /**
     * Test createTeacher - validation failure
     */
    public function testCreateTeacherValidationFailure()
    {
        $userId = new ObjectID();
        $teacherData = [
            'name' => 'John Doe',
            'subject' => 'Mathematics'
        ];

        // Mock Teacher instance
        $mockTeacher = m::mock('overload:Teacher');
        $mockTeacher->user_id = $userId;
        $mockTeacher->classes = [];
        
        $mockTeacher->shouldReceive('validate')->once()->andReturn(false);
        $mockTeacher->shouldReceive('save')->never();
        $mockTeacher->shouldReceive('getErrors')->once()->andReturn(['subject' => ['Subject is required']]);

        $result = TeacherHelper::createTeacher($teacherData, $userId);
        
        $this->assertFalse($result['success']);
        $this->assertInstanceOf(Teacher::class, $result['model']);
        $this->assertStringContainsString('Failed to save teacher:', $result['message']);
    }

    /**
     * Test createTeacher - save failure
     */
    public function testCreateTeacherSaveFailure()
    {
        $userId = new ObjectID();
        $teacherData = [
            'name' => 'John Doe',
            'subject' => 'Mathematics'
        ];

        // Mock Teacher instance
        $mockTeacher = m::mock('overload:Teacher');
        $mockTeacher->user_id = $userId;
        $mockTeacher->classes = [];
        
        $mockTeacher->shouldReceive('validate')->once()->andReturn(true);
        $mockTeacher->shouldReceive('save')->once()->andReturn(false);
        $mockTeacher->shouldReceive('getErrors')->once()->andReturn(['database' => ['Database error']]);

        $result = TeacherHelper::createTeacher($teacherData, $userId);
        
        $this->assertFalse($result['success']);
        $this->assertInstanceOf(Teacher::class, $result['model']);
        $this->assertStringContainsString('Failed to save teacher:', $result['message']);
    }

    /**
     * Test updateTeacher - success
     */
    public function testUpdateTeacherSuccess()
    {
        $teacherId = new ObjectID();
        $teacherData = [
            'name' => 'Jane Doe',
            'subject' => 'Physics',
            'classes' => [new ObjectID()]
        ];

        // Mock Teacher instance
        $mockTeacher = m::mock('overload:Teacher');
        $mockTeacher->_id = $teacherId;
        $mockTeacher->name = 'Jane Doe';
        $mockTeacher->subject = 'Physics';
        $mockTeacher->classes = $teacherData['classes'];

        $mockTeacher->shouldReceive('findByPk')->once()->with($teacherId)->andReturnSelf();
        $mockTeacher->shouldReceive('model')->once()->andReturnSelf();
        $mockTeacher->shouldReceive('validate')->once()->andReturn(true);
        $mockTeacher->shouldReceive('save')->once()->andReturn(true);

        $result = TeacherHelper::updateTeacher($teacherId, $teacherData);
        
        $this->assertTrue($result['success']);
        $this->assertEquals($mockTeacher, $result['model']);
        $this->assertStringContainsString('Teacher updated successfully!', $result['message']);
    }

    /**
     * Test updateTeacher - teacher not found
     */
    public function testUpdateTeacherNotFound()
    {
        $teacherId = new ObjectID();
        $teacherData = ['name' => 'Jane Doe'];

        // Mock Teacher model
        $mockTeacherModel = m::mock();
        $mockTeacherModel->shouldReceive('findByPk')
            ->once()
            ->with($teacherId)
            ->andReturn(null);
        
        m::mock('alias:Teacher')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockTeacherModel);

        $this->expectExceptionObject(new CHttpException(404, 'The requested teacher does not exist.'));
        TeacherHelper::updateTeacher($teacherId, $teacherData);
    }

    /**
     * Test updateTeacher - validation failure
     */
    public function testUpdateTeacherValidationFailure()
    {
        $teacherId = new ObjectID();
        $teacherData = [
            'name' => 'Jane Doe',
            'subject' => 'Physics'
        ];

        // Mock Teacher instance
        $mockTeacher = m::mock('overload:Teacher');
        $mockTeacher->_id = $teacherId;
        $mockTeacher->classes = [];

        $mockTeacher->shouldReceive('findByPk')->once()->with($teacherId)->andReturnSelf();
        $mockTeacher->shouldReceive('model')->once()->andReturnSelf();
        $mockTeacher->shouldReceive('validate')->once()->andReturn(false);
        $mockTeacher->shouldReceive('save')->never();
        $mockTeacher->shouldReceive('getErrors')->once()->andReturn(['name' => ['Name is required']]);

        $result = TeacherHelper::updateTeacher($teacherId, $teacherData);
        
        $this->assertFalse($result['success']);
        $this->assertInstanceOf(Teacher::class, $result['model']);
        $this->assertStringContainsString('Failed to save teacher:', $result['message']);
    }

    /**
     * Test listTeachers - success
     */
    public function testListTeachersSuccess()
    {
        $page = 1;
        $expectedTeachers = [
            [
                '_id' => new ObjectID(),
                'name' => 'John Doe',
                'subject' => 'Mathematics',
                'classes' => [],
                'user' => ['name' => 'John', 'email' => 'john@example.com']
            ]
        ];

        // Mock aggregation pipeline
        $mockAggregation = m::mock();
        $mockAggregation->shouldReceive('addStage')->times(6)->andReturnSelf();
        $mockAggregation->shouldReceive('aggregate')->once()->andReturn(['result' => $expectedTeachers]);

        // Mock Teacher model
        $mockTeacherModel = m::mock();
        $mockTeacherModel->shouldReceive('startAggregation')
            ->once()
            ->andReturn($mockAggregation);

        m::mock('alias:Teacher')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockTeacherModel);

        $result = TeacherHelper::listTeachers($page);
        
        $this->assertEquals($expectedTeachers, $result);
    }

    /**
     * Test listTeachers - default page
     */
    public function testListTeachersDefaultPage()
    {
        $expectedTeachers = [
            [
                '_id' => new ObjectID(),
                'name' => 'John Doe',
                'subject' => 'Mathematics'
            ]
        ];

        // Mock aggregation pipeline
        $mockAggregation = m::mock();
        $mockAggregation->shouldReceive('addStage')->times(6)->andReturnSelf();
        $mockAggregation->shouldReceive('aggregate')->once()->andReturn(['result' => $expectedTeachers]);

        // Mock Teacher model
        $mockTeacherModel = m::mock();
        $mockTeacherModel->shouldReceive('startAggregation')
            ->once()
            ->andReturn($mockAggregation);

        m::mock('alias:Teacher')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockTeacherModel);

        $result = TeacherHelper::listTeachers();
        
        $this->assertEquals($expectedTeachers, $result);
    }

    /**
     * Test getTeacherWithPopulatedClasses - success
     */
    public function testGetTeacherWithPopulatedClassesSuccess()
    {
        $teacherId = new ObjectID();
        $expectedTeacher = [
            '_id' => $teacherId,
            'name' => 'John Doe',
            'subject' => 'Mathematics',
            'classes' => [
                ['_id' => new ObjectID(), 'name' => 'Math 101'],
                ['_id' => new ObjectID(), 'name' => 'Math 102']
            ]
        ];

        // Mock aggregation pipeline
        $mockAggregation = m::mock();
        $mockAggregation->shouldReceive('addStage')->times(2)->andReturnSelf();
        $mockAggregation->shouldReceive('aggregate')->once()->andReturn(['result' => [$expectedTeacher]]);

        // Mock Teacher model
        $mockTeacherModel = m::mock();
        $mockTeacherModel->shouldReceive('startAggregation')
            ->once()
            ->andReturn($mockAggregation);

        m::mock('alias:Teacher')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockTeacherModel);

        $result = TeacherHelper::getTeacherWithPopulatedClasses($teacherId);
        
        $this->assertEquals($expectedTeacher, $result);
    }

    /**
     * Test getTeacherWithPopulatedClasses - teacher not found
     */
    public function testGetTeacherWithPopulatedClassesNotFound()
    {
        $teacherId = new ObjectID();

        // Mock aggregation pipeline
        $mockAggregation = m::mock();
        $mockAggregation->shouldReceive('addStage')->times(2)->andReturnSelf();
        $mockAggregation->shouldReceive('aggregate')->once()->andReturn(['result' => null]);

        // Mock Teacher model
        $mockTeacherModel = m::mock();
        $mockTeacherModel->shouldReceive('startAggregation')
            ->once()
            ->andReturn($mockAggregation);

        m::mock('alias:Teacher')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockTeacherModel);

        $this->expectExceptionObject(new CHttpException(404, 'The requested teacher does not exist.'));
        TeacherHelper::getTeacherWithPopulatedClasses($teacherId);
    }

    /**
     * Test count - without conditions
     */
    public function testCountWithoutConditions()
    {
        $expectedCount = 10;

        // Mock EMongoCriteria
        $mockCriteria = m::mock('overload:EMongoCriteria');

        // Mock Teacher model
        $mockTeacherModel = m::mock();
        $mockTeacherModel->shouldReceive('count')
            ->once()
            ->with(m::type('EMongoCriteria'))
            ->andReturn($expectedCount);
        
        m::mock('alias:Teacher')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockTeacherModel);
        
        $result = TeacherHelper::count();
        
        $this->assertEquals($expectedCount, $result);
    }

    /**
     * Test count - with conditions
     */
    public function testCountWithConditions()
    {
        $conditions = [
            ['status', '==', 'active'],
            ['subject', '==', 'Mathematics']
        ];
        $expectedCount = 5;

        // Mock EMongoCriteria
        $mockCriteria = m::mock('overload:EMongoCriteria');
        $mockCriteria->shouldReceive('addCond')->twice();

        // Mock Teacher model
        $mockTeacherModel = m::mock();
        $mockTeacherModel->shouldReceive('count')
            ->once()
            ->with(m::type('EMongoCriteria'))
            ->andReturn($expectedCount);
        
        m::mock('alias:Teacher')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockTeacherModel);
        
        $result = TeacherHelper::count($conditions);
        
        $this->assertEquals($expectedCount, $result);
    }

    /**
     * Test count - invalid conditions format
     */
    public function testCountInvalidConditions()
    {
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Conditions must be an array.');
        
        TeacherHelper::count('invalid');
    }

    /**
     * Test deleteTeacherByUserId - success
     */
    public function testDeleteTeacherByUserIdSuccess()
    {
        $userId = new ObjectID();

        // Mock EMongoCriteria for loadTeacherByUserId
        $mockCriteria = m::mock('overload:EMongoCriteria');
        $mockCriteria->shouldReceive('addCond')
            ->once()
            ->with('user_id', '==', $userId);

        // Mock Teacher instance
        $mockTeacher = m::mock();
        $mockTeacher->shouldReceive('delete')->once()->andReturn(true);

        // Mock Teacher model
        $mockTeacherModel = m::mock();
        $mockTeacherModel->shouldReceive('find')
            ->once()
            ->with(m::type('EMongoCriteria'))
            ->andReturn($mockTeacher);

        m::mock('alias:Teacher')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockTeacherModel);

        $result = TeacherHelper::deleteTeacherByUserId($userId);
        
        $this->assertTrue($result['success']);
        $this->assertEquals('Teacher deleted successfully!', $result['message']);
    }

    /**
     * Test deleteTeacherByUserId - delete failure
     */
    public function testDeleteTeacherByUserIdFailure()
    {
        $userId = new ObjectID();

        // Mock EMongoCriteria for loadTeacherByUserId
        $mockCriteria = m::mock('overload:EMongoCriteria');
        $mockCriteria->shouldReceive('addCond')
            ->once()
            ->with('user_id', '==', $userId);

        // Mock Teacher instance
        $mockTeacher = m::mock();
        $mockTeacher->shouldReceive('delete')->once()->andReturn(false);

        // Mock Teacher model
        $mockTeacherModel = m::mock();
        $mockTeacherModel->shouldReceive('find')
            ->once()
            ->with(m::type('EMongoCriteria'))
            ->andReturn($mockTeacher);

        m::mock('alias:Teacher')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockTeacherModel);

        $result = TeacherHelper::deleteTeacherByUserId($userId);
        
        $this->assertFalse($result['success']);
        $this->assertEquals('Failed to delete teacher.', $result['message']);
    }

    /**
     * Test deleteTeacherByUserId - teacher not found
     */
    public function testDeleteTeacherByUserIdNotFound()
    {
        $userId = new ObjectID();

        // Mock EMongoCriteria for loadTeacherByUserId
        $mockCriteria = m::mock('overload:EMongoCriteria');
        $mockCriteria->shouldReceive('addCond')
            ->once()
            ->with('user_id', '==', $userId);

        // Mock Teacher model
        $mockTeacherModel = m::mock();
        $mockTeacherModel->shouldReceive('find')
            ->once()
            ->with(m::type('EMongoCriteria'))
            ->andReturn(null);

        m::mock('alias:Teacher')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockTeacherModel);

        $this->expectExceptionObject(new CHttpException(404, 'The requested teacher does not exist.'));
        TeacherHelper::deleteTeacherByUserId($userId);
    }

    /**
     * Test ObjectId conversion in _update method (via createTeacher with string class IDs)
     */
    public function testCreateTeacherWithStringClassIds()
    {
        $userId = new ObjectID();
        $classId1 = new ObjectID();
        $classId2 = new ObjectID();
        $teacherData = [
            'name' => 'John Doe',
            'subject' => 'Mathematics',
            'classes' => [(string)$classId1, (string)$classId2]
        ];

        // Mock Teacher instance
        $mockTeacher = m::mock('overload:Teacher');
        $mockTeacher->_id = new ObjectID();
        $mockTeacher->user_id = $userId;
        $mockTeacher->classes = $teacherData['classes'];
        
        $mockTeacher->shouldReceive('validate')->once()->andReturn(true);
        $mockTeacher->shouldReceive('save')->once()->andReturn(true);

        $result = TeacherHelper::createTeacher($teacherData, $userId);
        
        $this->assertTrue($result['success']);
        $this->assertInstanceOf(Teacher::class, $result['model']);
    }

    /**
     * Test ObjectId conversion with array class format
     */
    public function testCreateTeacherWithArrayClassIds()
    {
        $userId = new ObjectID();
        $classId = new ObjectID();
        $teacherData = [
            'name' => 'John Doe',
            'subject' => 'Mathematics',
            'classes' => [['_id' => (string)$classId, 'name' => 'Math 101']]
        ];

        // Mock Teacher instance
        $mockTeacher = m::mock('overload:Teacher');
        $mockTeacher->_id = new ObjectID();
        $mockTeacher->user_id = $userId;
        $mockTeacher->classes = $teacherData['classes'];
        
        $mockTeacher->shouldReceive('validate')->once()->andReturn(true);
        $mockTeacher->shouldReceive('save')->once()->andReturn(true);

        $result = TeacherHelper::createTeacher($teacherData, $userId);
        
        $this->assertTrue($result['success']);
        $this->assertInstanceOf(Teacher::class, $result['model']);
    }

    /**
     * Test _update method exception handling through createTeacher
     */
    public function testCreateTeacherExceptionHandling()
    {
        $userId = new ObjectID();
        $teacherData = [
            'name' => 'John Doe',
            'subject' => 'Mathematics'
        ];

        // Mock Teacher instance that throws exception
        $mockTeacher = m::mock('overload:Teacher');
        $mockTeacher->user_id = $userId;
        $mockTeacher->classes = [];
        
        $mockTeacher->shouldReceive('validate')->once()->andThrow(new Exception('Database connection error'));

        $result = TeacherHelper::createTeacher($teacherData, $userId);
        
        $this->assertFalse($result['success']);
        $this->assertInstanceOf(Teacher::class, $result['model']);
        $this->assertStringContainsString('An error occurred:', $result['message']);
    }
}
