<?php
/**
* @runTestsInSeparateProcesses
* @preserveGlobalState disabled
*/
use Mockery\Adapter\Phpunit\MockeryTestCase;
use Mockery as m;
use MongoDB\BSON\ObjectID;
use MongoDB\BSON\UTCDateTime;
 
class UserHelperTest extends MockeryTestCase
{
    /**
     * Test loadUserById - successful case
     */
 
     protected function setUp(): void{
        parent::setUp();
        putenv('S3_BUCKET_NAME=somebucket');
    }
    protected function tearDown(): void{
        putenv('S3_BUCKET_NAME');
     }
    public function testLoadUserByIdSuccess()
    {
        $id = new ObjectID();
        $mockUser = m::mock();
    
        // Mock the User model's findByPk method
        $mockUserModel = m::mock();
        $mockUserModel->shouldReceive('findByPk')
            ->once()
            ->with($id)
            ->andReturn($mockUser);
    
        // Mock the alias to return the model
        m::mock('alias:User')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockUserModel);
    
        $result = UserHelper::loadUserById($id);
        $this->assertSame($mockUser, $result);
    }
    
    /**
     * Test loadUserById - user not found
     */
    public function testLoadUserByIdNotFound()
    {
        $id = new ObjectID();
        
        // Mock User model
        $mockUserModel = m::mock();
        $mockUserModel->shouldReceive('findByPk')
            ->once()
            ->with($id)
            ->andReturn(null);
        
        m::mock('alias:User')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockUserModel);
        $this->expectExceptionObject(new CHttpException(404, 'The requested user does not exist.'));
        UserHelper::loadUserById($id);
    }
 
    /**
     * Test loadUserById - unknown error
     */
    public function testLoadUserByIdUnknownError()
    {
        $id = new ObjectID();
        
        // Mock User model
        $mockUserModel = m::mock();
        $mockUserModel->shouldReceive('findByPk')
            ->once()
            ->with($id)
            ->andThrow(new Exception("Database error"));
        
        m::mock('alias:User')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockUserModel);
        $this->assertTrue(true);
        UserHelper::loadUserById($id);
    }
 
 
   /**
     * Test createUser - success
     */
    public function testCreateUserSuccess()
    {
           
        $userId = new ObjectID();
        $userData = [
            '_id'   => $userId,
            'name' => 'John Cena',
            'email' => 'johncena@gmail.com',
            'role' => 'student',
            'address' => [
                'street' => '123 Main St',
                'city' => 'Anytown',
                'state' => 'CA',
                'zip' => '12345',
                'country' => 'USA'
            ],
            'password' => 'password123',
            'created_at' => new UTCDateTime(),
            'updated_at' => new UTCDateTime()
        ];
 
        // Mock User instance
        $mockUser = m::mock('overload:User');
        $mockUser->_id = $userId;
        $mockUser->name = 'John Cena';
        $mockUser->email = 'johncena@gmail.com';
        $mockUser->role = 'student';
        $mockUser->user_id = $userId;
        $mockUser->address = [
            'street' => '123 Main St',
            'city' => 'Anytown',
            'state' => 'CA',
            'zip' => '12345',
            'country' => 'USA'
        ];
        $mockUser->password = 'password123';
        $mockUser->created_at = new UTCDateTime();
        $mockUser->updated_at = new UTCDateTime();

        $mockUser->shouldReceive('validate')->once()->andReturn(true);
        $mockUser->shouldReceive('_construct')->andReturnSelf();
        $mockUser->shouldReceive('save')->andReturn(true);
 
        $result = UserHelper::createUser($userData, $userId);
        // print_r($result['message']);
        $this->assertTrue($result['success']);
        $this->assertInstanceOf(User::class, $result['model']);
 
        $this->assertStringContainsString('User created successfully!', $result['message']);
    }
 
    /**
     * Test updateStudent - success
     */
    public function testUpdateStudentSuccess()
    {
        $userId = new ObjectID();
        $userData = [
            'name' => 'John Cena',
            'email' => 'johncena@gmail.com',
            'role' => 'student',
            'address' => [
                'street' => '123 Main St',
                'city' => 'Anytown',
                'state' => 'CA',
                'zip' => '12345',
                'country' => 'USA'
            ],
            'password' => 'password123',
            'created_at' => new UTCDateTime(),
            'updated_at' => new UTCDateTime()
        ];
 
        // Mock User instance
        $mockUser = m::mock('overload:User');
        $mockUser->_id = $userId;

        $mockUser->name = 'John Cena';
        $mockUser->email = 'johncena@gmail.com';
        $mockUser->role = 'student';
        $mockUser->user_id = $userId;
        $mockUser->address = [
            'street' => '123 Main St',
            'city' => 'Anytown',
            'state' => 'CA',
            'zip' => '12345',
            'country' => 'USA'
        ];
        $mockUser->password = 'password123';
        $mockUser->created_at = new UTCDateTime();
        $mockUser->updated_at = new UTCDateTime();


        $mockUser->shouldReceive('findByPk')->once()->with($userId)->andReturnSelf();
        $mockUser->shouldReceive('model')->once()->andReturnSelf();
        $mockUser->shouldReceive('setAttributes')->once()->with($userData);
        $mockUser->shouldReceive('validate')->once()->andReturn(true);
        $mockUser->shouldReceive('_construct')->andReturnSelf();
        $mockUser->shouldReceive('save')->andReturn(true);
 
        
        $result = UserHelper::updateUser($userId, $userData);
        
        $this->assertTrue($result['success']);
        $this->assertEquals($mockUser, $result['model']);
    }
     


     /**
     * Test updateStudent - success
     */
    public function testUpdateStudentFail()
    {
        $userId = new ObjectID();
        $userData = [
            'name' => 'John Cena',
            'email' => 'johncena@gmail.com',
            'role' => 'student',
            'address' => [
                'street' => '123 Main St',
                'city' => 'Anytown',
                'state' => 'CA',
                'zip' => '12345',
                'country' => 'USA'
            ],
            'password' => 'password123',
            'created_at' => new UTCDateTime(),
            'updated_at' => new UTCDateTime()
        ];
 
        // Mock User instance
        $mockUser = m::mock('overload:User');
        $mockUser->_id = $userId;

        $mockUser->name = 'John Cena';
        $mockUser->email = 'johncena@gmail.com';
        $mockUser->role = 'student';
        $mockUser->user_id = $userId;
        $mockUser->address = [
            'street' => '123 Main St',
            'city' => 'Anytown',
            'state' => 'CA',
            'zip' => '12345',
            'country' => 'USA'
        ];
        $mockUser->password = 'password123';
        $mockUser->created_at = new UTCDateTime();
        $mockUser->updated_at = new UTCDateTime();


        $mockUser->shouldReceive('findByPk')->once()->with($userId)->andReturnSelf();
        $mockUser->shouldReceive('model')->once()->andReturnSelf();
        $mockUser->shouldReceive('setAttributes')->once()->with($userData);
        $mockUser->shouldReceive('getErrors')->once()->andReturn(['email' => ['Email is already taken']]);
        $mockUser->shouldReceive('validate')->once()->andReturn(false);
        $mockUser->shouldReceive('_construct')->andReturnSelf();
        $mockUser->shouldReceive('save')->andReturn(false);
 
        
        $result = UserHelper::updateUser($userId, $userData);
        
        $this->assertFalse($result['success']);
        $this->assertInstanceOf(User::class, $result['model']);
    }

   /**
     * Test createUser - fail
     */
    public function testCreateUserFail()
    {
           
        $userId = new ObjectID();
        $userData = [
            '_id'   => $userId,
            'name' => 'John Cena',
            'email' => 'johncena@gmail.com',
            'role' => 'student',
            'address' => [
                'street' => '123 Main St',
                'city' => 'Anytown',
                'state' => 'CA',
                'zip' => '12345',
                'country' => 'USA'
            ],
            'password' => 'password123',
            'created_at' => new UTCDateTime(),
            'updated_at' => new UTCDateTime()
        ];
 
        // Mock User instance
        $mockUser = m::mock('overload:User');
        $mockUser->_id = $userId;
        $mockUser->name = 'John Cena';
        $mockUser->email = 'johncena@gmail.com';
        $mockUser->role = 'student';
        $mockUser->user_id = $userId;
        $mockUser->address = [
            'street' => '123 Main St',
            'city' => 'Anytown',
            'state' => 'CA',
            'zip' => '12345',
            'country' => 'USA'
        ];
        $mockUser->password = 'password123';
        $mockUser->created_at = new UTCDateTime();
        $mockUser->updated_at = new UTCDateTime();

        $mockUser->shouldReceive('validate')->once()->andReturn(true);
        $mockUser->shouldReceive('_construct')->andReturnSelf();
        $mockUser->shouldReceive('save')->andReturn(false);
 
        $result = UserHelper::createUser($userData, $userId);
        // print_r($result['message']);
        $this->assertFalse($result['success']);
        $this->assertInstanceOf(User::class, $result['model']);
 
        $this->assertStringContainsString('An error occurred:', $result['message']);
    }
 
    /**
     * Test deleteUser - success
     */
    public function testDeleteUserSuccess()
    {
        $userId = new ObjectID();
        // Mock User instance
        $mockUser = m::mock('overload:User');
        $mockUser->_id = $userId;
        $mockUser->shouldReceive('findByPk')->once()->with($userId)->andReturnSelf();
        $mockUser->shouldReceive('model')->once()->andReturnSelf();
        $mockUser->shouldReceive('delete')->once()->andReturn(true);
       
        $result = UserHelper::deleteUser($userId);
        
        $this->assertTrue($result['success']);
    }
    /**
     * Test deleteUser - failure
     */
    public function testDeleteUserFailure()
    {
        $userId = new ObjectID();
        // Mock User instance
        $mockUser = m::mock('overload:User');
        $mockUser->_id = $userId;
        $mockUser->shouldReceive('findByPk')->once()->with($userId)->andReturnSelf();
        $mockUser->shouldReceive('model')->once()->andReturnSelf();
        $mockUser->shouldReceive('delete')->once()->andReturn(false);
       
        $result = UserHelper::deleteUser($userId);
        
        $this->assertFalse($result['success']);
        $this->assertEquals('Failed to delete user.', $result['message']);
    }
 
    /**
     * Test deleteUser - exception handling
     */
    public function testDeleteUserExceptionHandled()
    {
        $userId = new ObjectID();
        // Mock User instance
        $mockUser = m::mock('overload:User');
        $mockUser->_id = $userId;
        $mockUser->shouldReceive('findByPk')->once()->with($userId)->andReturnSelf();
        $mockUser->shouldReceive('model')->once()->andReturnSelf();
        $mockUser->shouldReceive('delete')->once()->andThrow(new Exception('Database error'));
       
        $result = UserHelper::deleteUser($userId);
        
        $this->assertFalse($result['success']);
        $this->assertEquals('An error occurred: Database error', $result['message']);
    }
 
   
 
    /**
     * Test count - with conditions
     */
    public function testCountWithConditions()
    {
        $conditions = [
            ['status', '==', 'active'],
            ['age', '>', 18]
        ];
        $expectedCount = 5;
        // Mock Student model
        $mockStudentModel = m::mock();
        $mockStudentModel->shouldReceive('count')
            ->once()
            ->with(m::type('EMongoCriteria'))
            ->andReturn($expectedCount);
        
        // Mock Student alias - single mock
        $mockStudentAlias = m::mock('alias:Student');
        $mockStudentAlias->shouldReceive('model')
            ->once()
            ->andReturn($mockStudentModel);
        
        $result = StudentHelper::count($conditions);
        
        $this->assertEquals($expectedCount, $result);
    }
 
}
 