<?php
/**
 * @runTestsInSeparateProcesses
 * @preserveGlobalState disabled
 */
use Mockery\Adapter\Phpunit\MockeryTestCase;
use Mockery as m;
use MongoDB\BSON\ObjectID;
use MongoDB\BSON\UTCDateTime;

class ClassesHelperTest extends MockeryTestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        putenv('S3_BUCKET_NAME=somebucket');
    }

    protected function tearDown(): void
    {
        putenv('S3_BUCKET_NAME');
    }

    /**
     * Test classExists - class exists
     */
    public function testClassExistsTrue()
    {
        $id = new ObjectID();
        $mockClass = m::mock();

        // Mock Classes model
        $mockClassModel = m::mock();
        $mockClassModel->shouldReceive('findByPk')
            ->once()
            ->with($id)
            ->andReturn($mockClass);

        m::mock('alias:Classes')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockClassModel);

        $result = ClassesHelper::classExists($id);
        $this->assertTrue($result);
    }

    /**
     * Test classExists - class does not exist
     */
    public function testClassExistsFalse()
    {
        $id = new ObjectID();

        // Mock Classes model
        $mockClassModel = m::mock();
        $mockClassModel->shouldReceive('findByPk')
            ->once()
            ->with($id)
            ->andReturn(null);

        m::mock('alias:Classes')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockClassModel);

        $result = ClassesHelper::classExists($id);
        $this->assertFalse($result);
    }

    /**
     * Test classExists - exception handling
     */
    public function testClassExistsException()
    {
        $id = new ObjectID();

        // Mock Classes model
        $mockClassModel = m::mock();
        $mockClassModel->shouldReceive('findByPk')
            ->once()
            ->with($id)
            ->andThrow(new Exception("Database error"));

        m::mock('alias:Classes')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockClassModel);

        $this->expectException(Exception::class);
        $this->expectExceptionMessage("Database error");
        ClassesHelper::classExists($id);
    }

    /**
     * Test loadClassById - successful case
     */
    public function testLoadClassByIdSuccess()
    {
        $id = new ObjectID();
        $mockClass = m::mock();

        // Mock Classes model
        $mockClassModel = m::mock();
        $mockClassModel->shouldReceive('findByPk')
            ->once()
            ->with($id)
            ->andReturn($mockClass);

        m::mock('alias:Classes')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockClassModel);

        $result = ClassesHelper::loadClassById($id);
        $this->assertSame($mockClass, $result);
    }

    /**
     * Test loadClassById - class not found
     */
    public function testLoadClassByIdNotFound()
    {
        $id = new ObjectID();

        // Mock Classes model
        $mockClassModel = m::mock();
        $mockClassModel->shouldReceive('findByPk')
            ->once()
            ->with($id)
            ->andReturn(null);

        m::mock('alias:Classes')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockClassModel);

        $this->expectExceptionObject(new CHttpException(404, 'The requested class does not exist.'));
        ClassesHelper::loadClassById($id);
    }

    /**
     * Test loadClassById - exception handling
     */
    public function testLoadClassByIdException()
    {
        $id = new ObjectID();

        // Mock Classes model
        $mockClassModel = m::mock();
        $mockClassModel->shouldReceive('findByPk')
            ->once()
            ->with($id)
            ->andThrow(new Exception("Database error"));

        m::mock('alias:Classes')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockClassModel);

        $this->expectException(Exception::class);
        $this->expectExceptionMessage("Database error");
        ClassesHelper::loadClassById($id);
    }

    /**
     * Test createClass - success
     */
    public function testCreateClassSuccess()
    {
        $classData = [
            'class_name' => 'Mathematics 101',
            'description' => 'Basic Mathematics',
            'credits' => 3
        ];

        // Mock Classes instance
        $mockClass = m::mock('overload:Classes');
        $mockClass->_id = new ObjectID();
        $mockClass->class_name = 'Mathematics 101';
        $mockClass->description = 'Basic Mathematics';
        $mockClass->credits = 3;

        $mockClass->shouldReceive('validate')->once()->andReturn(true);
        $mockClass->shouldReceive('save')->once()->andReturn(true);

        $result = ClassesHelper::createClass($classData);

        $this->assertTrue($result['success']);
        $this->assertInstanceOf(Classes::class, $result['model']);
        $this->assertStringContainsString('Class created successfully!', $result['message']);
    }

    /**
     * Test createClass - validation failure
     */
    public function testCreateClassValidationFailure()
    {
        $classData = [
            'class_name' => 'Mathematics 101',
            'description' => 'Basic Mathematics'
        ];

        // Mock Classes instance
        $mockClass = m::mock('overload:Classes');
        $mockClass->_id = null;
        $mockClass->class_name = 'Mathematics 101';

        $mockClass->shouldReceive('validate')->once()->andReturn(false);
        $mockClass->shouldReceive('save')->never();
        $mockClass->shouldReceive('getErrors')->once()->andReturn(['credits' => ['Credits is required']]);

        $result = ClassesHelper::createClass($classData);

        $this->assertFalse($result['success']);
        $this->assertInstanceOf(Classes::class, $result['model']);
        $this->assertStringContainsString('Failed to save class:', $result['message']);
    }

    /**
     * Test createClass - save failure
     */
    public function testCreateClassSaveFailure()
    {
        $classData = [
            'class_name' => 'Mathematics 101',
            'description' => 'Basic Mathematics'
        ];

        // Mock Classes instance
        $mockClass = m::mock('overload:Classes');
        $mockClass->_id = null;

        $mockClass->shouldReceive('validate')->once()->andReturn(true);
        $mockClass->shouldReceive('save')->once()->andReturn(false);
        $mockClass->shouldReceive('getErrors')->once()->andReturn(['database' => ['Database error']]);

        $result = ClassesHelper::createClass($classData);

        $this->assertFalse($result['success']);
        $this->assertInstanceOf(Classes::class, $result['model']);
        $this->assertStringContainsString('Failed to save class:', $result['message']);
    }

    /**
     * Test updateClass - success
     */
    public function testUpdateClassSuccess()
    {
        $classId = new ObjectID();
        $classData = [
            'class_name' => 'Advanced Mathematics',
            'description' => 'Advanced Mathematics Course',
            'credits' => 4
        ];

        // Mock Classes instance
        $mockClass = m::mock('overload:Classes');
        $mockClass->_id = $classId;
        $mockClass->class_name = 'Advanced Mathematics';

        $mockClass->shouldReceive('findByPk')->once()->with($classId)->andReturnSelf();
        $mockClass->shouldReceive('model')->once()->andReturnSelf();
        $mockClass->shouldReceive('validate')->once()->andReturn(true);
        $mockClass->shouldReceive('save')->once()->andReturn(true);

        $result = ClassesHelper::updateClass($classId, $classData);

        $this->assertTrue($result['success']);
        $this->assertEquals($mockClass, $result['model']);
        $this->assertStringContainsString('Class updated successfully!', $result['message']);
    }

    /**
     * Test updateClass - class not found
     */
    public function testUpdateClassNotFound()
    {
        $classId = new ObjectID();
        $classData = ['class_name' => 'Advanced Mathematics'];

        // Mock Classes model
        $mockClassModel = m::mock();
        $mockClassModel->shouldReceive('findByPk')
            ->once()
            ->with($classId)
            ->andReturn(null);

        m::mock('alias:Classes')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockClassModel);

        $this->expectExceptionObject(new CHttpException(404, 'The requested class does not exist.'));
        ClassesHelper::updateClass($classId, $classData);
    }

    /**
     * Test updateClass - validation failure
     */
    public function testUpdateClassValidationFailure()
    {
        $classId = new ObjectID();
        $classData = [
            'class_name' => 'Advanced Mathematics',
            'description' => 'Advanced Mathematics Course'
        ];

        // Mock Classes instance
        $mockClass = m::mock('overload:Classes');
        $mockClass->_id = $classId;

        $mockClass->shouldReceive('findByPk')->once()->with($classId)->andReturnSelf();
        $mockClass->shouldReceive('model')->once()->andReturnSelf();
        $mockClass->shouldReceive('validate')->once()->andReturn(false);
        $mockClass->shouldReceive('save')->never();
        $mockClass->shouldReceive('getErrors')->once()->andReturn(['credits' => ['Credits is required']]);

        $result = ClassesHelper::updateClass($classId, $classData);

        $this->assertFalse($result['success']);
        $this->assertInstanceOf(Classes::class, $result['model']);
        $this->assertStringContainsString('Failed to save class:', $result['message']);
    }

    /**
     * Test _update method exception handling through createClass
     */
    public function testCreateClassExceptionHandling()
    {
        $classData = [
            'class_name' => 'Mathematics 101',
            'description' => 'Basic Mathematics'
        ];

        // Mock Classes instance that throws exception
        $mockClass = m::mock('overload:Classes');
        $mockClass->_id = null;

        $mockClass->shouldReceive('validate')->once()->andThrow(new Exception('Database connection error'));

        $result = ClassesHelper::createClass($classData);

        $this->assertFalse($result['success']);
        $this->assertInstanceOf(Classes::class, $result['model']);
        $this->assertStringContainsString('An error occurred:', $result['message']);
    }

    /**
     * Test deleteClass - success
     */
    public function testDeleteClassSuccess()
    {
        $classId = new ObjectID();

        // Mock Classes instance
        $mockClass = m::mock();
        $mockClass->shouldReceive('delete')->once()->andReturn(true);

        // Mock Classes model for loadClassById
        $mockClassModel = m::mock();
        $mockClassModel->shouldReceive('findByPk')
            ->once()
            ->with($classId)
            ->andReturn($mockClass);

        m::mock('alias:Classes')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockClassModel);

        // Mock EMongoCriteria for Student updates
        $mockCriteria = m::mock('overload:EMongoCriteria');
        $mockCriteria->class = $classId;

        // Mock EMongoModifier for Student updates
        $mockModifier = m::mock('overload:EMongoModifier');
        $mockModifier->shouldReceive('addModifier')->once()->with('class', 'set', '');

        // Mock Student model
        $mockStudentModel = m::mock();
        $mockStudentModel->shouldReceive('updateAll')
            ->once()
            ->with(m::type('EMongoModifier'), m::type('EMongoCriteria'))
            ->andReturn(true);

        m::mock('alias:Student')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockStudentModel);

        // Mock EMongoCriteria for Teacher updates
        $mockTeacherCriteria = m::mock('overload:EMongoCriteria');
        $mockTeacherCriteria->shouldReceive('addCond')
            ->once()
            ->with('classes', 'in', [$classId]);

        // Mock EMongoModifier for Teacher updates
        $mockTeacherModifier = m::mock('overload:EMongoModifier');
        $mockTeacherModifier->shouldReceive('addModifier')->once()->with('classes', 'pull', $classId);

        // Mock Teacher model
        $mockTeacherModel = m::mock();
        $mockTeacherModel->shouldReceive('updateAll')
            ->once()
            ->with(m::type('EMongoModifier'), m::type('EMongoCriteria'))
            ->andReturn(true);

        m::mock('alias:Teacher')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockTeacherModel);

        $result = ClassesHelper::deleteClass($classId);
        $this->assertTrue($result);
    }

    /**
     * Test deleteClass - class not found
     */
    public function testDeleteClassNotFound()
    {
        $classId = new ObjectID();

        // Mock Classes model
        $mockClassModel = m::mock();
        $mockClassModel->shouldReceive('findByPk')
            ->once()
            ->with($classId)
            ->andReturn(null);

        m::mock('alias:Classes')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockClassModel);

        $this->expectExceptionObject(new CHttpException(404, 'The requested class does not exist.'));
        ClassesHelper::deleteClass($classId);
    }

    /**
     * Test deleteClass - exception handling
     */
    public function testDeleteClassException()
    {
        $classId = new ObjectID();

        // Mock Classes model that throws exception
        $mockClassModel = m::mock();
        $mockClassModel->shouldReceive('findByPk')
            ->once()
            ->with($classId)
            ->andThrow(new Exception("Database connection error"));

        m::mock('alias:Classes')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockClassModel);

        $this->expectException(Exception::class);
        $this->expectExceptionMessage("Database connection error");
        ClassesHelper::deleteClass($classId);
    }

    /**
     * Test listClasses - success with results
     */
    public function testListClassesSuccess()
    {
        $page = 1;
        $limit = 10;
        $expectedClasses = [
            m::mock(), m::mock(), m::mock()
        ];

        // Mock EMongoCriteria
        $mockCriteria = m::mock('overload:EMongoCriteria');
        $mockCriteria->shouldReceive('limit')->once()->with($limit);
        $mockCriteria->shouldReceive('offset')->once()->with(0);

        // Mock Classes model
        $mockClassModel = m::mock();
        $mockClassModel->shouldReceive('findAll')
            ->once()
            ->with(m::type('EMongoCriteria'))
            ->andReturn($expectedClasses);

        m::mock('alias:Classes')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockClassModel);

        $result = ClassesHelper::listClasses($page, $limit);
        $this->assertEquals($expectedClasses, $result);
    }

    /**
     * Test listClasses - no results
     */
    public function testListClassesNoResults()
    {
        $page = 1;
        $limit = 10;

        // Mock EMongoCriteria
        $mockCriteria = m::mock('overload:EMongoCriteria');
        $mockCriteria->shouldReceive('limit')->once()->with($limit);
        $mockCriteria->shouldReceive('offset')->once()->with(0);

        // Mock Classes model
        $mockClassModel = m::mock();
        $mockClassModel->shouldReceive('findAll')
            ->once()
            ->with(m::type('EMongoCriteria'))
            ->andReturn(null);

        m::mock('alias:Classes')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockClassModel);

        $result = ClassesHelper::listClasses($page, $limit);
        $this->assertEquals([], $result);
    }

    /**
     * Test listClasses - default parameters
     */
    public function testListClassesDefaultParameters()
    {
        $expectedClasses = [m::mock()];

        // Mock EMongoCriteria
        $mockCriteria = m::mock('overload:EMongoCriteria');
        $mockCriteria->shouldReceive('limit')->once()->with(10);
        $mockCriteria->shouldReceive('offset')->once()->with(0);

        // Mock Classes model
        $mockClassModel = m::mock();
        $mockClassModel->shouldReceive('findAll')
            ->once()
            ->with(m::type('EMongoCriteria'))
            ->andReturn($expectedClasses);

        m::mock('alias:Classes')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockClassModel);

        $result = ClassesHelper::listClasses();
        $this->assertEquals($expectedClasses, $result);
    }

    /**
     * Test listClasses - exception handling
     */
    public function testListClassesException()
    {
        $page = 1;
        $limit = 10;

        // Mock EMongoCriteria
        $mockCriteria = m::mock('overload:EMongoCriteria');
        $mockCriteria->shouldReceive('limit')->once()->with($limit);
        $mockCriteria->shouldReceive('offset')->once()->with(0);

        // Mock Classes model that throws exception
        $mockClassModel = m::mock();
        $mockClassModel->shouldReceive('findAll')
            ->once()
            ->with(m::type('EMongoCriteria'))
            ->andThrow(new Exception("Database error"));

        m::mock('alias:Classes')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockClassModel);

        $this->expectException(Exception::class);
        $this->expectExceptionMessage("Database error");
        ClassesHelper::listClasses($page, $limit);
    }

    /**
     * Test count - without conditions
     */
    public function testCountWithoutConditions()
    {
        $expectedCount = 15;

        // Mock EMongoCriteria
        $mockCriteria = m::mock('overload:EMongoCriteria');

        // Mock Classes model
        $mockClassModel = m::mock();
        $mockClassModel->shouldReceive('count')
            ->once()
            ->with(m::type('EMongoCriteria'))
            ->andReturn($expectedCount);

        m::mock('alias:Classes')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockClassModel);

        $result = ClassesHelper::count();
        $this->assertEquals($expectedCount, $result);
    }

    /**
     * Test count - with conditions
     */
    public function testCountWithConditions()
    {
        $conditions = [
            ['credits', '>=', 3],
            ['status', '==', 'active']
        ];
        $expectedCount = 8;

        // Mock EMongoCriteria
        $mockCriteria = m::mock('overload:EMongoCriteria');
        $mockCriteria->shouldReceive('addCond')->twice();

        // Mock Classes model
        $mockClassModel = m::mock();
        $mockClassModel->shouldReceive('count')
            ->once()
            ->with(m::type('EMongoCriteria'))
            ->andReturn($expectedCount);

        m::mock('alias:Classes')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockClassModel);

        $result = ClassesHelper::count($conditions);
        $this->assertEquals($expectedCount, $result);
    }

    /**
     * Test count - invalid conditions format
     */
    public function testCountInvalidConditions()
    {
        $this->expectException(InvalidArgumentException::class);
        $this->expectExceptionMessage('Conditions must be an array.');

        ClassesHelper::count('invalid');
    }

    /**
     * Test getAllClasses - success with results
     */
    public function testGetAllClassesSuccess()
    {
        $mockClass1 = m::mock();
        $mockClass1->_id = new ObjectID();
        $mockClass1->class_name = 'Mathematics 101';

        $mockClass2 = m::mock();
        $mockClass2->_id = new ObjectID();
        $mockClass2->class_name = 'Physics 101';

        $expectedClasses = [$mockClass1, $mockClass2];

        // Mock Classes model
        $mockClassModel = m::mock();
        $mockClassModel->shouldReceive('findAll')
            ->once()
            ->andReturn($expectedClasses);

        m::mock('alias:Classes')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockClassModel);

        $result = ClassesHelper::getAllClasses();
        
        $expectedResult = [
            (string)$mockClass1->_id => 'Mathematics 101',
            (string)$mockClass2->_id => 'Physics 101'
        ];
        
        $this->assertEquals($expectedResult, $result);
    }

    /**
     * Test getAllClasses - no results
     */
    public function testGetAllClassesNoResults()
    {
        // Mock Classes model
        $mockClassModel = m::mock();
        $mockClassModel->shouldReceive('findAll')
            ->once()
            ->andReturn(null);

        m::mock('alias:Classes')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockClassModel);

        $result = ClassesHelper::getAllClasses();
        $this->assertEquals([], $result);
    }

    /**
     * Test getAllClasses - empty results
     */
    public function testGetAllClassesEmptyResults()
    {
        // Mock Classes model
        $mockClassModel = m::mock();
        $mockClassModel->shouldReceive('findAll')
            ->once()
            ->andReturn([]);

        m::mock('alias:Classes')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockClassModel);

        $result = ClassesHelper::getAllClasses();
        $this->assertEquals([], $result);
    }

    /**
     * Test getAllClasses - exception handling
     */
    public function testGetAllClassesException()
    {
        // Mock Classes model that throws exception
        $mockClassModel = m::mock();
        $mockClassModel->shouldReceive('findAll')
            ->once()
            ->andThrow(new Exception("Database connection error"));

        m::mock('alias:Classes')
            ->shouldReceive('model')
            ->once()
            ->andReturn($mockClassModel);

        $this->expectException(Exception::class);
        $this->expectExceptionMessage("Database connection error");
        ClassesHelper::getAllClasses();
    }
}
