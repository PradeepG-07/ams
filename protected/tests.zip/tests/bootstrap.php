<?php

// Set environment variable for coverage (optional)
putenv('XDEBUG_MODE=coverage');

// Suppress specific deprecation warnings from Yii framework
error_reporting(E_ALL & ~E_DEPRECATED);

// Or alternatively, use a custom error handler to filter out specific warnings
set_error_handler(function($errno, $errstr, $errfile, $errline) {
    // Suppress Yii framework deprecation warnings
    if ($errno === E_DEPRECATED && 
        (strpos($errstr, 'Return type of CMap::') !== false || 
         strpos($errstr, 'Return type of CList::') !== false)) {
        return true; // Suppress this error
    }
    
    // For all other errors, use the default handler
    return false;
}, E_DEPRECATED);

// Load Yii core
require_once('/data/live/framework/yiit.php'); // Use `yiit.php` for test environment
$config = '/data/live/protected/config/test.php';

// Load the Yii test app with the test config
Yii::createWebApplication($config);

// Optional: define path aliases
Yii::setPathOfAlias('application', dirname(__FILE__) . '/../');
Yii::setPathOfAlias('tests', dirname(__FILE__));

// Register autoloader if needed (Yii usually does this)
Yii::registerAutoloader(['YiiBase', 'autoload']);
