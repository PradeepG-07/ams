<?php

use Mockery\Adapter\Phpunit\MockeryTestCase;

class BaseHelperTest extends MockeryTestCase
{
    protected function setUp(): void
    {
        parent::setUp();
        $this->mockYiiApp();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    protected function mockYiiApp(): void
    {
        Yii::app()->request = Mockery::mock('CHttpRequest');
        Yii::app()->user = Mockery::mock('CWebUser');
        Yii::app()->params = ['jwtSecret' => 'test-secret'];
    }
}