<?php

// Include the Helper class file
require_once dirname(dirname(dirname(dirname(__DIR__)))) . '/components/helpers/Helper.php';

use Mockery\Adapter\Phpunit\MockeryTestCase;
use PHPUnit\Framework\Attributes\DataProvider;
use PHPUnit\Framework\Attributes\TestWith;

/**
 * Test class for Helper
 */
class HelperTest extends MockeryTestCase
{
    protected function setUp(): void
    {
        parent::setUp();
    }

    protected function tearDown(): void
    {
        Mockery::close();
        parent::tearDown();
    }

    /**
     * Data provider for testGetData
     */
    public static function getDataProvider(): array
    {
        return [
            'positive numbers' => [5, 10, 15],
            'negative numbers' => [-5, -10, -15],
            'mixed numbers' => [5, -10, -5],
            'zero values' => [0, 0, 0],
            'large numbers' => [1000000, 2000000, 3000000],
            'float numbers' => [5.5, 4.5, 10.0],
            'zero and positive' => [0, 10, 10],
            'zero and negative' => [0, -10, -10],
        ];
    }

    /**
     * Test the getData method
     */
    #[DataProvider('getDataProvider')]
    public function testGetData($a, $b, $expected)
    {
        $result = Helper::getData($a, $b);
        $this->assertEquals($expected, $result, "The sum of {$a} and {$b} should be {$expected}");
    }

}